# Compra y Venta · Demo frontend

Usa Node.js 22.12 o posterior. Desde la carpeta ComprayVenta, ejecuta `npm ci` y luego `npm run dev`. Abre la URL local que muestra Vite. `npm run build` genera el sitio estático en `dist`.

Registra una cuenta con datos ficticios e inicia sesión. Hay tres publicaciones de muestra. Para probar la creación, edición y eliminación de tus publicaciones, registra una empresa desde la aplicación. La primera cuenta creada en el navegador obtiene el rol de administrador de la demo.

Los datos se guardan en el navegador con localStorage y se conservan entre visitas al mismo origen. Al recargar, vuelve a iniciar sesión. Usa el mismo navegador y dirección para probar varios perfiles. El chat intercambia mensajes entre cuentas locales y los pedidos usan pagos simulados.

La demo utiliza bcryptjs para generar y comparar hashes. Usa una contraseña ficticia y exclusiva para esta prueba. El almacenamiento y los roles locales se pueden modificar desde las herramientas del navegador, por lo que esta autenticación es de demostración.
