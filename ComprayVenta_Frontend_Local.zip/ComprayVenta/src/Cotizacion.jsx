import React, { useState } from 'react';
import './Cotizacion.css';

export default function Cotizacion({ onNavigate, productosCotizar, onSolicitar }) {
  const [items, setItems] = useState(
    productosCotizar || []
  );

  const [enviando, setEnviando] = useState(false);

  const total = items.reduce((acc, curr) => acc + curr.precioNum * curr.cantidad, 0);

  const handleUpdateQty = (id, delta) => {
    setItems(items.map(p => p.id === id ? { ...p, cantidad: Math.max(1, p.cantidad + delta) } : p));
  };

  const handleSolicitar = async () => {
    if (!items.length || enviando) return;

    setEnviando(true);

    try {
      const resultado = await onSolicitar?.(items);

      if (!resultado?.ok) {
        throw new Error(
          resultado?.error || 'no se pudo registrar.'
        );
      }

      alert(
        'cotización N° ' + resultado.id +
        ' guardada en este navegador.'
      );

      onNavigate('principal');

    } catch (error) {
      alert(error.message);

    } finally {
      setEnviando(false);
    }
  };

  const handleDescargarPDF = () => {
    window.print();
  };

  return (
    <div className="cotizacion-page">
      <nav className="navbar-orange" style={{ padding: '10px 20px', display: 'flex', alignItems: 'center' }}>
        <button className="btn-back-home" onClick={() => onNavigate('principal')}>&#8592;</button>
        <div className="logo-home-circle" style={{ marginLeft: '15px' }}>
          <img src="/logo.svg" alt="Logo" style={{ width: '25px' }} />
        </div>
      </nav>

      <div className="cotizacion-box">
        <div className="btn-sol-title">solicitud de cotización</div>

        <div className="cotizacion-grid">
          {/* PRODUCTOS SELECCIONADOS */}
          <div className="cot-card-orange">
            <h3>productos seleccionados</h3>
            {items.map(prod => (
              <div key={prod.id} className="cot-prod-item">
                <div className="cot-prod-header">
                  <span>{prod.titulo}</span>
                  <span>{prod.precioStr}</span>
                </div>
                <div className="cot-prod-controls">
                  <span>
                    cantidad: {prod.cantidad} &nbsp;
                    <button className="cot-qty-btn" onClick={() => handleUpdateQty(prod.id, -1)}>-</button>
                    {prod.cantidad}
                    <button className="cot-qty-btn" onClick={() => handleUpdateQty(prod.id, 1)}>+</button>
                  </span>
                  <button className="btn-seleccionar-dropdown">seleccionar ∨</button>
                </div>
              </div>
            ))}
          </div>

          {/* RESUMEN DE COTIZACIÓN */}
          <div className="cot-card-orange">
            <h3>Resumen de cotización</h3>
            <div className="cot-summary-text">
              <p>Fecha de emisión: {new Date().toLocaleDateString('es-CL')}</p>
              <p>Cotización sujeta a confirmación del vendedor</p>
              <br />
              <p>Productos: {items.length}</p>
              {items.map(i => (
                <p key={i.id}>{i.titulo}... ${ (i.precioNum * i.cantidad).toLocaleString('es-CL') }</p>
              ))}
              <br />
              <p style={{ fontWeight: 'bold', fontSize: '15px' }}>Total: ${total.toLocaleString('es-CL')}</p>
            </div>
          </div>
        </div>

        {/* BOTONES DE ACCIÓN */}
        <div className="cot-actions-row">
          <button className="btn-cot-orange" onClick={handleSolicitar}>solicitar cotización</button>
          <button className="btn-cot-orange" onClick={() => onNavigate('principal')}>Cancelar</button>
        </div>

        <button className="btn-cot-descargar" onClick={handleDescargarPDF}>
          DESCARGAR PDF
        </button>
      </div>
    </div>
  );
}