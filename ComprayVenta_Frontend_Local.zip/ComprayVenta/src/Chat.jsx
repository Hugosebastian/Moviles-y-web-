import { useEffect, useState } from 'react';
import './Chat.css';

export default function Chat({ onNavigate, chats = [], chatActivoInicial, onCargarChats, onChatApi }) {
  const [selectedChatId, setSelectedChatId] = useState(chatActivoInicial?.id || null);
  const [mensajes, setMensajes] = useState([]);
  const [nuevoMensaje, setNuevoMensaje] = useState('');
  const [error, setError] = useState('');
  const [enviando, setEnviando] = useState(false);
  const activeChat = chats.find(c => String(c.id) === String(selectedChatId)) || chats[0];

  useEffect(() => {
    onCargarChats?.().catch(e => setError(e.message));
  }, [onCargarChats]);
  useEffect(() => {
    if (chatActivoInicial?.id) setSelectedChatId(chatActivoInicial.id);
  }, [chatActivoInicial?.id]);
  useEffect(() => {
    if (!activeChat) return;
    let vivo = true;
    const cargar = async () => {
      try {
        const r = await onChatApi(`/chats/${activeChat.id}/mensajes`);
        if (vivo) setMensajes(r.mensajes);
      } catch(e) { if (vivo) setError(e.message); }
    };
    cargar();
    const intervalo = setInterval(cargar, 5000);
    return () => { vivo = false; clearInterval(intervalo); };
  }, [activeChat?.id, onChatApi]);

  const enviar = async e => {
    e.preventDefault();
    if (!nuevoMensaje.trim() || !activeChat || enviando) return;
    setEnviando(true); setError('');
    try {
      await onChatApi(`/chats/${activeChat.id}/mensajes`, 'POST', { texto: nuevoMensaje.trim() });
      setNuevoMensaje('');
      const r = await onChatApi(`/chats/${activeChat.id}/mensajes`);
      setMensajes(r.mensajes);
    } catch(err) { setError(err.message); } finally { setEnviando(false); }
  };
  return (
    <div className="chat-page">
      <nav className="navbar-orange" style={{ padding:'10px 20px' }}>
        <button className="btn-back-home" onClick={() => onNavigate('principal')}>← Volver</button>
      </nav>
      <div className="chat-container-box">
        <div className="chat-sidebar">
          <div className="chat-sidebar-header">Chats privados</div>
          {chats.map(item => <button type="button" key={item.id}
            className={`chat-item ${String(item.id) === String(activeChat?.id) ? 'active' : ''}`}
            onClick={() => { setSelectedChatId(item.id); setMensajes([]); setError(''); }}>
            <img src={item.productoImg} alt="Producto" />
            <div className="chat-item-info"><h4>{item.vendedorNombre}</h4><p>{item.productoTitulo}</p></div>
          </button>)}
        </div>
        <div className="chat-main-area">
          {error && <p role="alert" style={{ color:'crimson', padding:12 }}>{error}</p>}
          {activeChat ? <>
            <div className="chat-header-vendedor">{activeChat.vendedorNombre} · {activeChat.productoTitulo}</div>
            <div className="chat-messages-body">{mensajes.length ? mensajes.map(m =>
              <div key={m.id} className={`message-bubble ${m.sender}`}><span>{m.text}</span><span className="time-stamp">{m.time}</span></div>
            ) : <p style={{padding:15}}>Aún no hay mensajes. Escribe el primero.</p>}</div>
            <form className="chat-input-bar" onSubmit={enviar}>
              <input type="text" maxLength={2000} placeholder="Escribe tu mensaje..." value={nuevoMensaje} onChange={e => setNuevoMensaje(e.target.value)} />
              <button type="submit" className="btn-send-message" disabled={enviando || !nuevoMensaje.trim()}>Enviar ➤</button>
            </form>
          </> : <p style={{ padding:30 }}>No tienes conversaciones. Abre un producto y elige «Contactar vendedor».</p>}
        </div>
      </div>
    </div>
  );
}
