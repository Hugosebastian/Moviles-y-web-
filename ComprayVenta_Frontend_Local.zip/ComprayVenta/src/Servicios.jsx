
import React, { useMemo, useState } from 'react';
import './Servicios.css';

const formatoPrecio = (precio) => {
  const numero = Number(precio);

  if (!Number.isFinite(numero)) {
    return '$0';
  }

  return `$${numero.toLocaleString('es-CL')}`;
};

export default function Servicios({
  publicaciones = [],
  onVerDetalle
}) {
  const [busqueda, setBusqueda] = useState('');
  const [categoriaSeleccionada, setCategoriaSeleccionada] =
    useState('todas');

  const servicios = useMemo(() => {
    return publicaciones.filter(
      (item) =>
        String(item.tipo || '').toLowerCase() === 'servicio'
    );
  }, [publicaciones]);

  const categorias = useMemo(() => {
    const disponibles = servicios
      .map((item) => item.categoria)
      .filter(Boolean);

    return [...new Set(disponibles)];
  }, [servicios]);

  const serviciosFiltrados = useMemo(() => {
    const texto = busqueda.trim().toLocaleLowerCase('es-CL');

    return servicios.filter((item) => {
      const coincideBusqueda =
        !texto ||
        [
          item.titulo,
          item.descripcion,
          item.categoria,
          item.empresaNombre,
          item.vendedor
        ].some((valor) =>
          String(valor || '')
            .toLocaleLowerCase('es-CL')
            .includes(texto)
        );

      const coincideCategoria =
        categoriaSeleccionada === 'todas' ||
        item.categoria === categoriaSeleccionada;

      return coincideBusqueda && coincideCategoria;
    });
  }, [servicios, busqueda, categoriaSeleccionada]);

  const abrirDetalle = (servicio) => {
    if (typeof onVerDetalle === 'function') {
      onVerDetalle(servicio);
    }
  };

  return (
    <main className="sv-pagina">
      <div className="sv-contenedor">

        <header className="sv-encabezado">
          <div>
            <span className="sv-etiqueta">
              servicios disponibles
            </span>

            <h1>explorar servicios</h1>

            <p>
              encuentra servicios publicados por las empresas
              registradas en nuestra plataforma.
            </p>
          </div>

          <div className="sv-contador">
            <strong>{servicios.length}</strong>
            <span>
              {servicios.length === 1
                ? 'servicio publicado'
                : 'servicios publicados'}
            </span>
          </div>
        </header>

        <section className="sv-filtros">
          <div className="sv-buscador">
            <span aria-hidden="true">⌕</span>

            <input
              type="search"
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              placeholder="buscar servicios o empresas..."
              aria-label="buscar servicios"
            />
          </div>

          <select
            value={categoriaSeleccionada}
            onChange={(e) =>
              setCategoriaSeleccionada(e.target.value)
            }
            aria-label="filtrar por categoría"
          >
            <option value="todas">
              todas las categorías
            </option>

            {categorias.map((categoria) => (
              <option
                key={categoria}
                value={categoria}
              >
                {categoria}
              </option>
            ))}
          </select>
        </section>

        {serviciosFiltrados.length === 0 ? (
          <section className="sv-vacio">
            <div className="sv-vacio-icono">
              🛠️
            </div>

            <h2>
              {servicios.length === 0
                ? 'todavía no hay servicios publicados'
                : 'no encontramos servicios'}
            </h2>

            <p>
              {servicios.length === 0
                ? 'cuando las empresas publiquen servicios, aparecerán aquí.'
                : 'prueba con otra búsqueda o categoría.'}
            </p>

            {servicios.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  setBusqueda('');
                  setCategoriaSeleccionada('todas');
                }}
                className="sv-boton-limpiar"
              >
                limpiar filtros
              </button>
            )}
          </section>
        ) : (
          <>
            <p className="sv-resultados">
              mostrando {serviciosFiltrados.length}{' '}
              {serviciosFiltrados.length === 1
                ? 'servicio'
                : 'servicios'}
            </p>

            <div className="sv-grid">
              {serviciosFiltrados.map((servicio) => {
                const stock = Number(servicio.stock);
                const disponible =
                  Number.isFinite(stock) && stock > 0;

                const empresa =
                  servicio.empresaNombre ||
                  servicio.vendedor ||
                  'empresa no especificada';

                const imagen =
                  servicio.img ||
                  servicio.imagenes?.[0] ||
                  '';

                return (
                  <article
                    className="sv-tarjeta"
                    key={servicio.id}
                  >
                    <div className="sv-imagen">
                      {imagen ? (
                        <img
                          src={imagen}
                          alt={servicio.titulo || 'servicio'}
                          loading="lazy"
                          onError={(e) => {
                            e.currentTarget.style.display =
                              'none';

                            e.currentTarget.parentElement
                              ?.classList.add(
                                'sv-imagen-sin-foto'
                              );
                          }}
                        />
                      ) : (
                        <div className="sv-sin-imagen">
                          🛠️
                        </div>
                      )}

                      <span
                        className={
                          disponible
                            ? 'sv-estado disponible'
                            : 'sv-estado agotado'
                        }
                      >
                        {disponible
                          ? 'disponible'
                          : 'sin cupos'}
                      </span>
                    </div>

                    <div className="sv-contenido">
                      <span className="sv-categoria">
                        {servicio.categoria ||
                          'sin categoría'}
                      </span>

                      <h2>{servicio.titulo}</h2>

                      <p className="sv-empresa">
                        ofrecido por{' '}
                        <strong>{empresa}</strong>
                      </p>

                      <p className="sv-descripcion">
                        {servicio.descripcion ||
                          'sin descripción disponible.'}
                      </p>

                      {servicio.tiempo && (
                        <div className="sv-dato">
                          <span>duración:</span>
                          <strong>
                            {servicio.tiempo}
                          </strong>
                        </div>
                      )}

                      {servicio.metodoEntrega && (
                        <div className="sv-dato">
                          <span>modalidad:</span>
                          <strong>
                            {servicio.metodoEntrega}
                          </strong>
                        </div>
                      )}

                      <div className="sv-pie">
                        <div className="sv-precio">
                          <small>precio</small>

                          <strong>
                            {formatoPrecio(
                              servicio.precioNum
                            )}
                          </strong>

                          {servicio.oferta &&
                            servicio.oferta !== '0%' && (
                              <span className="sv-oferta">
                                oferta: {servicio.oferta}
                              </span>
                            )}
                        </div>

                        <button
                          type="button"
                          className="sv-ver-detalle"
                          onClick={() =>
                            abrirDetalle(servicio)
                          }
                        >
                          ver detalles
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          </>
        )}
      </div>
    </main>
  );
}
