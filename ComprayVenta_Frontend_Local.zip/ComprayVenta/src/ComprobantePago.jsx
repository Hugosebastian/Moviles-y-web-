import React from 'react';
import './ComprobantePago.css';

export default function ComprobantePago({ onNavigate, datosUltimaCompra }) {
  const compra = datosUltimaCompra || {
    productoNombre: "Consola Playstation 5 Digital slim",
    img: "/productos/sin-imagen.svg",
    exito: true,
    numeroSeguimiento: "ABCDEFGHJKLM"
  };

  const handleDescargar = () => {
    window.print();
  };

  return (
    <div className="comprobante-page">
      <nav className="navbar-orange" style={{ padding: '10px 20px', display: 'flex', alignItems: 'center' }}>
        <button className="btn-back-home" onClick={() => onNavigate('principal')}>&#8592;</button>
        <div className="logo-home-circle" style={{ marginLeft: '15px' }}>
          <img src="/logo.svg" alt="Logo" style={{ width: '25px' }} />
        </div>
      </nav>

      <div className="comprobante-box">
        <div className="comprobante-grid">
          <div className="comprobante-img-card">
            <img src={compra.img} alt={compra.productoNombre} />
          </div>

          <div className="comprobante-info">
            <h2>{compra.productoNombre}</h2>

            <div className={`status-badge-pago ${compra.exito ? 'exito' : 'rechazado'}`}>
              {compra.exito ? 'PEDIDO DE PRUEBA REGISTRADO (SIN COBRO REAL)' : 'PAGO RECHAZADO'}
            </div>

            <div className="tracking-field">
              <label>Numero de seguimiento:</label>
              <input
                type="text"
                className="tracking-input"
                value={compra.numeroSeguimiento}
                readOnly
              />
            </div>

            <button className="btn-descargar-comprobante" onClick={handleDescargar}>
              Descargar comprobante de compra 📄
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}