import { compare, hash } from 'bcryptjs';

const clave = 'comprayventa-demo-v1';
const favoritos = [{ id: 'favoritos', nombre: 'Mis favoritos', predeterminada: true, productos: [] }];
let sesion;
let cola = Promise.resolve();

const identificador = () => crypto.randomUUID();
const mismo = (a, b) => String(a) === String(b);
const buscar = (lista, id) => {
  const item = lista.find(x => mismo(x.id, id));
  if (!item) throw new Error('El elemento ya no está disponible.');
  return item;
};
const usuarioVisible = ({ hashClave, ...usuario }) => usuario;
const validarClave = claveNueva => {
  if (claveNueva.length < 8 || new TextEncoder().encode(claveNueva).length > 72) {
    throw new Error('La contraseña debe tener al menos 8 caracteres y un máximo de 72 bytes.');
  }
};

async function operar(estado, ruta, metodo, datos) {
  const { usuarios, empresas, publicaciones, pedidos, cotizaciones, chats } = estado;
  const [seccion, id, accion, detalle] = ruta.split('/').slice(1);
  if (seccion === 'registro') {
    const { contrasena, ...perfil } = datos;
    if (usuarios.some(u => u.run === perfil.run || u.correo.toLowerCase() === perfil.correo.toLowerCase())) {
      throw new Error('Ya existe una cuenta local con ese RUN o correo.');
    }
    validarClave(contrasena);
    const { region, calle, numeroCasa, ...campos } = perfil;
    const primeraCuenta = usuarios.length === 0;
    const usuario = {
      ...campos, id: identificador(), estadoCuenta: 'Activa',
      tipoPerfil: primeraCuenta ? [...new Set([...campos.tipoPerfil, 'Administrador'])] : campos.tipoPerfil,
      estadoAdmin: primeraCuenta ? 'Aprobado' : campos.quiereSerAdmin ? 'Pendiente' : 'Sin solicitud',
      direcciones: region ? [{ id: identificador(), region, calle, numeroCasa }] : [],
      hashClave: await hash(contrasena, 12)
    };
    usuarios.push(usuario);
    return { usuario: usuarioVisible(usuario) };
  }
  if (seccion === 'login') {
    const usuario = usuarios.find(u => u.run === datos.run);
    if (!usuario || usuario.estadoCuenta === 'Bloqueada' || !(await compare(datos.contrasena, usuario.hashClave))) {
      throw new Error('RUN o contraseña incorrectos, o cuenta bloqueada.');
    }
    sesion = usuario.id;
    return { usuario: usuarioVisible(usuario) };
  }
  if (seccion === 'logout') {
    sesion = undefined;
    return {};
  }
  if (seccion === 'publicaciones' && metodo === 'GET') {
    return { publicaciones: publicaciones.filter(p => p.activa !== false) };
  }

  const usuario = usuarios.find(u => u.id === sesion);
  if (!usuario) throw new Error('Inicia sesión para continuar.');
  const empresa = empresas.find(e => e.usuarioId === usuario.id);
  switch (seccion) {
    case 'perfil': {
      if (id === 'contrasena') {
        if (!(await compare(datos.actual, usuario.hashClave))) throw new Error('Contraseña actual incorrecta.');
        validarClave(datos.nueva);
        usuario.hashClave = await hash(datos.nueva, 12);
      } else if (id === 'direcciones') {
        usuario.direcciones.push({ ...datos, id: identificador() });
      } else if (metodo === 'DELETE') {
        if (!(await compare(datos.contrasena, usuario.hashClave))) throw new Error('Contraseña incorrecta.');
        estado.usuarios = usuarios.filter(u => u !== usuario);
        estado.empresas = empresas.filter(e => e !== empresa);
        estado.publicaciones = publicaciones.filter(p => !empresa || p.empresaId !== empresa.id);
        delete estado.listas[usuario.id];
        sesion = undefined;
        return {};
      } else if (metodo === 'PATCH') {
        if (usuarios.some(u => u !== usuario && u.correo.toLowerCase() === datos.correo.toLowerCase())) {
          throw new Error('Ese correo ya está registrado.');
        }
        Object.assign(usuario, datos);
      }
      return { usuario: usuarioVisible(usuario), direcciones: usuario.direcciones };
    }
    case 'empresas': {
      if (metodo === 'GET') return { empresa };
      if (metodo === 'POST') {
        if (empresa) throw new Error('Ya registraste una empresa.');
        const nueva = { ...datos, id: identificador(), usuarioId: usuario.id, activa: true };
        empresas.push(nueva);
        usuario.tipoPerfil = [...new Set([...usuario.tipoPerfil, 'Emprendedor'])];
        return { empresa: nueva };
      }
      if (!empresa) throw new Error('Registra una empresa primero.');
      Object.assign(empresa, datos);
      return { empresa };
    }
    case 'publicaciones': {
      if (!empresa || empresa.activa === false) throw new Error('Necesitas una empresa activa.');
      if (metodo === 'POST') {
        const publicacion = { ...datos, id: identificador(), empresaId: empresa.id, activa: true };
        publicaciones.unshift(publicacion);
        return { publicacion };
      }
      const publicacion = buscar(publicaciones, id);
      if (publicacion.empresaId !== empresa.id) throw new Error('La publicación pertenece a otra empresa.');
      if (metodo === 'DELETE') estado.publicaciones = publicaciones.filter(p => p !== publicacion);
      else Object.assign(publicacion, datos);
      return { publicacion };
    }
    case 'listas':
      if (metodo === 'PUT') estado.listas[usuario.id] = datos.listas;
      return { listas: estado.listas[usuario.id] || favoritos };
    case 'chats': {
      const propios = chats.filter(c => c.comprador === usuario.id || c.empresaId === empresa?.id);
      if (id) {
        const chat = buscar(propios, id);
        if (metodo === 'POST') {
          chat.mensajes.push({ id: identificador(), autor: usuario.id, text: datos.texto,
            time: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }) });
        }
        return { mensajes: chat.mensajes.map(m => ({ ...m, sender: m.autor === usuario.id ? 'sent' : 'received' })) };
      }
      if (metodo === 'GET') return { chats: propios.map(({ mensajes, ...chat }) => chat) };
      const existente = propios.find(c => c.comprador === usuario.id && mismo(c.publicacionId, datos.publicacionId));
      if (existente) return { id: existente.id };
      const p = buscar(publicaciones, datos.publicacionId);
      const vendedor = empresas.find(e => e.id === p.empresaId);
      const chat = { id: identificador(), comprador: usuario.id, empresaId: p.empresaId, publicacionId: p.id,
        vendedorNombre: vendedor?.nombreEmpresa || 'Tienda de muestra', productoTitulo: p.titulo,
        productoImg: p.img, mensajes: [] };
      chats.push(chat);
      return { id: chat.id };
    }
    case 'pedidos':
    case 'cotizaciones': {
      if (metodo === 'GET') return { pedidos: pedidos.filter(p => id === 'ventas'
        ? empresa && p.productos.some(d => d.empresaId === empresa.id)
        : p.comprador === usuario.id) };

      const productos = datos.productos.map(({ id, cantidad }) => {
        const p = buscar(publicaciones, id);
        if (p.activa === false || !Number.isInteger(cantidad) || cantidad < 1) throw new Error('Producto o cantidad inválida.');
        if (seccion === 'pedidos') {
          if (Number(p.stock) < cantidad) throw new Error('Stock insuficiente para ' + p.titulo);
          p.stock = Number(p.stock) - cantidad;
        }
        return { ...p, cantidad, precio: Number(p.precioNum) };
      });
      const total = productos.reduce((suma, p) => suma + p.precio * p.cantidad, 0);
      const nuevoId = identificador();
      const fecha = new Date().toISOString();
      if (seccion === 'cotizaciones') {
        cotizaciones.push({ id: nuevoId, comprador: usuario.id, solicitante: usuario.nombreCompleto,
          nombre_empresa: 'Tienda local', detalles: productos, total, estado: 'Solicitada' });
        return { cotizacionId: nuevoId };
      }
      pedidos.push({ id: nuevoId, fecha, comprador: usuario.id, productos, totalPagado: total,
        ubicacionDespacho: datos.region, estado: 'Registrado', medioPago: 'Simulado' });
      return { pedidoId: nuevoId, fecha, region: datos.region };
    }
    case 'gestion': {
      if (id === 'pedidos') {
        const pedido = buscar(pedidos.filter(p => empresa && p.productos.some(d => d.empresaId === empresa.id)), accion);
        Object.assign(pedido, datos);
        return {};
      }
      if (metodo === 'GET') {
        return { cotizaciones: cotizaciones.filter(c => accion === 'recibidas'
          ? empresa && c.detalles.some(d => d.empresaId === empresa.id)
          : c.comprador === usuario.id) };
      }
      const cotizacion = buscar(cotizaciones, accion);
      if (detalle === 'responder' && empresa && cotizacion.detalles.some(d => d.empresaId === empresa.id)) {
        Object.assign(cotizacion, { respuesta: datos.respuesta, estado: 'Respondida' });
      } else if (detalle === 'aceptar' && cotizacion.comprador === usuario.id && cotizacion.estado === 'Respondida') {
        cotizacion.estado = 'Aceptada';
      } else throw new Error('La operación no está disponible para esta cuenta.');
      return {};
    }
    case 'admin': {
      if (!usuario.tipoPerfil.includes('Administrador')) throw new Error('Se requiere un perfil de administrador.');
      if (id === 'resumen') return { usuarios: usuarios.map(usuarioVisible), empresas, publicaciones };
      const item = buscar(estado[id], accion);
      if (id === 'usuarios' && detalle === 'solicitud') {
        item.estadoAdmin = datos.estado === 'Aprobada' ? 'Aprobado' : 'Rechazado';
        if (datos.estado === 'Aprobada' && !item.tipoPerfil.includes('Administrador')) item.tipoPerfil.push('Administrador');
      } else if (id === 'usuarios' && detalle === 'estado') {
        item.estadoCuenta = datos.estado;
      } else Object.assign(item, datos);
      return {};
    }
    default: throw new Error('Operación local desconocida.');
  }
}

function estadoInicial() {
  const muestras = [
    ['Notebook de muestra', 'Tecnología', 'laptop', 249990],
    ['Mochila urbana de muestra', 'Accesorios', 'mochila', 18990],
    ['Zapatillas de muestra', 'Calzado', 'zapatilla', 29990]
  ];
  return { usuarios: [], empresas: [], pedidos: [], cotizaciones: [], chats: [], listas: {},
    publicaciones: muestras.map(([titulo, categoria, imagen, precioNum], i) => ({
      id: 'muestra-' + i, titulo, categoria, img: '/productos/' + imagen + '.svg',
      descripcion: 'Publicación ficticia para probar la tienda.', precioNum, stock: 10, activa: true
    })) };
}

export function solicitudLocal(ruta, { method = 'GET', body } = {}) {
  const tarea = cola.then(async () => {
    try {
      const guardado = localStorage.getItem(clave);
      const estado = guardado ? JSON.parse(guardado) : estadoInicial();
      const resultado = await operar(estado, ruta, method, body);
      if (method !== 'GET' && !['/login', '/logout'].includes(ruta)) {
        localStorage.setItem(clave, JSON.stringify(estado));
      }
      return { ok: true, json: async () => resultado };
    } catch (error) {
      return { ok: false, json: async () => ({ error: error.message }) };
    }
  });
  cola = tarea;
  return tarea;
}
