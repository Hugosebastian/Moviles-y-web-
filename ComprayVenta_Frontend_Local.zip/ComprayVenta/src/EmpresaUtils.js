// Utilidades compartidas: la identidad de la empresa NO depende de la marca.
// Solo se normalizan los valores para comparar, nunca para mostrarlos.
export const normalizarNombreEmpresa = (nombre) => String(nombre ?? '')
  .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
  .toLocaleLowerCase('es-CL').replace(/[^\p{L}\p{N}]+/gu, ' ').trim().replace(/\s+/g, ' ');

export const normalizarRut = (rut) => String(rut ?? '')
  .replace(/\./g, '').replace(/\s/g, '').toUpperCase();

export function rutValido(rut) {
  const limpio = normalizarRut(rut);
  const match = limpio.match(/^(\d{1,8})-([0-9K])$/);
  if (!match) return false;
  const cuerpo = match[1];
  let suma = 0;
  let multiplicador = 2;
  for (let i = cuerpo.length - 1; i >= 0; i--) {
    suma += Number(cuerpo[i]) * multiplicador;
    multiplicador = multiplicador === 7 ? 2 : multiplicador + 1;
  }
  const resto = 11 - (suma % 11);
  const dv = resto === 11 ? '0' : resto === 10 ? 'K' : String(resto);
  return match[2] === dv;
}

export function mismoPropietario(empresa, usuario) {
  return Boolean(empresa?.propietarioRun && usuario?.run &&
    normalizarRut(empresa.propietarioRun) === normalizarRut(usuario.run));
}

export function perteneceAEmpresa(publicacion, empresa) {
  if (!empresa || !publicacion) return false;
  const identificador = publicacion.empresaId ?? publicacion.vendedorId;
  return identificador != null && String(identificador) === String(empresa.id);
}

export function stockDisponible(item) {
  const stock = Number.parseInt(String(item?.stock ?? '').trim(), 10);
  return Number.isInteger(stock) && stock >= 0 ? stock : 0;
}