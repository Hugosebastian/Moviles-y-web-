# Compra y Venta

Aplicación React con Vite y backend Node.js/Express conectado a PostgreSQL. Esta carpeta reúne el código fuente y los SQL de la versión ComprayVenta recibida.

## Requisitos

- Node.js compatible con la versión de Vite declarada en package.json.
- PostgreSQL activo y acceso a una base con el esquema de esta versión.
- npm.

## Base de datos

Si la base ya está preparada, no vuelvas a cargar el esquema ni reemplaces sus datos. Si empiezas en una base nueva y vacía, ejecuta con pgAdmin:

1. `database/01_esquema_completo.sql`.
2. `database/02_verificar.sql`.

El esquema corresponde a esta versión del proyecto: 16 tablas, con roles Cliente, Emprendedor y Administrador. No es el esquema académico anterior de 40 tablas. Los SQL se copiaron sin modificar su contenido. No se incluyen registros reales de usuarios ni el respaldo de una base local.

## Backend

En una terminal situada en backend:

```powershell
npm ci
Copy-Item .env.example .env
```

Edita `.env` con tu conexión real. El ejemplo usa PostgreSQL en localhost:5432, base postgres y usuario postgres, según la conexión utilizada al preparar este paquete; cada integrante debe configurar sus propios datos. Si creaste otra base, cambia DB_NAME. Conserva PORT=3000 para que coincida con el frontend.

Luego ejecuta:

```powershell
node probar-db.js
node server.js
```

No subas el `.env` real al repositorio. Su contenido no está incluido en este paquete.

## Frontend

En una segunda terminal situada en la carpeta principal:

```powershell
npm ci
npm run dev
```

Abre http://localhost:5173 y mantén ambos procesos funcionando. El frontend utiliza http://localhost:3000 para las solicitudes al backend. PostgreSQL tiene su propio puerto 5432, configurable en backend/.env.

## Logo

El logo exportado de Figma ya está incluido en `public/logo.svg` y se carga mediante `src/Logo.jsx`. El componente utiliza el favicon como respaldo si la imagen no está disponible. Los logos de marcas se conservan en public/marcas.

## Administrador de prueba

Para crear el primer administrador, el script `backend/crear-admin.js` utiliza ADMIN_RUN, ADMIN_EMAIL y ADMIN_PASSWORD. Configura esas variables localmente en backend/.env, con un RUN aún no registrado y una contraseña propia de al menos 12 caracteres. Ejecuta desde backend:

```powershell
node crear-admin.js
```

Después retira esas tres variables del archivo local. La cuenta se conserva en PostgreSQL con hash bcrypt. Las credenciales de PostgreSQL y las de una cuenta de la web son diferentes.

## Archivos para GitHub

Sube el contenido de esta carpeta al repositorio: src, public, backend, database y los archivos de configuración de la raíz, incluidos ambos package-lock.json. No subas este ZIP como sustituto del código fuente.

Las minutas semanales reales las añadirá el integrante responsable. Mantén los commits y la participación real de cada integrante. La configuración y verificación de la Raspberry siguen pendientes del equipo.

## Alcance de la preparación

Se retiraron node_modules, dist, .env, respaldos y paquetes duplicados de instalación. Se unificó el puerto de la API en 3000 y se preparó el logo local con respaldo. Esta preparación del repositorio no certifica porcentajes de avance, configuración de Raspberry ni pruebas contra la base real del usuario.

También se corrigió la coincidencia de mayúsculas en las importaciones de Catalogo.js para permitir compilar en Linux y Raspberry.
