
const pool = require('./db');

async function probarConexion() {
  try {
    const resultado = await pool.query(
      'SELECT current_database() AS base, NOW() AS fecha'
    );

    console.log('conexión exitosa');
    console.log('base de datos:', resultado.rows[0].base);
    console.log('fecha:', resultado.rows[0].fecha);

  } catch (error) {
    console.error('error al conectar:', error.message);

  } finally {
    await pool.end();
  }
}

probarConexion();
