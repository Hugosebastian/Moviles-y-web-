import { useState } from 'react';
import './PublicarItem.css';

const SECCIONES = [
  ['vestuario-hombre', 'vestuario hombre'],
  ['calzado-hombre', 'calzado hombre'],
  ['vestuario-mujer', 'vestuario mujer'],
  ['calzado-mujer', 'calzado mujer'],
  ['ninos', 'niños y niñas'],
  ['tecnologia', 'tecnología y computación'],
  ['celulares', 'celulares'],
  ['televisores', 'televisores'],
  ['deportes', 'deportes y aire libre'],
  ['hogar', 'hogar'],
  ['muebles', 'muebles'],
  ['mascotas', 'mascotas'],
  ['accesorios', 'accesorios'],
  ['juguetes', 'juguetes'],
  ['belleza', 'belleza'],
  ['libros', 'libros y papelería'],
  ['otros', 'otros']
];

// Los identificadores deben coincidir con BarraSuperior.jsx.
const CATEGORIAS_SERVICIOS = [
  ['instalacion-electrodomesticos', 'instalación de electrodomésticos'],
  ['armado-muebles', 'armado e instalación de muebles'],
  ['soporte-computacion', 'soporte técnico y computación'],
  ['reparacion-celulares', 'reparación de celulares'],
  ['electricidad', 'electricidad e iluminación'],
  ['gasfiteria', 'gasfitería y plomería'],
  ['limpieza', 'limpieza del hogar'],
  ['pintura', 'pintura y mantención'],
  ['jardineria', 'jardinería'],
  ['mudanzas', 'mudanzas y fletes'],
  ['clases', 'clases particulares'],
  ['diseno', 'diseño y servicios digitales'],
  ['mascotas-servicios', 'cuidado de mascotas'],
  ['otros-servicios', 'otros servicios']
];

const SIN_IMAGEN = '/productos/sin-imagen.svg';

const inicial = {
  nombre: '',
  descripcion: '',
  categoria: '',
  seccion: 'tecnologia',
  condicion: 'Nuevo',
  marca: '',
  color: '',
  tamano: '',
  peso: '',
  materialPrincipal: '',
  precio: '',
  stock: '',
  oferta: '',
  img: SIN_IMAGEN,
  imagenUrl: '',
  modalidad: 'Presencial',
  duracion: '',
  restriccionEdad: 'Apto todas edades'
};

export default function PublicarItem({
  onNavigate,
  onAgregarPublicacion,
  empresaActiva,
  tipoPublicacion = 'Producto'
}) {
  const esServicio = String(tipoPublicacion).toLowerCase() === 'servicio';
  const [datos, setDatos] = useState(inicial);
  const [error, setError] = useState('');
  const [publicando, setPublicando] = useState(false);

  const cambiar = (campo, valor) => {
    setDatos(actual => ({ ...actual, [campo]: valor }));
    setError('');
  };

  const cargarImagen = evento => {
    const archivo = evento.target.files?.[0];
    if (!archivo) return;
    if (!archivo.type.startsWith('image/')) {
      setError('selecciona una imagen válida.');
      return;
    }
    if (archivo.size > 1.5 * 1024 * 1024) {
      setError('la imagen debe pesar menos de 1,5 MB.');
      return;
    }
    const lector = new FileReader();
    lector.onload = () => {
      setDatos(actual => ({ ...actual, img: String(lector.result), imagenUrl: '' }));
      setError('');
    };
    lector.readAsDataURL(archivo);
  };

  const validar = () => {
    if (datos.nombre.trim().length < 3) return 'el nombre debe tener al menos 3 caracteres.';
    if (datos.descripcion.trim().length < 10) return 'la descripción debe tener al menos 10 caracteres.';
    if (esServicio && !CATEGORIAS_SERVICIOS.some(([id]) => id === datos.categoria)) {
      return 'selecciona una categoría de servicio.';
    }
    if (datos.precio === '' || !Number.isInteger(Number(datos.precio)) || Number(datos.precio) <= 0) {
      return 'ingresa un precio entero mayor que cero.';
    }
    if (datos.stock === '' || !Number.isInteger(Number(datos.stock)) || Number(datos.stock) < 0) {
      return esServicio ? 'los cupos deben ser un número entero desde cero.' : 'el stock debe ser un número entero desde cero.';
    }
    const ofertaTexto = datos.oferta.trim();
    if (ofertaTexto) {
      const porcentaje = Number(ofertaTexto.replace('%', ''));
      if (!/^\d+(?:\.\d+)?%?$/.test(ofertaTexto) || porcentaje < 0 || porcentaje > 100) {
        return 'la oferta debe estar entre 0% y 100%.';
      }
    }
    return null;
  };

  const publicar = async evento => {
    evento.preventDefault();
    if (!empresaActiva || publicando) return;
    const mensaje = validar();
    if (mensaje) { setError(mensaje); return; }

    const precio = Number(datos.precio);
    const oferta = Number((datos.oferta.trim() || '0').replace('%', ''));
    const imagen = datos.img || SIN_IMAGEN;
    const nuevaPublicacion = {
      id: `publicacion-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      tipo: esServicio ? 'Servicio' : 'Producto',
      titulo: datos.nombre.trim(),
      descripcion: datos.descripcion.trim(),
      categoria: datos.categoria.trim(),
      precioNum: precio,
      precioStr: `$${precio.toLocaleString('es-CL')}`,
      stock: Number(datos.stock),
      oferta: `${oferta}%`,
      img: imagen,
      imagenes: [imagen],
      ...(esServicio ? {
        tiempo: datos.duracion.trim(),
        metodoEntrega: datos.modalidad,
        restriccionEdad: datos.restriccionEdad
      } : {
        seccion: datos.seccion,
        condicion: datos.condicion,
        marca: datos.marca.trim(),
        color: datos.color.trim(),
        tamano: datos.tamano.trim(),
        peso: datos.peso.trim(),
        materialPrincipal: datos.materialPrincipal.trim()
      })
    };

    setPublicando(true);

    try {
      const resultado = await onAgregarPublicacion?.(
        nuevaPublicacion
      );

      if (!resultado?.ok) {
        setError(
          resultado?.error || 'no se pudo publicar.'
        );
        return;
      }

      onNavigate?.('mis-ventas');

    } catch (error) {
      setError(error.message);

    } finally {
      setPublicando(false);
    }
  };

  if (!empresaActiva) {
    return (
      <main className="pub2-pagina">
        <div className="pub2-contenedor">
          <h1>registrar empresa</h1>
          <p>necesitas una empresa para publicar.</p>
          <button className="pub2-primario" onClick={() => onNavigate?.('registro-empresa')}>
            crear empresa
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="pub2-pagina">
      <div className="pub2-contenedor">
        <header className="pub2-encabezado">
          <span className="pub2-etiqueta">{empresaActiva.nombreEmpresa}</span>
          <h1>{esServicio ? 'publicar servicio' : 'publicar producto'}</h1>
          <p>completa los datos para que tu publicación aparezca en la plataforma.</p>
        </header>

        <form className="pub2-formulario" onSubmit={publicar}>
          <div className="pub2-seccion-titulo">
            <h2>{esServicio ? 'información del servicio' : 'información del producto'}</h2>
            <p>los campos marcados con * son obligatorios.</p>
          </div>

          <div className="pub2-grid">
            <label className="pub2-completo">
              {esServicio ? 'nombre del servicio *' : 'nombre del producto *'}
              <input required maxLength={120} value={datos.nombre}
                placeholder={esServicio ? 'ej.: instalación de lavadora' : 'ej.: notebook de 16 GB'}
                onChange={e => cambiar('nombre', e.target.value)} />
            </label>
            <label className="pub2-completo">
              descripción *
              <textarea required rows={4} minLength={10} maxLength={3000}
                placeholder={esServicio ? 'explica qué incluye el servicio y sus condiciones.' : 'describe las características del producto.'}
                value={datos.descripcion} onChange={e => cambiar('descripcion', e.target.value)} />
            </label>

            {esServicio ? (
              <>
                <label>
                  categoría del servicio *
                  <select required value={datos.categoria} onChange={e => cambiar('categoria', e.target.value)}>
                    <option value="">selecciona una categoría</option>
                    {CATEGORIAS_SERVICIOS.map(([id, nombre]) => (
                      <option key={id} value={id}>{nombre}</option>
                    ))}
                  </select>
                </label>
                <label>
                  modalidad *
                  <select required value={datos.modalidad} onChange={e => cambiar('modalidad', e.target.value)}>
                    <option value="Presencial">presencial</option>
                    <option value="En línea">en línea</option>
                    <option value="A domicilio">a domicilio</option>
                    <option value="En local">en local</option>
                  </select>
                </label>
                <label>
                  duración estimada (opcional)
                  <input placeholder="ej.: 1 hora, 3 días" value={datos.duracion}
                    onChange={e => cambiar('duracion', e.target.value)} />
                </label>
                <label>
                  restricción de edad (opcional)
                  <select value={datos.restriccionEdad} onChange={e => cambiar('restriccionEdad', e.target.value)}>
                    <option value="Apto todas edades">apto para todas las edades</option>
                    <option value="mayores de 18">mayores de 18</option>
                  </select>
                </label>
              </>
            ) : (
              <>
                <label>
                  sección de la tienda *
                  <select required value={datos.seccion} onChange={e => cambiar('seccion', e.target.value)}>
                    {SECCIONES.map(([id, nombre]) => <option key={id} value={id}>{nombre}</option>)}
                  </select>
                </label>
                <label>
                  condición *
                  <select required value={datos.condicion} onChange={e => cambiar('condicion', e.target.value)}>
                    <option value="Nuevo">nuevo</option>
                    <option value="Usado">usado</option>
                    <option value="Reacondicionado">reacondicionado</option>
                  </select>
                </label>
                <label>
                  categoría (opcional)
                  <input placeholder="ej.: computadores" value={datos.categoria}
                    onChange={e => cambiar('categoria', e.target.value)} />
                </label>
                <label>
                  marca (opcional)
                  <input value={datos.marca} onChange={e => cambiar('marca', e.target.value)} />
                </label>
                <label>
                  color (opcional)
                  <input value={datos.color} onChange={e => cambiar('color', e.target.value)} />
                </label>
                <label>
                  tamaño (opcional)
                  <input value={datos.tamano} onChange={e => cambiar('tamano', e.target.value)} />
                </label>
                <label>
                  peso (opcional)
                  <input value={datos.peso} onChange={e => cambiar('peso', e.target.value)} />
                </label>
                <label>
                  material principal (opcional)
                  <input value={datos.materialPrincipal} onChange={e => cambiar('materialPrincipal', e.target.value)} />
                </label>
              </>
            )}

            <label>
              precio en pesos chilenos *
              <input type="number" min="1" step="1" required value={datos.precio}
                placeholder="ej.: 19990" onChange={e => cambiar('precio', e.target.value)} />
            </label>
            <label>
              {esServicio ? 'cupos disponibles *' : 'stock disponible *'}
              <input type="number" min="0" step="1" required value={datos.stock}
                placeholder="ej.: 10" onChange={e => cambiar('stock', e.target.value)} />
              <small>{esServicio ? 'cantidad de atenciones disponibles.' : 'cantidad de unidades disponibles.'}</small>
            </label>
            <label>
              oferta en porcentaje (opcional)
              <input value={datos.oferta} placeholder="ej.: 10%" onChange={e => cambiar('oferta', e.target.value)} />
              <small>si no hay oferta, déjalo vacío.</small>
            </label>
            <div className="pub2-imagen-campo">
              <label htmlFor="pub2-archivo">imagen (opcional)</label>
              <input id="pub2-archivo" type="file" accept="image/*" onChange={cargarImagen} />
              <small>tamaño máximo: 1,5 MB.</small>
              <label htmlFor="pub2-imagen-url">o usa una url de imagen</label>
              <input id="pub2-imagen-url" type="url" placeholder="https://ejemplo.cl/imagen.jpg"
                value={datos.imagenUrl} onChange={e => {
                  setDatos(actual => ({
                    ...actual,
                    imagenUrl: e.target.value,
                    img: e.target.value || SIN_IMAGEN
                  }));
                  setError('');
                }} />
              <div className="pub2-vista-previa">
                <img src={datos.img} alt="vista previa de la publicación"
                  onError={e => { e.currentTarget.onerror = null; e.currentTarget.src = SIN_IMAGEN; }} />
              </div>
            </div>
          </div>

          {error && <p className="pub2-error" role="alert">{error}</p>}
          <div className="pub2-acciones">
            <button type="button" className="pub2-secundario" onClick={() => onNavigate?.('mi-empresa')}>
              cancelar
            </button>
            <button type="submit" className="pub2-primario" disabled={publicando}>
              {publicando ? 'publicando...' : esServicio ? 'publicar servicio' : 'publicar producto'}
            </button>
          </div>
        </form>
        <p className="pub2-nota">
          la publicación se asociará automáticamente a {empresaActiva.nombreEmpresa}.
          el nombre y rut de la empresa no se pueden cambiar desde este formulario.
        </p>
      </div>
    </main>
  );
}
