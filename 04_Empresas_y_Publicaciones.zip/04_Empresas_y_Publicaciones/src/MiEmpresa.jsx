
import { useEffect, useMemo, useState } from 'react';
import {
  normalizarNombreEmpresa,
  perteneceAEmpresa
} from './EmpresaUtils';
import './MiEmpresa.css';

const REGIONES = [
  'Arica y Parinacota',
  'Tarapacá',
  'Antofagasta',
  'Atacama',
  'Coquimbo',
  'Valparaíso',
  'Región Metropolitana',
  "Libertador General Bernardo O'Higgins",
  'Maule',
  'Ñuble',
  'Biobío',
  'La Araucanía',
  'Los Ríos',
  'Los Lagos',
  'Aysén del General Carlos Ibáñez del Campo',
  'Magallanes y de la Antártica Chilena'
];

const datosEditables = empresa => ({
  nombreEmpresa: empresa?.nombreEmpresa || '',
  correo: empresa?.correo || '',
  telefono: empresa?.telefono || '',
  region: empresa?.region || 'Región Metropolitana',
  calle: empresa?.calle || '',
  numeroCasa: empresa?.numeroCasa || '',
  paginaWeb: empresa?.paginaWeb || ''
});

export default function MiEmpresa({
  empresaActiva,
  empresasRegistradas = [],
  publicaciones = [],
  historialCompras = [],
  onNavigate,
  onActualizarEmpresa
}) {
  const [editando, setEditando] = useState(false);
  const [guardando, setGuardando] = useState(false);
  const [datos, setDatos] = useState(
    () => datosEditables(empresaActiva)
  );
  const [error, setError] = useState('');
  const [mensaje, setMensaje] = useState('');

  useEffect(() => {
    setDatos(datosEditables(empresaActiva));
    setEditando(false);
  }, [empresaActiva?.id]);

  const propias = useMemo(
    () => publicaciones.filter(item =>
      perteneceAEmpresa(item, empresaActiva)
    ),
    [publicaciones, empresaActiva]
  );

  const productos = propias.filter(
    item => String(item.tipo).toLowerCase() !== 'servicio'
  );

  const servicios = propias.filter(
    item => String(item.tipo).toLowerCase() === 'servicio'
  );

  const productosVendidos = useMemo(() => {
    return historialCompras.reduce((total, compra) => {
      const unidades = (compra.productos || [])
        .filter(item =>
          perteneceAEmpresa(item, empresaActiva) &&
          String(item.tipo || '').toLowerCase() !== 'servicio'
        )
        .reduce(
          (suma, item) =>
            suma + (Number(item.cantidad) || 1),
          0
        );

      return total + unidades;
    }, 0);
  }, [historialCompras, empresaActiva]);

  const cambiar = (campo, valor) => {
    setDatos(actual => ({
      ...actual,
      [campo]: valor
    }));
    setError('');
    setMensaje('');
  };

  const cancelar = () => {
    setDatos(datosEditables(empresaActiva));
    setEditando(false);
    setError('');
  };

  const guardar = async evento => {
    evento.preventDefault();
    if (guardando) return;

    const nombre = datos.nombreEmpresa.trim();
    const correo = datos.correo.trim();
    const telefono = datos.telefono.replace(/\D/g, '');
    const calle = datos.calle.trim();
    const numeroCasa = datos.numeroCasa.trim();
    const paginaWeb = datos.paginaWeb.trim();

    if (nombre.length < 3 || nombre.length > 80) {
      setError(
        'el nombre debe tener entre 3 y 80 caracteres.'
      );
      return;
    }

    const repetido = empresasRegistradas.some(
      empresa =>
        String(empresa.id) !== String(empresaActiva.id) &&
        normalizarNombreEmpresa(empresa.nombreEmpresa) ===
        normalizarNombreEmpresa(nombre)
    );

    if (repetido) {
      setError('ya existe una empresa con ese nombre.');
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) {
      setError('ingresa un correo válido.');
      return;
    }

    if (telefono.length < 8 || telefono.length > 11) {
      setError('ingresa un teléfono de 8 a 11 dígitos.');
      return;
    }

    if (!calle || !numeroCasa) {
      setError('completa la calle y el número.');
      return;
    }

    if (paginaWeb) {
      try {
        const url = new URL(paginaWeb);

        if (!['http:', 'https:'].includes(url.protocol)) {
          throw new Error('url no válida');
        }
      } catch {
        setError(
          'la página web debe comenzar con https:// o http://.'
        );
        return;
      }
    }

    setGuardando(true);

    try {
      const resultado = await onActualizarEmpresa?.({
        nombreEmpresa: nombre,
        correo,
        telefono,
        region: datos.region,
        calle,
        numeroCasa,
        direccion: `${datos.region}, ${calle} #${numeroCasa}`,
        paginaWeb
      });

      if (!resultado?.ok) {
        setError(
          resultado?.error ||
          'no se pudieron actualizar los datos.'
        );
        return;
      }

    } catch (error) {
      setError(
        error.message || 'no se pudieron actualizar los datos.'
      );
      return;

    } finally {
      setGuardando(false);
    }

      setEditando(false);
    setMensaje('los datos de tu empresa se actualizaron.');
  };

  if (!empresaActiva) {
    return (
      <main className="me-pagina">
        <div className="me-contenedor me-tarjeta">
          <h1>mi empresa</h1>
          <p>todavía no tienes una empresa registrada.</p>

          <button
            className="me-primario"
            onClick={() => onNavigate('registro-empresa')}
          >
            crear empresa
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="me-pagina">
      <div className="me-contenedor">

        <header className="me-portada">
          <div className="me-icono">🏬</div>

          <div className="me-portada-texto">
            <span className="me-etiqueta">
              panel de empresa
            </span>

            <h1>{empresaActiva.nombreEmpresa}</h1>

            <p>
              administra la información y las
              publicaciones de tu negocio.
            </p>
          </div>
        </header>

        <div className="me-estadisticas">
          <div>
            <span>productos publicados</span>
            <strong>{productos.length}</strong>
          </div>

          <div>
            <span>servicios publicados</span>
            <strong>{servicios.length}</strong>
          </div>

          <div>
            <span>productos vendidos</span>
            <strong>{productosVendidos}</strong>
          </div>

          <div>
            <span>publicaciones totales</span>
            <strong>{propias.length}</strong>
          </div>
        </div>

        <section className="me-tarjeta me-datos-panel">
          <div className="me-titulo-fila">
            <div>
              <h2>información de la empresa</h2>
              <p>
                revisa y modifica los datos de contacto
                de tu negocio.
              </p>
            </div>

            {!editando && (
              <button
                className="me-secundario"
                onClick={() => {
                  setDatos(datosEditables(empresaActiva));
                  setMensaje('');
                  setEditando(true);
                }}
              >
                <span aria-hidden="true">✎ </span>
                editar información
              </button>
            )}
          </div>

          {editando ? (
            <form onSubmit={guardar}>
              <div className="me-formulario">
                <label>
                  nombre de la empresa *
                  <input
                    value={datos.nombreEmpresa}
                    maxLength={80}
                    required
                    onChange={e =>
                      cambiar('nombreEmpresa', e.target.value)
                    }
                  />
                </label>

                <label>
                  rut de la empresa
                  <input
                    value={empresaActiva.runEmpresa || ''}
                    disabled
                  />
                  <small>no se puede modificar</small>
                </label>

                <label>
                  correo de contacto *
                  <input
                    type="email"
                    required
                    value={datos.correo}
                    onChange={e =>
                      cambiar('correo', e.target.value)
                    }
                  />
                </label>

                <label>
                  teléfono de contacto *
                  <input
                    type="tel"
                    required
                    value={datos.telefono}
                    onChange={e =>
                      cambiar('telefono', e.target.value)
                    }
                  />
                </label>

                <label>
                  región *
                  <select
                    value={datos.region}
                    onChange={e =>
                      cambiar('region', e.target.value)
                    }
                  >
                    {REGIONES.map(region => (
                      <option key={region} value={region}>
                        {region}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  calle *
                  <input
                    required
                    value={datos.calle}
                    onChange={e =>
                      cambiar('calle', e.target.value)
                    }
                  />
                </label>

                <label>
                  número *
                  <input
                    required
                    value={datos.numeroCasa}
                    onChange={e =>
                      cambiar('numeroCasa', e.target.value)
                    }
                  />
                </label>

                <label>
                  página web (opcional)
                  <input
                    type="url"
                    placeholder="https://miempresa.cl"
                    value={datos.paginaWeb}
                    onChange={e =>
                      cambiar('paginaWeb', e.target.value)
                    }
                  />
                </label>
              </div>

              <p className="me-campo-protegido">
                <span aria-hidden="true">🔒 </span>
                el rut, el propietario y la fecha de
                creación no pueden modificarse.
              </p>

              {error && (
                <p className="me-error" role="alert">
                  {error}
                </p>
              )}

              <div className="me-botones">
                <button
                  type="button"
                  className="me-secundario"
                  onClick={cancelar}
                >
                  cancelar
                </button>

                <button
                  type="submit"
                  className="me-primario"
                  disabled={guardando}
                >
                  {guardando ? 'guardando...' : 'guardar cambios'}
                </button>
              </div>
            </form>
          ) : (
            <dl className="me-datos">
              <dt>nombre</dt>
              <dd>{empresaActiva.nombreEmpresa}</dd>

              <dt>rut</dt>
              <dd>{empresaActiva.runEmpresa}</dd>

              <dt>correo</dt>
              <dd>{empresaActiva.correo}</dd>

              <dt>teléfono</dt>
              <dd>{empresaActiva.telefono}</dd>

              <dt>región</dt>
              <dd>{empresaActiva.region || 'sin información'}</dd>

              <dt>dirección</dt>
              <dd>{empresaActiva.direccion || 'sin información'}</dd>

              <dt>página web</dt>
              <dd>{empresaActiva.paginaWeb || 'no registrada'}</dd>

              <dt>rut del titular</dt>
              <dd>{empresaActiva.propietarioRun}</dd>
            </dl>
          )}

          {mensaje && (
            <p className="me-exito" role="status">
              {mensaje}
            </p>
          )}
        </section>

        <section className="me-tarjeta me-publicaciones-panel">
          <h2>publicar en mi empresa</h2>

          <p>
            elige qué deseas ofrecer. cada opción tiene
            un formulario con los datos correspondientes.
          </p>

          <div className="me-opciones-publicar">
            <button
              type="button"
              className="me-opcion"
              onClick={() =>
                onNavigate('publicar-producto')
              }
            >
              <span className="me-opcion-icono">📦</span>

              <strong>publicar producto</strong>

              <small>
                precio, condición, stock, categoría
                y características del producto
              </small>

              <span className="me-opcion-enlace">
                comenzar →
              </span>
            </button>

            <button
              type="button"
              className="me-opcion"
              onClick={() =>
                onNavigate('publicar-servicio')
              }
            >
              <span className="me-opcion-icono">🛠️</span>

              <strong>publicar servicio</strong>

              <small>
                modalidad, duración, disponibilidad
                y descripción del servicio
              </small>

              <span className="me-opcion-enlace">
                comenzar →
              </span>
            </button>
          </div>

          <button
            type="button"
            className="me-secundario me-ver-publicaciones"
            onClick={() => onNavigate('mis-ventas')}
          >
            ver mis ventas y publicaciones →
          </button>
        </section>

        <p className="me-nota">
          los productos vendidos se calculan con las
          compras simuladas de esta sesión. no representan
          ventas reales ni incluyen compras hechas desde
          otros dispositivos.
        </p>

      </div>
    </main>
  );
}
