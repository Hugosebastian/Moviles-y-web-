
import { useMemo, useState } from 'react';
import { perteneceAEmpresa } from './EmpresaUtils';
import './MisVentas.css';

const esServicio = item =>
  String(item?.tipo || '').toLowerCase() === 'servicio';

const dinero = valor =>
  `$${Number(valor || 0).toLocaleString('es-CL')}`;

const stockNumero = valor => {
  const numero = Number.parseInt(String(valor ?? ''), 10);
  return Number.isInteger(numero) && numero >= 0
    ? numero
    : 0;
};

const datosIniciales = item => ({
  titulo: item.titulo || '',
  marca: item.marca || '',
  categoria: item.categoria || '',
  descripcion: item.descripcion || '',
  precioNum: String(item.precioNum ?? ''),
  stock: String(stockNumero(item.stock)),
  oferta: item.oferta || '0%',
  img: item.img || '',
  tiempo: item.tiempo || '',
  metodoEntrega: item.metodoEntrega || ''
});

export default function MisVentas({
  onNavigate,
  publicaciones = [],
  empresaActiva,
  historialCompras = [],
  onGuardarPublicacion,
  onEliminarPublicacion
}) {
  const [editando, setEditando] = useState(null);
  const [borrador, setBorrador] = useState(null);
  const [error, setError] = useState('');

  // ============================================
  // PUBLICACIONES DE LA EMPRESA
  // ============================================

  const publicacionesPropias = useMemo(() => {
    if (!empresaActiva) return [];

    return publicaciones.filter(item =>
      perteneceAEmpresa(item, empresaActiva)
    );
  }, [publicaciones, empresaActiva]);

  const productos = useMemo(
    () => publicacionesPropias.filter(
      item => !esServicio(item)
    ),
    [publicacionesPropias]
  );

  const servicios = useMemo(
    () => publicacionesPropias.filter(esServicio),
    [publicacionesPropias]
  );

  // ============================================
  // PRODUCTOS Y SERVICIOS VENDIDOS
  // ============================================

  const {
    productosVendidos,
    serviciosVendidos
  } = useMemo(() => {
    let totalProductos = 0;
    let totalServicios = 0;

    if (!empresaActiva) {
      return {
        productosVendidos: 0,
        serviciosVendidos: 0
      };
    }

    historialCompras.forEach(compra => {
      (compra?.productos || []).forEach(comprado => {
        // Contar solo compras asociadas a esta empresa.
        if (!perteneceAEmpresa(comprado, empresaActiva)) {
          return;
        }

        // Si la compra antigua no guardó el tipo,
        // buscarlo en la publicación correspondiente.
        const publicacionOriginal = publicaciones.find(
          item =>
            String(item.id) === String(comprado.id) &&
            perteneceAEmpresa(item, empresaActiva)
        );

        const tipo = String(
          comprado.tipo ||
          publicacionOriginal?.tipo ||
          ''
        ).toLowerCase();

        const cantidadOriginal = Number(comprado.cantidad);

        const cantidad =
          Number.isFinite(cantidadOriginal) &&
          cantidadOriginal > 0
            ? cantidadOriginal
            : 1;

        if (tipo === 'servicio') {
          totalServicios += cantidad;
        } else if (tipo === 'producto') {
          totalProductos += cantidad;
        }
      });
    });

    return {
      productosVendidos: totalProductos,
      serviciosVendidos: totalServicios
    };
  }, [
    historialCompras,
    publicaciones,
    empresaActiva
  ]);

  // ============================================
  // EDITAR PUBLICACIONES
  // ============================================

  const empezarEdicion = item => {
    setEditando(String(item.id));
    setBorrador(datosIniciales(item));
    setError('');
  };

  const cambiarCampo = (campo, valor) => {
    setBorrador(actual => ({
      ...actual,
      [campo]: valor
    }));

    setError('');
  };

  const cancelarEdicion = () => {
    setEditando(null);
    setBorrador(null);
    setError('');
  };

  const guardarCambios = async item => {
    if (!borrador) return;

    const titulo = borrador.titulo.trim();
    const descripcion = borrador.descripcion.trim();

    const precio = Number(borrador.precioNum);
    const stock = Number(borrador.stock);

    const ofertaTexto =
      borrador.oferta.trim() || '0%';

    const porcentaje = Number(
      ofertaTexto.replace('%', '')
    );

    if (titulo.length < 3) {
      setError(
        'el nombre debe tener al menos 3 caracteres.'
      );
      return;
    }

    if (descripcion.length < 10) {
      setError(
        'la descripción debe tener al menos 10 caracteres.'
      );
      return;
    }

    if (
      borrador.precioNum === '' ||
      !Number.isInteger(precio) ||
      precio <= 0
    ) {
      setError(
        'el precio debe ser un número entero mayor que cero.'
      );
      return;
    }

    if (
      borrador.stock === '' ||
      !Number.isInteger(stock) ||
      stock < 0
    ) {
      setError(
        'el stock o los cupos deben ser un número entero desde cero.'
      );
      return;
    }

    if (
      !/^\d+(?:\.\d+)?%?$/.test(ofertaTexto) ||
      !Number.isFinite(porcentaje) ||
      porcentaje < 0 ||
      porcentaje > 100
    ) {
      setError(
        'la oferta debe estar entre 0% y 100%.'
      );
      return;
    }

    const cambios = {
      titulo,
      descripcion,
      categoria: borrador.categoria.trim(),
      precioNum: precio,
      precioStr: dinero(precio),
      stock,
      oferta: `${porcentaje}%`
    };

    if (esServicio(item)) {
      cambios.tiempo = borrador.tiempo.trim();
      cambios.metodoEntrega =
        borrador.metodoEntrega.trim();
    } else {
      cambios.marca = borrador.marca.trim();
    }

    const imagen = borrador.img.trim();

    if (imagen && imagen !== (item.img || '')) {
      if (
        !imagen.startsWith('https://') &&
        !imagen.startsWith('http://') &&
        !imagen.startsWith('/')
      ) {
        setError(
          'la imagen debe tener una url válida.'
        );
        return;
      }

      cambios.img = imagen;
      cambios.imagenes = [imagen];
    }

    try {
      const resultado = await onGuardarPublicacion?.(
        item.id,
        cambios
      );

      if (!resultado?.ok) {
        setError(
          resultado?.error || 'no se pudo guardar.'
        );
        return;
      }

      cancelarEdicion();

    } catch (error) {
      setError(error.message);
    }
  };

  // ============================================
  // ELIMINAR PUBLICACIONES
  // ============================================

  const eliminar = async item => {
    const confirmado = window.confirm(
      `¿quieres eliminar definitivamente «${item.titulo}»?`
    );

    if (!confirmado) return;

    try {
      const resultado = await onEliminarPublicacion?.(
        item.id
      );

      if (!resultado?.ok) {
        setError(
          resultado?.error ||
          'no se pudo eliminar la publicación.'
        );
        return;
      }

    } catch (error) {
      setError(error.message);
      return;
    }

    if (editando === String(item.id)) {
      cancelarEdicion();
    }
  };

  // ============================================
  // SIN EMPRESA
  // ============================================

  if (!empresaActiva) {
    return (
      <main className="ventas-container">
        <div className="ventas-box ventas-sin-empresa">
          <h1>mis ventas</h1>

          <p>
            primero necesitas registrar una empresa
            para administrar tus publicaciones.
          </p>

          <button
            type="button"
            className="btn-confirmar-pub"
            onClick={() =>
              onNavigate('registro-empresa')
            }
          >
            registrar empresa
          </button>
        </div>
      </main>
    );
  }

  // ============================================
  // INTERFAZ PRINCIPAL
  // ============================================

  return (
    <main className="ventas-container">
      <div className="ventas-box">

        <button type="button" className="btn-confirmar-pub" onClick={() => onNavigate("gestion-ventas")}>Gestionar pedidos y responder cotizaciones ↗</button>
        <header className="ventas-header-row">
          <div>
            <span className="ventas-sobre">
              {empresaActiva.nombreEmpresa}
            </span>

            <h1>mis ventas</h1>

            <p>
              administra tus productos y servicios,
              revisa las publicaciones y consulta
              tus ventas registradas.
            </p>
          </div>

          <div className="ventas-botones-nuevos">
            <button
              type="button"
              className="btn-confirmar-pub"
              onClick={() =>
                onNavigate('publicar-producto')
              }
            >
              + publicar producto
            </button>

            <button
              type="button"
              className="ventas-cancelar"
              onClick={() =>
                onNavigate('publicar-servicio')
              }
            >
              + publicar servicio
            </button>
          </div>
        </header>

        {/* ====================================== */}
        {/* LAS CUATRO ESTADÍSTICAS               */}
        {/* ====================================== */}

        <section className="ventas-resumen">

          <div className="ventas-estadistica">
            <span className="ventas-estadistica-icono">
              📦
            </span>

            <span>productos publicados</span>

            <strong>{productos.length}</strong>

            <small>
              productos actualmente en venta
            </small>
          </div>

          <div className="ventas-estadistica">
            <span className="ventas-estadistica-icono">
              🛍️
            </span>

            <span>productos vendidos</span>

            <strong>{productosVendidos}</strong>

            <small>
              unidades vendidas registradas
            </small>
          </div>

          <div className="ventas-estadistica">
            <span className="ventas-estadistica-icono">
              🛠️
            </span>

            <span>servicios publicados</span>

            <strong>{servicios.length}</strong>

            <small>
              servicios actualmente disponibles
            </small>
          </div>

          <div className="ventas-estadistica">
            <span className="ventas-estadistica-icono">
              ✅
            </span>

            <span>servicios vendidos</span>

            <strong>{serviciosVendidos}</strong>

            <small>
              contrataciones registradas
            </small>
          </div>

        </section>

        {/* ====================================== */}
        {/* ENCABEZADO DE PUBLICACIONES            */}
        {/* ====================================== */}

        <section className="ventas-publicaciones">

          <div className="ventas-publicaciones-titulo">
            <div>
              <h2>mis publicaciones</h2>

              <p>
                {publicacionesPropias.length}{' '}
                publicación(es) en tu empresa
              </p>
            </div>

            <button
              type="button"
              className="ventas-ir-empresa"
              onClick={() =>
                onNavigate('mi-empresa')
              }
            >
              ver mi empresa →
            </button>
          </div>

          {publicacionesPropias.length === 0 ? (

            <div className="ventas-vacio">
              <div className="ventas-vacio-icono">
                📦
              </div>

              <h3>todavía no hay publicaciones</h3>

              <p>
                puedes publicar tu primer producto
                o servicio desde los botones superiores.
              </p>
            </div>

          ) : (

            <div className="ventas-grid">

              {publicacionesPropias.map(item => {
                const abierto =
                  editando === String(item.id);

                const datos = abierto
                  ? borrador
                  : null;

                return (
                  <article
                    key={item.id}
                    className="card-publicado"
                  >

                    <div className="ventas-item-top">
                      <img
                        src={
                          item.img ||
                          item.imagenes?.[0] ||
                          '/productos/sin-imagen.svg'
                        }
                        alt={item.titulo}
                        onError={e => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src =
                            '/productos/sin-imagen.svg';
                        }}
                      />

                      <div className="ventas-item-info">
                        <span className="ventas-tipo">
                          {esServicio(item)
                            ? 'servicio'
                            : 'producto'}
                        </span>

                        <h3>{item.titulo}</h3>

                        <strong className="ventas-precio">
                          {dinero(item.precioNum)}
                        </strong>
                      </div>
                    </div>

                    {/* ================================= */}
                    {/* FORMULARIO DE EDICIÓN            */}
                    {/* ================================= */}

                    {abierto && datos ? (

                      <div className="ventas-campos">

                        <label className="ventas-completo">
                          nombre de la publicación

                          <input
                            value={datos.titulo}
                            onChange={e =>
                              cambiarCampo(
                                'titulo',
                                e.target.value
                              )
                            }
                          />
                        </label>

                        {!esServicio(item) && (
                          <label>
                            marca

                            <input
                              value={datos.marca}
                              onChange={e =>
                                cambiarCampo(
                                  'marca',
                                  e.target.value
                                )
                              }
                            />
                          </label>
                        )}

                        <label>
                          categoría

                          <input
                            value={datos.categoria}
                            onChange={e =>
                              cambiarCampo(
                                'categoria',
                                e.target.value
                              )
                            }
                          />
                        </label>

                        <label>
                          precio ($)

                          <input
                            type="number"
                            min="1"
                            step="1"
                            value={datos.precioNum}
                            onChange={e =>
                              cambiarCampo(
                                'precioNum',
                                e.target.value
                              )
                            }
                          />
                        </label>

                        <label>
                          {esServicio(item)
                            ? 'cupos disponibles'
                            : 'stock disponible'}

                          <input
                            type="number"
                            min="0"
                            step="1"
                            value={datos.stock}
                            onChange={e =>
                              cambiarCampo(
                                'stock',
                                e.target.value
                              )
                            }
                          />
                        </label>

                        <label>
                          oferta (%)

                          <input
                            placeholder="ej.: 10%"
                            value={datos.oferta}
                            onChange={e =>
                              cambiarCampo(
                                'oferta',
                                e.target.value
                              )
                            }
                          />
                        </label>

                        {esServicio(item) && (
                          <>
                            <label>
                              duración

                              <input
                                placeholder="ej.: 2 horas"
                                value={datos.tiempo}
                                onChange={e =>
                                  cambiarCampo(
                                    'tiempo',
                                    e.target.value
                                  )
                                }
                              />
                            </label>

                            <label>
                              modalidad

                              <select
                                value={datos.metodoEntrega}
                                onChange={e =>
                                  cambiarCampo(
                                    'metodoEntrega',
                                    e.target.value
                                  )
                                }
                              >
                                <option value="">
                                  seleccionar
                                </option>

                                <option value="Presencial">
                                  presencial
                                </option>

                                <option value="En línea">
                                  en línea
                                </option>

                                <option value="A domicilio">
                                  a domicilio
                                </option>

                                <option value="En local">
                                  en local
                                </option>
                              </select>
                            </label>
                          </>
                        )}

                        <label className="ventas-completo">
                          descripción

                          <textarea
                            rows={4}
                            value={datos.descripcion}
                            onChange={e =>
                              cambiarCampo(
                                'descripcion',
                                e.target.value
                              )
                            }
                          />
                        </label>

                        <label className="ventas-completo">
                          url de imagen (opcional)

                          <input
                            type="url"
                            placeholder="https://ejemplo.cl/imagen.jpg"
                            value={
                              datos.img.startsWith('data:')
                                ? ''
                                : datos.img
                            }
                            onChange={e =>
                              cambiarCampo(
                                'img',
                                e.target.value
                              )
                            }
                          />
                        </label>

                        {error && (
                          <p
                            className="ventas-error"
                            role="alert"
                          >
                            {error}
                          </p>
                        )}

                      </div>

                    ) : (

                      <div className="ventas-detalles">

                        <div>
                          <span>
                            {esServicio(item)
                              ? 'cupos disponibles'
                              : 'stock disponible'}
                          </span>

                          <strong>
                            {stockNumero(item.stock)}
                          </strong>
                        </div>

                        <div>
                          <span>oferta</span>

                          <strong>
                            {item.oferta || '0%'}
                          </strong>
                        </div>

                        <div>
                          <span>categoría</span>

                          <strong>
                            {item.categoria ||
                              item.seccion ||
                              'sin categoría'}
                          </strong>
                        </div>

                        {esServicio(item) &&
                          item.metodoEntrega && (
                            <div>
                              <span>modalidad</span>

                              <strong>
                                {item.metodoEntrega}
                              </strong>
                            </div>
                          )}

                      </div>

                    )}

                    {/* ================================= */}
                    {/* BOTONES DE EDICIÓN               */}
                    {/* ================================= */}

                    <div className="card-actions">

                      {abierto ? (
                        <>
                          <button
                            type="button"
                            className="ventas-cancelar"
                            onClick={cancelarEdicion}
                          >
                            cancelar
                          </button>

                          <button
                            type="button"
                            className="btn-confirmar-pub"
                            onClick={() =>
                              guardarCambios(item)
                            }
                          >
                            guardar cambios
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            type="button"
                            className="btn-eliminar-pub"
                            onClick={() =>
                              eliminar(item)
                            }
                          >
                            eliminar
                          </button>

                          <button
                            type="button"
                            className="btn-confirmar-pub"
                            onClick={() =>
                              empezarEdicion(item)
                            }
                          >
                            editar
                          </button>
                        </>
                      )}

                    </div>

                  </article>
                );
              })}

            </div>

          )}

        </section>

        <p className="ventas-nota">
          las publicaciones se cuentan desde el catálogo
          actual de tu empresa. las ventas se calculan
          a partir de las compras simuladas registradas
          durante esta sesión. si todavía no existen
          compras o contrataciones registradas,
          el contador correspondiente mostrará 0.
        </p>

      </div>
    </main>
  );
}
