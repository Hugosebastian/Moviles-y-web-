import { useMemo, useState } from 'react';
import { normalizarNombreEmpresa, normalizarRut, rutValido } from './EmpresaUtils';
import './RegistroEmpresa.css';

const REGIONES = [
  'Arica y Parinacota', 'Tarapacá', 'Antofagasta', 'Atacama', 'Coquimbo',
  'Valparaíso', 'Región Metropolitana', "Libertador General Bernardo O'Higgins",
  'Maule', 'Ñuble', 'Biobío', 'La Araucanía', 'Los Ríos', 'Los Lagos',
  'Aysén del General Carlos Ibáñez del Campo', 'Magallanes y de la Antártica Chilena'
];

const soloDigitos = valor => String(valor).replace(/\D/g, '');

export default function RegistroEmpresa({ onNavigate, usuarioActivo, empresasRegistradas = [], onEmpresaCreada }) {
  const [datos, setDatos] = useState({
    nombreEmpresa: '', runEmpresa: '', correo: usuarioActivo?.correo || '',
    telefono: usuarioActivo?.telefonoPersonal || '', region: 'Región Metropolitana',
    calle: '', numeroCasa: '', paginaWeb: ''
  });
  const [error, setError] = useState('');
  const [enviando, setEnviando] = useState(false);

  const duplicada = useMemo(() => {
    const nombre = normalizarNombreEmpresa(datos.nombreEmpresa);
    return nombre.length > 0 && empresasRegistradas.some(empresa =>
      normalizarNombreEmpresa(empresa.nombreEmpresa) === nombre);
  }, [datos.nombreEmpresa, empresasRegistradas]);

  const cambiar = (campo, valor) => {
    setError('');
    setDatos(actual => ({ ...actual, [campo]: valor }));
  };

  const guardar = async (evento) => {
    evento.preventDefault();
    if (enviando) return;
    if (!usuarioActivo?.run) {
      setError('inicia sesión para registrar una empresa.');
      return;
    }
    const nombreEmpresa = datos.nombreEmpresa.trim();
    const runEmpresa = normalizarRut(datos.runEmpresa);
    const telefono = soloDigitos(datos.telefono);
    const numeroCasa = datos.numeroCasa.trim();
    if (nombreEmpresa.length < 3 || nombreEmpresa.length > 80) {
      setError('el nombre de la empresa debe tener entre 3 y 80 caracteres.'); return;
    }
    if (duplicada) { setError('ya existe una empresa registrada con ese nombre.'); return; }
    if (!rutValido(runEmpresa)) { setError('el rut ingresado no es válido. revisa el dígito verificador.'); return; }
    if (!/^\S+@\S+\.\S+$/.test(datos.correo.trim())) { setError('ingresa un correo válido.'); return; }
    if (telefono.length < 8 || telefono.length > 11) { setError('ingresa un teléfono de 8 a 11 dígitos.'); return; }
    if (!datos.calle.trim() || !numeroCasa) { setError('completa la calle y el número de la dirección.'); return; }
    if (datos.paginaWeb.trim()) {
      try {
        const web = new URL(datos.paginaWeb.trim());
        if (!['https:', 'http:'].includes(web.protocol)) throw new Error('protocolo');
      } catch { setError('la página web debe comenzar con https:// o http://'); return; }
    }
    setEnviando(true);

    try {
      const resultado = await onEmpresaCreada?.({
        nombreEmpresa,
        runEmpresa,
        correo: datos.correo.trim(),
        telefono,
        region: datos.region,
        calle: datos.calle.trim(),
        numeroCasa,
        direccion: `${datos.region}, ${datos.calle.trim()} #${numeroCasa}`,
        paginaWeb: datos.paginaWeb.trim()
      });

      if (!resultado?.ok) {
        setError(
          resultado?.error || 'no se pudo registrar la empresa.'
        );
      }

    } catch (error) {
      setError(
        error.message || 'no se pudo registrar la empresa.'
      );

    } finally {
      setEnviando(false);
    }

      // App.jsx abre automáticamente el panel cuando el registro termina.
  };

  if (!usuarioActivo) {
    return <main className="empresa-container"><div className="empresa-box">
      <h2>registro de empresa</h2><p>inicia sesión antes de crear una empresa.</p>
      <button className="btn-crear-empresa" onClick={() => onNavigate('login')}>ir al inicio de sesión</button>
    </div></main>;
  }

  return (
    <main className="empresa-container">
      <div className="empresa-box">
        <div className="empresa-encabezado">
          <span className="empresa-insignia">🏬 cuenta de emprendedor</span>
          <h1 className="empresa-title">crea tu empresa</h1>
          <p>registra tu negocio para publicar productos o servicios y administrar tus ventas desde tu perfil.</p>
        </div>
        <div className="empresa-propietario">
          <span>responsable de la empresa</span>
          <strong>{usuarioActivo.nombreCompleto || usuarioActivo.nombre || usuarioActivo.run}</strong>
          <small>esta empresa quedará asociada a tu cuenta.</small>
        </div>
        <form onSubmit={guardar} noValidate>
          <div className="empresa-grid">
            <div className="form-group-empresa empresa-ancho">
              <label htmlFor="em-nombre">nombre de la empresa *</label>
              <input id="em-nombre" autoComplete="organization" maxLength={80} required
                placeholder="ej.: Mi Tienda" value={datos.nombreEmpresa}
                aria-invalid={duplicada}
                onChange={e => cambiar('nombreEmpresa', e.target.value)} />
              {duplicada && <small className="empresa-error">este nombre ya está registrado. elige otro.</small>}
              <small>el nombre debe ser único, sin importar mayúsculas, espacios o tildes.</small>
            </div>
            <div className="form-group-empresa">
              <label htmlFor="em-rut">rut de la empresa o titular *</label>
              <input id="em-rut" maxLength={12} required placeholder="12.345.678-5"
                value={datos.runEmpresa} onChange={e => cambiar('runEmpresa', e.target.value)} />
            </div>
            <div className="form-group-empresa">
              <label htmlFor="em-correo">correo de contacto *</label>
              <input id="em-correo" type="email" required autoComplete="email"
                value={datos.correo} onChange={e => cambiar('correo', e.target.value)} />
            </div>
            <div className="form-group-empresa">
              <label htmlFor="em-telefono">teléfono de contacto *</label>
              <input id="em-telefono" type="tel" inputMode="numeric" required maxLength={16}
                value={datos.telefono} onChange={e => cambiar('telefono', e.target.value)}
                placeholder="912345678" />
            </div>
            <div className="form-group-empresa">
              <label htmlFor="em-region">región *</label>
              <select id="em-region" value={datos.region} onChange={e => cambiar('region', e.target.value)}>
                {REGIONES.map(region => <option key={region} value={region}>{region}</option>)}
              </select>
            </div>
            <div className="form-group-empresa">
              <label htmlFor="em-calle">calle *</label>
              <input id="em-calle" required maxLength={100} placeholder="ej.: Avenida Central"
                value={datos.calle} onChange={e => cambiar('calle', e.target.value)} />
            </div>
            <div className="form-group-empresa">
              <label htmlFor="em-numero">número *</label>
              <input id="em-numero" required maxLength={20} placeholder="123"
                value={datos.numeroCasa} onChange={e => cambiar('numeroCasa', e.target.value)} />
            </div>
            <div className="form-group-empresa empresa-ancho">
              <label htmlFor="em-web">página web (opcional)</label>
              <input id="em-web" type="url" placeholder="https://mitienda.cl"
                value={datos.paginaWeb} onChange={e => cambiar('paginaWeb', e.target.value)} />
            </div>
          </div>
          {error && <div className="empresa-aviso-error" role="alert">{error}</div>}
          <div className="empresa-acciones">
            <button type="button" className="empresa-cancelar" onClick={() => onNavigate('principal')}>cancelar</button>
            <button type="submit" className="btn-crear-empresa" disabled={enviando || duplicada}>
              {enviando ? 'registrando...' : 'crear empresa'}
            </button>
          </div>
        </form>
        <p className="empresa-nota">* campos obligatorios. los datos se guardan en PostgreSQL. el registro no verifica la existencia legal de la empresa.</p>
      </div>
    </main>
  );
}