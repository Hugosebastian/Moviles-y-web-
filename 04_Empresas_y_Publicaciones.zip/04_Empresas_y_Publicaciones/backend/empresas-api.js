
const crypto = require('node:crypto');

const ORIGEN =
  process.env.FRONTEND_ORIGIN || 'http://localhost:5173';

function normalizarRut(valor) {
  return String(valor || '')
    .replace(/[.\s]/g, '')
    .toUpperCase();
}

function rutValido(valor) {
  const rut = normalizarRut(valor);
  const partes = rut.match(/^(\d{1,8})-([0-9K])$/);

  if (!partes) return false;

  let suma = 0;
  let factor = 2;

  for (let i = partes[1].length - 1; i >= 0; i--) {
    suma += Number(partes[1][i]) * factor;
    factor = factor === 7 ? 2 : factor + 1;
  }

  const resultado = 11 - (suma % 11);
  const dv =
    resultado === 11 ? '0' :
    resultado === 10 ? 'K' :
    String(resultado);

  return partes[2] === dv;
}

function normalizarNombre(valor) {
  return String(valor || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('es-CL')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

function convertirEmpresa(fila) {
  if (!fila) return null;

  return {
    id: String(fila.id),
    propietarioId: String(fila.propietario_id),
    propietarioRun: fila.propietario_run,
    nombreEmpresa: fila.nombre_empresa,
    runEmpresa: fila.rut_empresa,
    correo: fila.correo || '',
    telefono: fila.telefono || '',
    region: fila.region || '',
    calle: fila.calle || '',
    numeroCasa: fila.numero_casa || '',
    direccion: [
      fila.region,
      `${fila.calle || ''} #${fila.numero_casa || ''}`
    ].filter(Boolean).join(', '),
    paginaWeb: fila.pagina_web || '',
    fechaCreacion: fila.fecha_registro
  };
}

const CAMPOS = `
  e.id,
  e.propietario_id,
  u.run AS propietario_run,
  e.nombre_empresa,
  e.rut_empresa,
  e.correo,
  e.telefono,
  e.region,
  e.calle,
  e.numero_casa,
  e.pagina_web,
  e.fecha_registro
`;

async function empresaDelUsuario(db, usuarioId) {
  const resultado = await db.query(
    `SELECT ${CAMPOS}
     FROM empresas e
     JOIN usuarios u ON u.id = e.propietario_id
     WHERE e.propietario_id = $1 AND e.activa = TRUE
     LIMIT 1`,
    [usuarioId]
  );

  return convertirEmpresa(resultado.rows[0]);
}

function validarDatos(datos, nuevo) {
  const nombreEmpresa = String(
    datos.nombreEmpresa || ''
  ).trim().replace(/\s+/g, ' ');

  const runEmpresa = normalizarRut(datos.runEmpresa);

  const correo = String(
    datos.correo || ''
  ).trim().toLowerCase();

  const telefono = String(
    datos.telefono || ''
  ).replace(/\D/g, '');

  const region = String(datos.region || '').trim();
  const calle = String(datos.calle || '').trim();
  const numeroCasa = String(datos.numeroCasa || '').trim();
  const paginaWeb = String(datos.paginaWeb || '').trim();

  if (
    nombreEmpresa.length < 3 ||
    nombreEmpresa.length > 80
  ) {
    return {
      error: 'el nombre debe tener entre 3 y 80 caracteres.'
    };
  }

  if (nuevo && !rutValido(runEmpresa)) {
    return {
      error: 'el rut de la empresa no es válido.'
    };
  }

  if (
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo) ||
    correo.length > 150
  ) {
    return { error: 'ingresa un correo válido.' };
  }

  if (
    telefono.length < 8 ||
    telefono.length > 11
  ) {
    return {
      error: 'ingresa un teléfono de 8 a 11 dígitos.'
    };
  }

  if (
    !region ||
    region.length > 100 ||
    !calle ||
    calle.length > 100 ||
    !numeroCasa ||
    numeroCasa.length > 20
  ) {
    return {
      error: 'completa correctamente la región, calle y número.'
    };
  }

  if (paginaWeb) {
    try {
      const url = new URL(paginaWeb);

      if (
        !['https:', 'http:'].includes(url.protocol) ||
        paginaWeb.length > 250
      ) {
        return {
          error: 'ingresa una página web válida.'
        };
      }
    } catch {
      return {
        error: 'la página web debe comenzar con https:// o http://.'
      };
    }
  }

  return {
    nombreEmpresa,
    runEmpresa,
    correo,
    telefono,
    region,
    calle,
    numeroCasa,
    paginaWeb
  };
}

function registrarRutasEmpresas(app, pool) {

  async function autenticar(req, res, next) {
    const cookie = (req.headers.cookie || '')
      .split(';')
      .map(x => x.trim())
      .find(x => x.startsWith('cv_sesion='));

    const token = cookie
      ? cookie.slice('cv_sesion='.length)
      : '';

    if (!/^[a-f0-9]{64}$/.test(token)) {
      return res.status(401).json({
        error: 'inicia sesión nuevamente.'
      });
    }

    try {
      const hash = crypto
        .createHash('sha256')
        .update(token)
        .digest('hex');

      const resultado = await pool.query(
        `SELECT s.usuario_id
         FROM sesiones s
         JOIN usuarios u ON u.id = s.usuario_id
         WHERE s.token_hash = $1
           AND s.expira_en > NOW()
           AND u.estado_cuenta = 'Activa'`,
        [hash]
      );

      if (!resultado.rows.length) {
        return res.status(401).json({
          error: 'la sesión ya no es válida.'
        });
      }

      req.usuarioId = resultado.rows[0].usuario_id;
      next();

    } catch (error) {
      console.error(
        'error de autenticación de empresa:',
        error
      );

      res.status(500).json({
        error: 'error de autenticación.'
      });
    }
  }

  // Proteger solicitudes que modifican datos.
  app.use('/api/empresas', (req, res, next) => {
    if (
      !['GET', 'HEAD', 'OPTIONS'].includes(req.method) &&
      req.headers.origin !== ORIGEN
    ) {
      return res.status(403).json({
        error: 'origen no permitido.'
      });
    }

    next();
  });

  // Consultar la empresa del usuario conectado.
  app.get(
    '/api/empresas/mia',
    autenticar,
    async (req, res) => {
      try {
        const empresa = await empresaDelUsuario(
          pool,
          req.usuarioId
        );

        res.json({ empresa });

      } catch (error) {
        console.error(
          'error al consultar empresa:',
          error
        );

        res.status(500).json({
          error: 'no se pudo consultar la empresa.'
        });
      }
    }
  );

  // Registrar empresa.
  app.post(
    '/api/empresas',
    autenticar,
    async (req, res) => {
      const datos = validarDatos(
        req.body || {},
        true
      );

      if (datos.error) {
        return res.status(400).json({
          error: datos.error
        });
      }

      const cliente = await pool.connect()
        .catch(() => null);

      if (!cliente) {
        return res.status(500).json({
          error: 'base de datos no disponible.'
        });
      }

      try {
        await cliente.query('BEGIN');

        // Impedir dos registros simultáneos
        // para el mismo propietario.
        await cliente.query(
          `SELECT id
           FROM usuarios
           WHERE id = $1
           FOR UPDATE`,
          [req.usuarioId]
        );

        const propia = await empresaDelUsuario(
          cliente,
          req.usuarioId
        );

        if (propia) {
          await cliente.query('ROLLBACK');

          return res.status(409).json({
            error: 'tu cuenta ya tiene una empresa registrada.'
          });
        }

        const existentes = await cliente.query(
          `SELECT nombre_empresa, rut_empresa
           FROM empresas`
        );

        if (
          existentes.rows.some(
            x =>
              normalizarNombre(x.nombre_empresa) ===
              normalizarNombre(datos.nombreEmpresa)
          )
        ) {
          await cliente.query('ROLLBACK');

          return res.status(409).json({
            error: 'ese nombre de empresa ya está registrado.'
          });
        }

        if (
          existentes.rows.some(
            x =>
              normalizarRut(x.rut_empresa) ===
              datos.runEmpresa
          )
        ) {
          await cliente.query('ROLLBACK');

          return res.status(409).json({
            error: 'ese rut de empresa ya está registrado.'
          });
        }

        await cliente.query(
          `INSERT INTO empresas (
            propietario_id,
            nombre_empresa,
            rut_empresa,
            correo,
            telefono,
            region,
            calle,
            numero_casa,
            pagina_web
          )
          VALUES (
            $1, $2, $3, $4, $5,
            $6, $7, $8, $9
          )`,
          [
            req.usuarioId,
            datos.nombreEmpresa,
            datos.runEmpresa,
            datos.correo,
            datos.telefono,
            datos.region,
            datos.calle,
            datos.numeroCasa,
            datos.paginaWeb
          ]
        );

        // Agregar el rol Emprendedor
        // si todavía no lo tiene.
        await cliente.query(
          `INSERT INTO usuario_roles (
            usuario_id,
            rol_id
          )
          SELECT $1, r.id
          FROM roles r
          WHERE r.nombre = 'Emprendedor'
            AND NOT EXISTS (
              SELECT 1
              FROM usuario_roles ur
              WHERE ur.usuario_id = $1
                AND ur.rol_id = r.id
            )`,
          [req.usuarioId]
        );

        const empresa = await empresaDelUsuario(
          cliente,
          req.usuarioId
        );

        await cliente.query('COMMIT');

        res.status(201).json({ empresa });

      } catch (error) {
        await cliente.query('ROLLBACK')
          .catch(() => {});

        console.error(
          'error al crear empresa:',
          error
        );

        res.status(
          error.code === '23505' ? 409 : 500
        ).json({
          error: error.code === '23505'
            ? 'la empresa ya existe o el propietario ya tiene una.'
            : 'no se pudo registrar la empresa.'
        });

      } finally {
        cliente.release();
      }
    }
  );

  // Modificar solamente la empresa propia.
  app.patch(
    '/api/empresas/mia',
    autenticar,
    async (req, res) => {
      const datos = validarDatos(
        req.body || {},
        false
      );

      if (datos.error) {
        return res.status(400).json({
          error: datos.error
        });
      }

      const cliente = await pool.connect()
        .catch(() => null);

      if (!cliente) {
        return res.status(500).json({
          error: 'base de datos no disponible.'
        });
      }

      try {
        await cliente.query('BEGIN');

        const propia = await empresaDelUsuario(
          cliente,
          req.usuarioId
        );

        if (!propia) {
          await cliente.query('ROLLBACK');

          return res.status(404).json({
            error: 'no tienes una empresa registrada.'
          });
        }

        const existentes = await cliente.query(
          `SELECT id, nombre_empresa
           FROM empresas
           WHERE id <> $1`,
          [propia.id]
        );

        if (
          existentes.rows.some(
            x =>
              normalizarNombre(x.nombre_empresa) ===
              normalizarNombre(datos.nombreEmpresa)
          )
        ) {
          await cliente.query('ROLLBACK');

          return res.status(409).json({
            error: 'ese nombre de empresa ya está registrado.'
          });
        }

        await cliente.query(
          `UPDATE empresas
           SET nombre_empresa = $1,
               correo = $2,
               telefono = $3,
               region = $4,
               calle = $5,
               numero_casa = $6,
               pagina_web = $7
           WHERE propietario_id = $8`,
          [
            datos.nombreEmpresa,
            datos.correo,
            datos.telefono,
            datos.region,
            datos.calle,
            datos.numeroCasa,
            datos.paginaWeb,
            req.usuarioId
          ]
        );

        const empresa = await empresaDelUsuario(
          cliente,
          req.usuarioId
        );

        await cliente.query('COMMIT');

        res.json({ empresa });

      } catch (error) {
        await cliente.query('ROLLBACK')
          .catch(() => {});

        console.error(
          'error al editar empresa:',
          error
        );

        res.status(
          error.code === '23505' ? 409 : 500
        ).json({
          error: error.code === '23505'
            ? 'ese nombre de empresa ya está registrado.'
            : 'no se pudo actualizar la empresa.'
        });

      } finally {
        cliente.release();
      }
    }
  );
}

module.exports = {
  registrarRutasEmpresas
};
