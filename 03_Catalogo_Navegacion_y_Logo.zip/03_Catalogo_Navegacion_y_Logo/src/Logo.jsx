import { useState } from 'react';
export default function Logo(props) {
  const [respaldo, setRespaldo] = useState(false);
  return <img {...props} src={respaldo ? '/favicon.svg' : '/logo.svg'} alt={props.alt || 'Compra y Venta'} onError={() => setRespaldo(true)} />;
}
