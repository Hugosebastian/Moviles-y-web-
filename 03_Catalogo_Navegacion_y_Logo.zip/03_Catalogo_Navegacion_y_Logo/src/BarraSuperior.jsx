import Logo from './Logo';
import { useEffect, useMemo, useRef, useState } from 'react';
import './BarraSuperior.css';
import { CATEGORIAS, SECCIONES_PUBLICAR, correspondeCategoria } from './Catalogo';

// Las categorías principales son exactamente las mismas de Principal.jsx.
// Se agregan las subcategorías del formulario para mantenerlas accesibles.
const CATEGORIAS_PRODUCTOS = (() => {
  const opciones = [
    ...CATEGORIAS.map(categoria => ({ id: categoria.id, nombre: categoria.titulo })),
    ...SECCIONES_PUBLICAR.map(seccion => ({ id: seccion.id, nombre: seccion.titulo }))
  ];
  return opciones.filter((opcion, indice) =>
    opciones.findIndex(otra => otra.id === opcion.id) === indice
  );
})();

// Categorías habituales de servicios ofrecidos en marketplaces.
// No son publicaciones ficticias: el contador parte en cero.
const CATEGORIAS_SERVICIOS = [
  ['instalacion-electrodomesticos', 'instalación de electrodomésticos'],
  ['armado-muebles', 'armado e instalación de muebles'],
  ['soporte-computacion', 'soporte técnico y computación'],
  ['reparacion-celulares', 'reparación de celulares'],
  ['electricidad', 'electricidad e iluminación'],
  ['gasfiteria', 'gasfitería y plomería'],
  ['limpieza', 'limpieza del hogar'],
  ['pintura', 'pintura y mantención'],
  ['jardineria', 'jardinería'],
  ['mudanzas', 'mudanzas y fletes'],
  ['clases', 'clases particulares'],
  ['diseno', 'diseño y servicios digitales'],
  ['mascotas-servicios', 'cuidado de mascotas'],
  ['otros-servicios', 'otros servicios']
].map(([id, nombre]) => ({ id, nombre }));

const normalizar = valor => String(valor ?? '')
  .normalize('NFD')
  .replace(/[\u0300-\u036f]/g, '')
  .toLocaleLowerCase('es-CL')
  .trim();

const esServicio = item => normalizar(item?.tipo) === 'servicio';

// Compatibilidad con publicaciones antiguas que guardaban categorías libres.
const ALIAS_SERVICIOS = {
  'instalacion': 'instalacion-electrodomesticos',
  'electrodomesticos': 'instalacion-electrodomesticos',
  'armado de muebles': 'armado-muebles',
  'muebles': 'armado-muebles',
  'reparacion': 'soporte-computacion',
  'computacion': 'soporte-computacion',
  'reparacion de computadores': 'soporte-computacion',
  'limpieza de computadores': 'soporte-computacion',
  'reparacion de celulares': 'reparacion-celulares',
  'electricista': 'electricidad',
  'electricidad e iluminacion': 'electricidad',
  'gasfiter': 'gasfiteria',
  'plomeria': 'gasfiteria',
  'limpieza del hogar': 'limpieza',
  'aseo': 'limpieza',
  'pintura y mantencion': 'pintura',
  'jardin': 'jardineria',
  'fletes': 'mudanzas',
  'clases particulares': 'clases',
  'educacion': 'clases',
  'diseno grafico': 'diseno',
  'servicios digitales': 'diseno',
  'cuidado de mascotas': 'mascotas-servicios'
};

function categoriaServicio(item) {
  const valor = normalizar(item?.categoria);
  const conocida = CATEGORIAS_SERVICIOS.find(
    categoria => valor === normalizar(categoria.id) || valor === normalizar(categoria.nombre)
  );
  return conocida?.id || ALIAS_SERVICIOS[valor] || valor;
}

function Icono({ tipo, size = 23 }) {
  const dibujos = {
    volver: <><path d="M19 12H5" /><path d="m12 19-7-7 7-7" /></>,
    menu: <path d="M4 6h16M4 12h16M4 18h16" />,
    buscar: <><circle cx="10.8" cy="10.8" r="7" /><path d="m16 16 5 5" /></>,
    corazon: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z" />,
    carrito: <><circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" /><path d="M1 1h4l2.4 13.3a2 2 0 0 0 2 1.7h9.6a2 2 0 0 0 2-1.7L23 6H6" /></>,
    usuario: <><circle cx="12" cy="8" r="4" /><path d="M4 21v-2a8 8 0 0 1 16 0v2" /></>,
    cerrar: <path d="M18 6 6 18M6 6l12 12" />,
    abajo: <path d="m6 9 6 6 6-6" />,
    ayuda: <><circle cx="12" cy="12" r="9" /><path d="M9.5 9a2.5 2.5 0 1 1 4.3 1.7c-1.2 1.1-1.8 1.4-1.8 3" /><path d="M12 17h.01" /></>
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round"
      strokeLinejoin="round" aria-hidden="true">
      {dibujos[tipo]}
    </svg>
  );
}

const AYUDAS = [
  {
    titulo: '¿cómo comprar?',
    respuesta: 'busca una publicación, revisa sus detalles y agrégala al carrito. sigue los pasos de compra disponibles en la plataforma. las compras actuales son simuladas.'
  },
  {
    titulo: '¿cómo publicar?',
    respuesta: 'abre perfil → empresa. si todavía no tienes una empresa, regístrala. después selecciona publicar producto o publicar servicio y completa los campos obligatorios.'
  },
  {
    titulo: '¿cómo revisar mis ventas?',
    respuesta: 'abre perfil → mis ventas. ahí podrás revisar, editar o eliminar publicaciones y consultar los contadores de ventas registradas en la sesión.'
  },
  {
    titulo: '¿qué hago si tengo un problema?',
    respuesta: 'revisa los datos de la publicación y utiliza la opción de mensajes para consultar al vendedor cuando esté disponible. todavía no hay un sistema de soporte externo conectado.'
  }
];

export default function BarraSuperior({
  vistaActual,
  onNavigate,
  onVolver,
  onCerrarSesion,
  onVerDetalle,
  onSeleccionarCategoria,
  publicaciones = [],
  carrito = [],
  deseos = [],
  usuarioActivo,
  empresaActiva,
  usuarios = []
}) {
  const [menuAbierto, setMenuAbierto] = useState(false);
  const [perfilAbierto, setPerfilAbierto] = useState(false);
  const [busqueda, setBusqueda] = useState('');
  const [resultadosAbiertos, setResultadosAbiertos] = useState(false);
  const [tipoCategorias, setTipoCategorias] = useState('productos');
  const [ayudaAbierta, setAyudaAbierta] = useState(false);
  const [preguntaAbierta, setPreguntaAbierta] = useState(null);
  const perfilRef = useRef(null);
  const buscarRef = useRef(null);

  const esAdmin = Array.isArray(usuarioActivo?.tipoPerfil)
    && usuarioActivo.tipoPerfil.includes('Administrador')
    && usuarioActivo.estadoAdmin === 'Aprobado'
    && usuarioActivo.estadoCuenta !== 'Bloqueada';

  // Una solicitud pendiente todavía NO concede permisos de administrador.
  const cantidadSolicitudes = usuarios.filter(usuario =>
    usuario.estadoAdmin === 'Pendiente'
  ).length;

  const buscables = useMemo(() => {
    const unicos = new Map();
    [...publicaciones, ...carrito, ...deseos].forEach((item, indice) => {
      if (!item) return;
      const clave = `${item.id ?? item.titulo ?? indice}:${item.empresaId ?? item.vendedorId ?? ''}`;
      if (!unicos.has(clave)) unicos.set(clave, item);
    });
    return [...unicos.values()];
  }, [publicaciones, carrito, deseos]);

  const resultados = useMemo(() => {
    const palabras = normalizar(busqueda).split(/\s+/).filter(Boolean);
    if (!palabras.length) return [];
    return buscables.filter(item => {
      const contenido = normalizar([
        item.titulo, item.descripcion, item.marca, item.categoria,
        item.seccion, item.empresaNombre, item.vendedor, item.tipo
      ].filter(Boolean).join(' '));
      return palabras.every(palabra => contenido.includes(palabra));
    });
  }, [busqueda, buscables]);

  const categoriasProductos = useMemo(() => {
    const resultado = [...CATEGORIAS_PRODUCTOS];
    const ids = new Set(resultado.map(item => normalizar(item.id)));
    publicaciones.filter(item => !esServicio(item)).forEach(item => {
      const id = normalizar(item.seccion || item.categoria);
      if (id && !ids.has(id)) {
        resultado.push({ id, nombre: String(item.categoria || item.seccion) });
        ids.add(id);
      }
    });
    return resultado;
  }, [publicaciones]);

  const categoriasServicios = useMemo(() => {
    const resultado = [...CATEGORIAS_SERVICIOS];
    const ids = new Set(resultado.map(item => item.id));
    publicaciones.filter(esServicio).forEach(item => {
      const id = categoriaServicio(item);
      if (id && !ids.has(id)) {
        resultado.push({ id, nombre: String(item.categoria || id) });
        ids.add(id);
      }
    });
    return resultado;
  }, [publicaciones]);

  const categoriasVisibles = tipoCategorias === 'productos'
    ? categoriasProductos : categoriasServicios;

  const perteneceACategoria = (item, categoriaId, tipo) => {
    if (tipo === 'servicios') {
      return esServicio(item) && categoriaServicio(item) === categoriaId;
    }
    return !esServicio(item) && (
      correspondeCategoria(item, categoriaId) ||
      normalizar(item.categoria) === normalizar(categoriaId)
    );
  };

  const contarCategoria = categoria => publicaciones.filter(item =>
    perteneceACategoria(item, categoria.id, tipoCategorias)
  ).length;

  // No mostramos una lista de productos dentro del menú: abrimos el mismo
  // resultado filtrado de la página Principal.
  const abrirCategoria = categoria => {
    setMenuAbierto(false);
    setAyudaAbierta(false);
    setResultadosAbiertos(false);
    onSeleccionarCategoria?.(tipoCategorias, categoria.id, categoria.nombre);
  };

  useEffect(() => {
    const cerrarFuera = evento => {
      if (perfilRef.current && !perfilRef.current.contains(evento.target)) {
        setPerfilAbierto(false);
      }
      if (buscarRef.current && !buscarRef.current.contains(evento.target)) {
        setResultadosAbiertos(false);
      }
    };
    const cerrarEscape = evento => {
      if (evento.key === 'Escape') {
        setMenuAbierto(false);
        setPerfilAbierto(false);
        setResultadosAbiertos(false);
      }
    };
    document.addEventListener('mousedown', cerrarFuera);
    document.addEventListener('keydown', cerrarEscape);
    return () => {
      document.removeEventListener('mousedown', cerrarFuera);
      document.removeEventListener('keydown', cerrarEscape);
    };
  }, []);

  useEffect(() => {
    setMenuAbierto(false);
    setPerfilAbierto(false);
    setResultadosAbiertos(false);
  }, [vistaActual]);

  useEffect(() => {
    if (!menuAbierto) return undefined;
    const anterior = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = anterior; };
  }, [menuAbierto]);

  const ir = vista => {
    setMenuAbierto(false);
    setPerfilAbierto(false);
    setResultadosAbiertos(false);
    onNavigate?.(vista);
  };

  const volver = () => {
    if (menuAbierto) { setMenuAbierto(false); return; }
    setMenuAbierto(false);
    setPerfilAbierto(false);
    setResultadosAbiertos(false);
    onVolver?.();
  };

  const abrirPublicacion = item => {
    setMenuAbierto(false);
    setPerfilAbierto(false);
    setResultadosAbiertos(false);
    setBusqueda('');
    onVerDetalle?.(item);
  };

  const abrirMenu = () => {
    setMenuAbierto(true);
    setPerfilAbierto(false);
    setResultadosAbiertos(false);
    setAyudaAbierta(false);
    setPreguntaAbierta(null);
  };

  const opcion = (etiqueta, vista, icono) => (
    <button type="button" className="bs-opcion" onClick={() => ir(vista)}>
      <span className="bs-opcion-icono" aria-hidden="true">{icono}</span>
      <span>{etiqueta}</span>
      <span className="bs-flecha-opcion" aria-hidden="true">›</span>
    </button>
  );

  const cantidadCarrito = carrito.reduce((total, item) =>
    total + (Number(item.cantidad) || 1), 0
  );

  return (
    <>
      <header className="bs-barra">
        <div className="bs-interior">
          <div className="bs-izquierda">
            <button type="button" className="bs-icono bs-volver" onClick={volver}
              aria-label="volver atrás" title="volver atrás">
              <Icono tipo="volver" size={25} />
            </button>
            <button type="button" className="bs-logo" onClick={() => ir('principal')}
              aria-label="ir al inicio" title="inicio">
              <Logo
                alt="" onError={e => { e.currentTarget.onerror = null; e.currentTarget.src = '/favicon.svg'; }} />
            </button>
            <button type="button" className="bs-menu-boton" onClick={abrirMenu}
              aria-label="abrir menú">
              <Icono tipo="menu" size={23} />
              <span>menú</span>
            </button>
          </div>

          <div className="bs-centro" ref={buscarRef}>
            <form className="bs-buscador" role="search" onSubmit={evento => {
              evento.preventDefault();
              if (!busqueda.trim()) return;
              setResultadosAbiertos(true);
              if (resultados.length === 1) abrirPublicacion(resultados[0]);
            }}>
              <input type="search" value={busqueda} onChange={e => {
                setBusqueda(e.target.value);
                setResultadosAbiertos(Boolean(e.target.value.trim()));
              }} onFocus={() => { if (busqueda.trim()) setResultadosAbiertos(true); }}
                placeholder="buscar productos, servicios, marcas y más..."
                aria-label="buscar publicaciones" />
              <button type="submit" aria-label="buscar"><Icono tipo="buscar" size={22} /></button>
            </form>
            {resultadosAbiertos && busqueda.trim() && (
              <div className="bs-resultados" role="region" aria-label="resultados de búsqueda">
                <div className="bs-resultados-titulo">resultados de búsqueda ({resultados.length})</div>
                {resultados.length ? resultados.map((item, indice) => (
                  <button type="button" className="bs-resultado"
                    key={`${item.id ?? indice}-${indice}`} onClick={() => abrirPublicacion(item)}>
                    <img src={item.img || item.imagenes?.[0] || '/productos/sin-imagen.svg'}
                      alt="" onError={e => { e.currentTarget.onerror = null; e.currentTarget.src = '/productos/sin-imagen.svg'; }} />
                    <span className="bs-resultado-textos">
                      <strong>{item.titulo}</strong>
                      <small>{item.empresaNombre || item.vendedor || item.tipo || 'publicación'}</small>
                    </span>
                    <span aria-hidden="true">›</span>
                  </button>
                )) : <p className="bs-sin-resultados">no encontramos publicaciones con ese nombre.</p>}
              </div>
            )}
          </div>

          <div className="bs-derecha">
            <button type="button" className="bs-icono bs-con-contador" onClick={() => ir('deseos')}
              aria-label="lista de deseos" title="lista de deseos">
              <Icono tipo="corazon" size={26} />
              {deseos.length > 0 && <span className="bs-contador">{deseos.length}</span>}
            </button>
            <button type="button" className="bs-icono bs-con-contador" onClick={() => ir('carrito')}
              aria-label="carrito" title="carrito">
              <Icono tipo="carrito" size={25} />
              {cantidadCarrito > 0 && <span className="bs-contador">{cantidadCarrito}</span>}
            </button>
            <div className="bs-perfil" ref={perfilRef}>
              <button type="button" className="bs-perfil-boton" aria-label="opciones de perfil"
                aria-expanded={perfilAbierto} onClick={() => {
                  setPerfilAbierto(actual => !actual);
                  setResultadosAbiertos(false);
                }}>
                <span className="bs-avatar"><Icono tipo="usuario" size={23} /></span>
                <Icono tipo="abajo" size={15} />
              </button>
              {perfilAbierto && (
                <div className="bs-perfil-menu">
                  {opcion('mi perfil', 'perfil', '👤')}
                  {opcion('mis compras', 'mis-compras', '🛍')}
                  {opcion('mis mensajes', 'chat', '💬')}
                  {esAdmin && (
                    <button type="button" className="bs-opcion" onClick={() => ir('admin-panel')}>
                      <span className="bs-opcion-icono">🛠</span>
                      <span>panel administrador</span>
                      {cantidadSolicitudes > 0 && <span className="bs-pendientes">{cantidadSolicitudes} pendiente(s)</span>}
                    </button>
                  )}
                  {opcion('empresa', empresaActiva ? 'mi-empresa' : 'registro-empresa', '🏬')}
                  {empresaActiva && opcion('mis ventas', 'mis-ventas', '📊')}
                  <div className="bs-separador" />
                  <button type="button" className="bs-salir" onClick={() => {
                    setPerfilAbierto(false);
                    onCerrarSesion?.();
                  }}><span aria-hidden="true">⎋</span>cerrar sesión</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {menuAbierto && (
        <div className="bs-velo" onMouseDown={() => setMenuAbierto(false)}>
          <aside className="bs-panel-lateral bs-categorias-panel" aria-label="menú de categorías"
            onMouseDown={e => e.stopPropagation()}>
            <div className="bs-lateral-cabecera">
              <strong>menú</strong>
              <button type="button" aria-label="cerrar menú" onClick={() => setMenuAbierto(false)}>
                <Icono tipo="cerrar" size={24} />
              </button>
            </div>

            <button type="button" className="bs-categorias-atras"
              style={{ margin: '8px 20px 0', alignSelf: 'flex-start' }}
              onClick={() => setMenuAbierto(false)}>
              ← volver
            </button>
            <div className="bs-menu-cuerpo">
              {ayudaAbierta ? (
                <section className="bs-ayuda-contenido">
                  <button type="button" className="bs-categorias-atras" onClick={() => {
                    setAyudaAbierta(false);
                    setPreguntaAbierta(null);
                  }}>← volver a categorías</button>
                  <h2>centro de ayuda</h2>
                  <p className="bs-categorias-descripcion">respuestas a las preguntas más frecuentes sobre compra y venta.</p>
                  {AYUDAS.map((ayuda, indice) => (
                    <div className="bs-ayuda-pregunta" key={ayuda.titulo}>
                      <button type="button" onClick={() => setPreguntaAbierta(actual => actual === indice ? null : indice)}
                        aria-expanded={preguntaAbierta === indice}>
                        <span>{ayuda.titulo}</span>
                        <span aria-hidden="true">{preguntaAbierta === indice ? '−' : '+'}</span>
                      </button>
                      {preguntaAbierta === indice && <p>{ayuda.respuesta}</p>}
                    </div>
                  ))}
                </section>
              ) : (
                <>
                  <h2 className="bs-menu-subtitulo">categorías</h2>
                  <div className="bs-categorias-tabs">
                    <button type="button" className={tipoCategorias === 'productos' ? 'activo' : ''}
                      onClick={() => setTipoCategorias('productos')}>
                      📦 productos
                    </button>
                    <button type="button" className={tipoCategorias === 'servicios' ? 'activo' : ''}
                      onClick={() => setTipoCategorias('servicios')}>
                      🛠️ servicios
                    </button>
                  </div>
                  <div className="bs-categorias-listado">
                    <p className="bs-categorias-descripcion">
                      selecciona una categoría para ver sus publicaciones en la página principal.
                    </p>
                    {categoriasVisibles.map(categoria => (
                      <button type="button" className="bs-categoria-fila" key={categoria.id}
                        onClick={() => abrirCategoria(categoria)}>
                        <span className="bs-categoria-icono" aria-hidden="true">
                          {tipoCategorias === 'productos' ? '📦' : '🛠️'}
                        </span>
                        <span className="bs-categoria-nombre">{categoria.nombre}</span>
                        <span className="bs-categoria-cantidad">{contarCategoria(categoria)}</span>
                        <span className="bs-categoria-flecha" aria-hidden="true">›</span>
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            <div className="bs-menu-pie">
              <button type="button" className="bs-centro-ayuda-boton" onClick={() => {
                setAyudaAbierta(actual => !actual);
                setPreguntaAbierta(null);
              }}>
                <Icono tipo="ayuda" size={20} />
                <span>{ayudaAbierta ? 'volver a categorías' : 'centro de ayuda'}</span>
                <span aria-hidden="true">›</span>
              </button>
            </div>
          </aside>
        </div>
      )}
    </>
  );
}
