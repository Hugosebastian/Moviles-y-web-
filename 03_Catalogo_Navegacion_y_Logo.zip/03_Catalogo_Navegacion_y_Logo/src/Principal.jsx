import { useState, useEffect, useRef } from 'react';
import { GRUPOS_MARCAS, CATEGORIAS, SECCIONES, correspondeCategoria, correspondeMarca, normalizar, seccionDe } from './Catalogo';
import './Principal.css';

export default function Principal({
  onNavigate, carrito = [], setCarrito, deseos = [], setDeseos,
  onVerDetalle, empresaActiva, usuarioActivo, usuarios,
  publicaciones = [], categoriaDesdeMenu = null,
  reinicioPrincipal = 0, onEstadoFiltro, onLimpiarCategoria
}) {
  const [busqueda, setBusqueda] = useState('');
  const [brandIndex, setBrandIndex] = useState(0);
  const [paginaCategoria, setPaginaCategoria] = useState(0);
  const [filtro, setFiltro] = useState(() => categoriaDesdeMenu ? {
    tipo: categoriaDesdeMenu.tipo === 'servicios' ? 'servicio' : 'categoria',
    id: categoriaDesdeMenu.id,
    nombre: categoriaDesdeMenu.nombre
  } : null);
  const ultimoReinicio = useRef(reinicioPrincipal);
  const resultadosRef = useRef(null);
  const filasRef = useRef({});
  const categoriasPorPagina = 8;
  const totalPaginasCategoria = Math.ceil(CATEGORIAS.length / categoriasPorPagina);

  useEffect(() => {
    if (filtro || busqueda.trim()) resultadosRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [filtro, busqueda]);

  // Las categorías del menú superior usan el mismo filtro visual
  // que las categorías de esta página.
  useEffect(() => {
    if (!categoriaDesdeMenu) return;
    setBusqueda('');
    setFiltro({
      tipo: categoriaDesdeMenu.tipo === 'servicios' ? 'servicio' : 'categoria',
      id: categoriaDesdeMenu.id,
      nombre: categoriaDesdeMenu.nombre
    });
  }, [categoriaDesdeMenu?.token]);

  // El botón superior volver borra el filtro antes de cambiar de página.
  useEffect(() => {
    if (ultimoReinicio.current === reinicioPrincipal) return;
    ultimoReinicio.current = reinicioPrincipal;
    setFiltro(null);
    setBusqueda('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [reinicioPrincipal]);

  useEffect(() => {
    onEstadoFiltro?.(Boolean(filtro || busqueda.trim()));
  }, [filtro, busqueda, onEstadoFiltro]);

  const coincideServicio = (item, categoria) => {
    if (String(item?.tipo).toLowerCase() !== 'servicio') return false;
    const valor = normalizar(item.categoria || '');
    return valor === normalizar(categoria.id) ||
      valor === normalizar(categoria.nombre);
  };

  const toggleDeseo = (producto) => {
    setDeseos(actual => actual.some(item => item.id === producto.id)
      ? actual.filter(item => item.id !== producto.id) : [...actual, producto]);
  };

  const agregarAlCarrito = (producto) => {
    setCarrito(actual => {
      const existe = actual.find(item => item.id === producto.id);
      return existe ? actual.map(item => item.id === producto.id ? { ...item, cantidad: item.cantidad + 1 } : item)
        : [...actual, { ...producto, cantidad: 1 }];
    });
    alert(`¡${producto.titulo} agregado al carrito!`);
  };

  const grupoActual = GRUPOS_MARCAS[brandIndex];
  const categoriasActuales = CATEGORIAS.slice(paginaCategoria * categoriasPorPagina, (paginaCategoria + 1) * categoriasPorPagina);
  // Publicaciones reales, creadas desde el formulario de la aplicación.
  const publicacionesVisibles = publicaciones.filter(p => p && String(p.tipo).toLowerCase() !== 'servicio');

  const limpiarFiltro = () => {
    setFiltro(null);
    setBusqueda('');
    onLimpiarCategoria?.();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const navegarMarcas = (cantidad) => setBrandIndex(i => (i + cantidad + GRUPOS_MARCAS.length) % GRUPOS_MARCAS.length);
  const navegarCategorias = (cantidad) => setPaginaCategoria(i => (i + cantidad + totalPaginasCategoria) % totalPaginasCategoria);
  const irAMarca = (name) => {
    setBusqueda('');
    setFiltro({ tipo: 'marca', id: grupoActual.id, nombre: name });
    onLimpiarCategoria?.();
  };
  const irACategoria = (id, titulo) => {
    setBusqueda('');
    setFiltro({ tipo: 'categoria', id, nombre: titulo });
    onLimpiarCategoria?.();
  };
  const moverFila = (id, sentido) => filasRef.current[id]?.scrollBy({ left: 525 * sentido, behavior: 'smooth' });

  const vistaResultados = Boolean(busqueda.trim() || filtro);
  const productosFiltrados = (filtro?.tipo === 'servicio'
    ? publicaciones.filter(p => coincideServicio(p, filtro))
    : publicacionesVisibles.filter(p => {
        if (busqueda.trim()) {
          const palabras = normalizar(busqueda);
          return normalizar(`${p.titulo || ''} ${p.marca || ''} ${p.categoria || ''} ${seccionDe(p)}`).includes(palabras);
        }
        if (filtro?.tipo === 'marca') return correspondeMarca(p, filtro.nombre, filtro.id);
        if (filtro?.tipo === 'categoria') return correspondeCategoria(p, filtro.id) ||
          normalizar(p.categoria) === normalizar(filtro.id);
        return false;
      }));

  const renderProducto = (item) => {
    const estaEnDeseos = deseos.some(d => d.id === item.id);
    const servicio = String(item.tipo).toLowerCase() === 'servicio';
    return (
      <article key={item.id} className="catalog-product-card">
        <div className="catalog-photo">
          <img src={item.img || '/productos/sin-imagen.svg'} alt={item.titulo} loading="lazy" onError={e => { e.currentTarget.onerror = null; e.currentTarget.src = '/productos/sin-imagen.svg'; }} />
          <span className="catalog-real-tag">Disponible</span>
          <button type="button" aria-label={estaEnDeseos ? 'Quitar de favoritos' : 'Agregar a favoritos'} title="Lista de deseos" className={`catalog-heart ${estaEnDeseos ? 'selected' : ''}`} onClick={() => toggleDeseo(item)}>{estaEnDeseos ? '♥' : '♡'}</button>
        </div>
        <div className="catalog-product-info">
          <span className="catalog-brand">{servicio ? 'servicio' : (item.marca || 'producto publicado')}</span>
          <h4>{item.titulo}</h4>
          <strong className="catalog-price">{item.precioStr || `$${Number(item.precioNum || 0).toLocaleString('es-CL')}`}</strong>
          <div className="catalog-product-actions">
            <button type="button" className="catalog-detail-btn" onClick={() => onVerDetalle?.(item)}>{servicio ? 'ver servicio' : 'ver detalle'}</button>
            {!servicio && <button type="button" className="catalog-cart-btn" aria-label={`Agregar ${item.titulo} al carrito`} title="Agregar al carrito" onClick={() => agregarAlCarrito(item)}>＋</button>}
          </div>
        </div>
      </article>
    );
  };

  const renderEjemplo = ([titulo, imagen], index, seccion) => (
    <article key={`${seccion}-${index}`} className="catalog-product-card catalog-preview-card" aria-label={`Espacio de ejemplo para ${titulo.toLowerCase()}`}>
      <div className="catalog-photo">
        <img src={`/productos/${imagen}.svg`} alt={`Ilustración de ${titulo.toLowerCase()}`} loading="lazy" />
        <span className="catalog-preview-tag">Vista previa</span>
      </div>
      <div className="catalog-product-info">
        <span className="catalog-brand">Próximas publicaciones</span>
        <h4>{titulo}</h4>
        <p className="catalog-preview-caption">Aquí se mostrarán los productos publicados.</p>
      </div>
    </article>
  );

  const renderProductRow = (seccion) => {
    const reales = publicacionesVisibles.filter(p => correspondeCategoria(p, seccion.id));
    const ejemplos = reales.length ? [] : seccion.ejemplos;
    return (
      <section key={seccion.id} className="catalog-row-section" aria-label={seccion.titulo}>
        <div className="catalog-row-top">
          <div>
            <h3>{seccion.titulo}</h3>
            <p>{seccion.descripcion}</p>
          </div>
          <div className="catalog-row-controls">
            <button type="button" className="catalog-see-all" onClick={() => irACategoria(seccion.id, seccion.titulo)}>Ver categoría <span aria-hidden="true">→</span></button>
            {reales.length > 4 && <>
              <button type="button" className="catalog-small-arrow" title="Ver anteriores" aria-label={`Ver productos anteriores de ${seccion.titulo}`} onClick={() => moverFila(seccion.id, -1)}>‹</button>
              <button type="button" className="catalog-small-arrow" title="Ver siguientes" aria-label={`Ver más productos de ${seccion.titulo}`} onClick={() => moverFila(seccion.id, 1)}>›</button>
            </>}
          </div>
        </div>
        <div className="catalog-product-scroll" ref={el => { filasRef.current[seccion.id] = el; }}>
          {reales.map(renderProducto)}
          {ejemplos.map((ejemplo, index) => renderEjemplo(ejemplo, index, seccion.id))}
        </div>
      </section>
    );
  };

  return (
    <div className="principal-container">
      <main className="main-wrapper">
        {/* Carrusel de marcas: flechas en ambos lados, sin círculos decorativos. */}
        <section className="brands-section" aria-label="Marcas destacadas">
          <div className="catalog-heading-center">
            <span className="catalog-kicker">DESCUBRE TUS FAVORITAS</span>
            <h2>{grupoActual.titulo}</h2>
            <p>{grupoActual.subtitulo}</p>
          </div>
          <div className="brands-carousel-layout">
            <button type="button" className="catalog-carousel-arrow" aria-label="Ver grupo anterior de marcas" title="Marcas anteriores" onClick={() => navegarMarcas(-1)}>‹</button>
            <div className="brands-grid" aria-live="polite">
              {grupoActual.brands.map(([name, logo]) => (
                <button type="button" className="brand-card" key={`${grupoActual.id}-${logo}`} onClick={() => irAMarca(name)} title={`Ver publicaciones de ${name}`}>
                  <span className="brand-logo-frame"><img src={`/marcas/${logo}.svg`} alt={`Marca ${name}`} /></span>
                  <span className="brand-label">{name}</span>
                  <span className="brand-link">Ver productos <span aria-hidden="true">↗</span></span>
                </button>
              ))}
            </div>
            <button type="button" className="catalog-carousel-arrow" aria-label="Ver siguiente grupo de marcas" title="Más marcas" onClick={() => navegarMarcas(1)}>›</button>
          </div>
        </section>

        {/* Resultados reales cuando se elige una marca, categoría o término de búsqueda. */}
        {vistaResultados && <section className="catalog-results" ref={resultadosRef} aria-label="Publicaciones filtradas">
          <div className="catalog-results-heading">
            <div>
              <span className="catalog-kicker">explora la tienda</span>
              <h2>{busqueda.trim() ? `Resultados para “${busqueda.trim()}”` : filtro?.tipo === 'marca' ? `${filtro.nombre} · ${GRUPOS_MARCAS.find(g => g.id === filtro.id)?.titulo.toLowerCase().replace('mejores marcas de ', '') || 'productos'}` : filtro?.nombre}</h2>
              <p>{productosFiltrados.length} {productosFiltrados.length === 1 ? 'publicación disponible' : 'publicaciones disponibles'}</p>
            </div>
            <button type="button" className="catalog-clear-btn" onClick={limpiarFiltro}>← volver al inicio</button>
          </div>
          {productosFiltrados.length ? <div className="catalog-results-grid">{productosFiltrados.map(renderProducto)}</div> : (
            <div className="catalog-results-empty">
              <div className="catalog-empty-icon"><img src="/productos/sin-imagen.svg" alt="" /></div>
              <div>
                <h3>todavía no hay publicaciones aquí</h3>
                <p>cuando se publique un producto o servicio en esta categoría, aparecerá aquí con su información.</p>
              </div>
            </div>
          )}
        </section>}

        {!vistaResultados && <>
          {/* Dos filas simétricas de imágenes, con flechas y sin indicadores circulares. */}
          <section className="categories-section" aria-label="Categorías de productos">
            <div className="catalog-section-heading">
              <div>
                <span className="catalog-kicker">ENCUENTRA LO QUE BUSCAS</span>
                <h2>Explora nuestras categorías</h2>
                <p>Todo lo que necesitas, en un solo lugar.</p>
              </div>
              <div className="catalog-pagination-controls">
                <span className="catalog-page-indicator">{paginaCategoria + 1} / {totalPaginasCategoria}</span>
                <button type="button" className="catalog-carousel-arrow compact" aria-label="Categorías anteriores" onClick={() => navegarCategorias(-1)}>‹</button>
                <button type="button" className="catalog-carousel-arrow compact" aria-label="Más categorías" onClick={() => navegarCategorias(1)}>›</button>
              </div>
            </div>
            <div className="categories-grid" aria-live="polite">
              {categoriasActuales.map(cat => (
                <button type="button" key={cat.id} className="category-tile" onClick={() => irACategoria(cat.id, cat.titulo)}>
                  <img src={`/categorias/${cat.imagen}.svg`} alt={`Ilustración de la categoría ${cat.titulo}`} loading="lazy" />
                  <span className="category-tile-copy"><strong>{cat.titulo}</strong><small>{cat.texto}</small><span className="category-open" aria-hidden="true">↗</span></span>
                </button>
              ))}
            </div>
          </section>

          <section className="storefront-section" aria-label="Publicaciones por secciones">
            <div className="catalog-storefront-heading">
              <span className="catalog-kicker">NUESTRA VITRINA</span>
              <h2>Descubre publicaciones por sección</h2>
              <p>Los espacios marcados como “Vista previa” se llenarán cuando se suban productos reales.</p>
            </div>
            {SECCIONES.map(renderProductRow)}
          </section>
        </>}
      </main>
    </div>
  );
}
