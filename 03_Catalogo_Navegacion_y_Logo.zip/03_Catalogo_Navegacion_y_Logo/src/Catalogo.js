
/* ==========================================
   CATÁLOGO GENERAL DE COMPRA Y VENTA
========================================== */

// MEJORES MARCAS

export const GRUPOS_MARCAS = [
  {
    id: 'zapatillas',
    titulo: 'Mejores marcas de zapatillas',
    subtitulo: 'Encuentra zapatillas de tus marcas favoritas',
    brands: [
      ['Adidas', 'adidas'],
      ['Nike', 'nike'],
      ['New Balance', 'newbalance'],
      ['Puma', 'puma'],
      ['Vans', 'vans']
    ]
  },
  {
    id: 'ropa',
    titulo: 'Mejores marcas de ropa',
    subtitulo: 'Prendas y estilos para cada ocasión',
    brands: [
      ["Levi's", 'levis'],
      ['Zara', 'zara'],
      ['H&M', 'hm'],
      ['Uniqlo', 'uniqlo'],
      ['Lacoste', 'lacoste']
    ]
  },
  {
    id: 'televisores',
    titulo: 'Mejores marcas de televisores',
    subtitulo: 'Pantallas y entretenimiento para el hogar',
    brands: [
      ['Samsung', 'samsung'],
      ['LG', 'lg'],
      ['Sony', 'sony'],
      ['TCL', 'tcl'],
      ['Hisense', 'hisense']
    ]
  },
  {
    id: 'tecnologia',
    titulo: 'Mejores marcas de tecnología',
    subtitulo: 'Tecnología para cada día',
    brands: [
      ['Apple', 'apple'],
      ['Samsung', 'samsung'],
      ['Lenovo', 'lenovo'],
      ['HP', 'hp'],
      ['Asus', 'asus']
    ]
  },
  {
    id: 'deportes',
    titulo: 'Mejores marcas deportivas',
    subtitulo: 'Equípate para lo que más te gusta',
    brands: [
      ['Adidas', 'adidas'],
      ['Nike', 'nike'],
      ['Puma', 'puma'],
      ['Under Armour', 'underarmour'],
      ['Reebok', 'reebok']
    ]
  }
];


/* ==========================================
   CATEGORÍAS PRINCIPALES
========================================== */

export const CATEGORIAS = [
  {
    id: 'hombre',
    titulo: 'Hombre',
    texto: 'Moda y calzado',
    imagen: 'hombre'
  },
  {
    id: 'mujer',
    titulo: 'Mujer',
    texto: 'Moda y accesorios',
    imagen: 'mujer'
  },
  {
    id: 'ninos',
    titulo: 'Niños y niñas',
    texto: 'Para los pequeños',
    imagen: 'ninos'
  },
  {
    id: 'calzado',
    titulo: 'Calzado',
    texto: 'Para todos',
    imagen: 'calzado'
  },
  {
    id: 'tecnologia',
    titulo: 'Tecnología',
    texto: 'Computación y más',
    imagen: 'tecnologia'
  },
  {
    id: 'hogar',
    titulo: 'Hogar',
    texto: 'Todo para tu casa',
    imagen: 'hogar'
  },
  {
    id: 'deportes',
    titulo: 'Deportes',
    texto: 'Entrena a tu manera',
    imagen: 'deportes'
  },
  {
    id: 'mascotas',
    titulo: 'Mascotas',
    texto: 'Para tus compañeros',
    imagen: 'mascotas'
  },
  {
    id: 'accesorios',
    titulo: 'Accesorios',
    texto: 'Complementa tu estilo',
    imagen: 'accesorios'
  },
  {
    id: 'celulares',
    titulo: 'Celulares',
    texto: 'Conectados siempre',
    imagen: 'celulares'
  },
  {
    id: 'televisores',
    titulo: 'Televisores',
    texto: 'Series y películas',
    imagen: 'televisores'
  },
  {
    id: 'muebles',
    titulo: 'Muebles',
    texto: 'Espacios a tu gusto',
    imagen: 'muebles'
  },
  {
    id: 'juguetes',
    titulo: 'Juguetería',
    texto: 'Para jugar y crear',
    imagen: 'juguetes'
  },
  {
    id: 'belleza',
    titulo: 'Belleza',
    texto: 'Cuidado personal',
    imagen: 'belleza'
  },
  {
    id: 'libros',
    titulo: 'Libros y útiles',
    texto: 'Lectura y estudio',
    imagen: 'libros'
  },
  {
    id: 'otros',
    titulo: 'Otras categorías',
    texto: 'Descubre más',
    imagen: 'otros'
  }
];


/* ==========================================
   SECCIONES DE PUBLICACIONES
========================================== */

export const SECCIONES = [
  {
    id: 'vestuario-hombre',
    titulo: 'Vestuario hombre',
    descripcion: 'Poleras, chaquetas, jeans y más',
    icono: 'hombre',
    ejemplos: [
      ['Polerones', 'poleron'],
      ['Poleras y camisas', 'camisa'],
      ['Jeans y pantalones', 'jeans'],
      ['Chaquetas', 'chaqueta']
    ]
  },
  {
    id: 'calzado-hombre',
    titulo: 'Calzado hombre',
    descripcion: 'Zapatillas, zapatos y botines',
    icono: 'calzado',
    ejemplos: [
      ['Zapatillas', 'zapatilla'],
      ['Botines', 'botin'],
      ['Calzado urbano', 'zapatilla'],
      ['Botas', 'botin']
    ]
  },
  {
    id: 'vestuario-mujer',
    titulo: 'Vestuario mujer',
    descripcion: 'Prendas para todos los estilos',
    icono: 'mujer',
    ejemplos: [
      ['Vestidos', 'vestido'],
      ['Blusas y poleras', 'camisa'],
      ['Faldas', 'falda'],
      ['Jeans', 'jeans']
    ]
  },
  {
    id: 'calzado-mujer',
    titulo: 'Calzado mujer',
    descripcion: 'Zapatillas y zapatos para cada día',
    icono: 'calzado',
    ejemplos: [
      ['Zapatillas', 'zapatilla'],
      ['Zapatos', 'tacon'],
      ['Botines', 'botin'],
      ['Calzado casual', 'zapatilla']
    ]
  },
  {
    id: 'ninos',
    titulo: 'Niños y niñas',
    descripcion: 'Ropa, juegos y más',
    icono: 'ninos',
    ejemplos: [
      ['Ropa infantil', 'ninos'],
      ['Zapatillas infantiles', 'zapatilla'],
      ['Mochilas', 'mochila'],
      ['Polerones', 'poleron']
    ]
  },
  {
    id: 'tecnologia',
    titulo: 'Tecnología',
    descripcion: 'Computación y electrónicos',
    icono: 'tecnologia',
    ejemplos: [
      ['Notebooks', 'laptop'],
      ['Monitores', 'monitor'],
      ['Mochilas para notebook', 'mochila'],
      ['Equipos y accesorios', 'laptop']
    ]
  },
  {
    id: 'deportes',
    titulo: 'Deportes y aire libre',
    descripcion: 'Todo para mantenerte activo',
    icono: 'deportes',
    ejemplos: [
      ['Balones', 'balon'],
      ['Zapatillas deportivas', 'zapatilla'],
      ['Ropa deportiva', 'camisa'],
      ['Mochilas', 'mochila']
    ]
  },
  {
    id: 'hogar',
    titulo: 'Hogar y decoración',
    descripcion: 'Ideas para tus espacios',
    icono: 'hogar',
    ejemplos: [
      ['Sillones', 'sofa'],
      ['Televisores', 'monitor'],
      ['Decoración', 'sofa'],
      ['Organización', 'mochila']
    ]
  }
];


/* ==========================================
   SECCIONES DISPONIBLES PARA PUBLICAR
========================================== */

export const SECCIONES_PUBLICAR = [
  { id: 'vestuario-hombre', titulo: 'Vestuario hombre' },
  { id: 'calzado-hombre', titulo: 'Calzado hombre' },
  { id: 'vestuario-mujer', titulo: 'Vestuario mujer' },
  { id: 'calzado-mujer', titulo: 'Calzado mujer' },
  { id: 'ninos', titulo: 'Niños y niñas' },
  { id: 'tecnologia', titulo: 'Tecnología y computación' },
  { id: 'celulares', titulo: 'Celulares' },
  { id: 'televisores', titulo: 'Televisores' },
  { id: 'deportes', titulo: 'Deportes y aire libre' },
  { id: 'hogar', titulo: 'Hogar' },
  { id: 'muebles', titulo: 'Muebles' },
  { id: 'mascotas', titulo: 'Mascotas' },
  { id: 'accesorios', titulo: 'Accesorios' },
  { id: 'juguetes', titulo: 'Juguetes' },
  { id: 'belleza', titulo: 'Belleza' },
  { id: 'libros', titulo: 'Libros y papelería' },
  { id: 'otros', titulo: 'Otros' }
];


/* ==========================================
   FUNCIONES PARA FILTRAR PRODUCTOS
========================================== */

// Normalizar texto para facilitar búsquedas
export const normalizar = (texto = '') =>
  String(texto)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();


// Detectar sección de un producto
export function seccionDe(producto) {

  if (producto.seccion) {
    return producto.seccion;
  }

  const texto = normalizar(
    `${producto.categoria || ''} ${producto.titulo || ''}`
  );

  if (/nino|nina|infantil|bebe/.test(texto)) {
    return 'ninos';
  }

  if (/televisor|television|smart tv|pantalla tv/.test(texto)) {
    return 'televisores';
  }

  if (/celular|smartphone|iphone|telefono movil/.test(texto)) {
    return 'celulares';
  }

  if (/laptop|notebook|computador|gamer|pc |playstation|consola|monitor|tablet/.test(texto)) {
    return 'tecnologia';
  }

  if (/mascota|perro|gato/.test(texto)) {
    return 'mascotas';
  }

  if (/juguete|lego|muneca/.test(texto)) {
    return 'juguetes';
  }

  if (/mueble|sillon|sofa|cama|escritorio/.test(texto)) {
    return 'muebles';
  }

  if (/deporte|balon|fitness|bicicleta|raqueta/.test(texto)) {
    return 'deportes';
  }

  if (/zapati|zapato|calzado|botin|bota|tacon/.test(texto)) {
    return /mujer|dama|femeni/.test(texto)
      ? 'calzado-mujer'
      : 'calzado-hombre';
  }

  if (/vestido|blusa|falda|vestuario mujer/.test(texto)) {
    return 'vestuario-mujer';
  }

  if (/polera|poleron|jean|chaqueta|camisa|vestuario hombre|ropa/.test(texto)) {
    return /mujer|dama|femeni/.test(texto)
      ? 'vestuario-mujer'
      : 'vestuario-hombre';
  }

  if (/hogar|decoracion|electrohogar/.test(texto)) {
    return 'hogar';
  }

  if (/accesorio|cartera|mochila|reloj/.test(texto)) {
    return 'accesorios';
  }

  if (/belleza|maquillaje|cosmetico/.test(texto)) {
    return 'belleza';
  }

  if (/libro|papeleria|libreria|utiles/.test(texto)) {
    return 'libros';
  }

  return 'otros';
}


// Comprobar si un producto corresponde a una categoría
export function correspondeCategoria(producto, id) {

  const seccion = seccionDe(producto);

  const grupos = {
    hombre: ['vestuario-hombre', 'calzado-hombre'],
    mujer: ['vestuario-mujer', 'calzado-mujer'],
    calzado: ['calzado-hombre', 'calzado-mujer'],
    tecnologia: ['tecnologia', 'celulares', 'televisores'],
    hogar: ['hogar', 'muebles'],
    ninos: ['ninos', 'juguetes']
  };

  if (grupos[id]) {
    return grupos[id].includes(seccion);
  }

  return seccion === id;
}


// Comprobar si un producto corresponde a una marca
export function correspondeMarca(producto, marca, grupo) {

  const marcaBuscada = normalizar(marca)
    .replace(/[^a-z0-9]/g, '');

  const marcaProducto = normalizar(
    producto.marca || ''
  );

  const texto = normalizar(
    `${producto.titulo || ''} ${producto.marca || ''}`
  );

  const compactar = texto =>
    texto.replace(/[^a-z0-9]/g, '');

  const coincide =
    compactar(marcaProducto) === marcaBuscada ||
    texto.includes(normalizar(marca));

  if (!coincide) {
    return false;
  }

  const seccion = seccionDe(producto);

  if (grupo === 'zapatillas') {
    return [
      'calzado-hombre',
      'calzado-mujer'
    ].includes(seccion);
  }

  if (grupo === 'ropa') {
    return [
      'vestuario-hombre',
      'vestuario-mujer'
    ].includes(seccion);
  }

  if (grupo === 'televisores') {
    return seccion === 'televisores' ||
      (
        seccion === 'tecnologia' &&
        /tv|televisor/.test(texto)
      );
  }

  if (grupo === 'deportes') {
    return seccion === 'deportes' ||
      (
        seccion.startsWith('calzado-') &&
        /deporte|running|futbol/.test(texto)
      );
  }

  if (grupo === 'tecnologia') {
    return [
      'tecnologia',
      'celulares',
      'televisores'
    ].includes(seccion);
  }

  return true;
}
