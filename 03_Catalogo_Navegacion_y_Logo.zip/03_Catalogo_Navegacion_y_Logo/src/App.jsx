
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import Login from './Login';
import Registro from './Registro';
import Principal from './Principal';
import Perfil from './Perfil';
import Carrito from './Carrito';
import MisCompras from './MisCompras';
import DetalleProducto from './DetalleProducto';
import RegistroEmpresa from './RegistroEmpresa';
import MiEmpresa from './MiEmpresa';
import Servicios from './Servicios';
import {
  normalizarNombreEmpresa,
  normalizarRut,
  rutValido,
  perteneceAEmpresa
} from './EmpresaUtils';
import PublicarItem from './PublicarItem';
import MisVentas from './MisVentas';
import Chat from './Chat';
import Cotizacion from './Cotizacion';
import ComprobantePago from './ComprobantePago';
import AdminPanel from './AdminPanel';
import GestionComercial from './GestionComercial';
import BarraSuperior from './BarraSuperior';
import './ListaDeseos.css';

const LISTA_PREDETERMINADA = {
  id: 'favoritos', nombre: 'Mis favoritos', predeterminada: true, productos: []
};

export default function App() {
  const [vistaActual, setVistaActual] = useState('login');
  const [historialVistas, setHistorialVistas] = useState([]);
  const [categoriaDesdeMenu, setCategoriaDesdeMenu] = useState(null);
  const [reinicioPrincipal, setReinicioPrincipal] = useState(0);
  const [filtroPrincipalActivo, setFiltroPrincipalActivo] = useState(false);
  const contadorCategorias = useRef(0);
  const [seccionAdmin, setSeccionAdmin] = useState('resumen');

  const abrirCategoria = (tipo, id, nombre) => {
    contadorCategorias.current += 1;
    setCategoriaDesdeMenu({
      tipo, id, nombre, token: contadorCategorias.current
    });
    setFiltroPrincipalActivo(true);
    if (vistaActual !== 'principal') {
      setHistorialVistas(actual => [...actual, vistaActual].slice(-30));
    }
    setVistaActual('principal');
  };

  const volverAlInicioPrincipal = () => {
    setCategoriaDesdeMenu(null);
    setFiltroPrincipalActivo(false);
    setReinicioPrincipal(actual => actual + 1);
  };

  const navegar = (vista) => {
    let destino = vista === 'vender' ? 'publicar-producto' : vista;

    if (
      ['publicar-producto', 'publicar-servicio', 'mis-ventas', 'mi-empresa'].includes(destino)
      && !empresaActiva
    ) {
      destino = 'registro-empresa';
    }

    if (destino === 'registro-empresa' && empresaActiva) {
      destino = 'mi-empresa';
    }

    if (
      destino === 'admin-panel' &&
      !(
        usuarioActivo?.tipoPerfil?.includes('Administrador') &&
        usuarioActivo?.estadoAdmin === 'Aprobado'
      )
    ) {
      destino = 'principal';
    }

    if (destino === 'principal') {
      volverAlInicioPrincipal();
    }

    if (destino === 'admin-panel' && vistaActual !== 'admin-panel') {
      setSeccionAdmin('resumen');
    }

    if (destino === vistaActual) return;

    setHistorialVistas(actual => [...actual, vistaActual].slice(-30));
    setVistaActual(destino);
  };

  const volver = () => {
    if (vistaActual === 'principal' && filtroPrincipalActivo) {
      volverAlInicioPrincipal();
      return;
    }

    if (vistaActual === 'principal') {
      cerrarSesion();
      return;
    }

    if (vistaActual === 'admin-panel' && seccionAdmin !== 'resumen') {
      setSeccionAdmin('resumen');
      return;
    }

    if (!historialVistas.length) {
      if (vistaActual !== 'principal') {
        volverAlInicioPrincipal();
        setVistaActual('principal');
      }
      return;
    }

    const anterior = historialVistas[historialVistas.length - 1];

    setHistorialVistas(actual => actual.slice(0, -1));

    if (anterior === 'principal') volverAlInicioPrincipal();
    if (anterior === 'admin-panel') setSeccionAdmin('resumen');

    setVistaActual(anterior === 'login' ? 'principal' : anterior);
  };

  const cerrarSesion = () => {
    if (!window.confirm('¿quieres cerrar sesión?')) return;

    fetch('http://localhost:3000/api/logout', {
      method: 'POST',
      credentials: 'include'
    }).catch(() => {});

    setUsuarioActivo(null);
    setCarrito([]);
    setProductoSeleccionado(null);
    setHistorialVistas([]);
    setCategoriaDesdeMenu(null);
    setFiltroPrincipalActivo(false);
    setMostrarRegistro(false);
    setVistaActual('login');
  };

  const [mostrarRegistro, setMostrarRegistro] = useState(false);
  const [usuarioActivo, setUsuarioActivo] = useState(null);

  const [empresasRegistradas, setEmpresasRegistradas] = useState([]);

  const empresaActiva = useMemo(
    () => empresasRegistradas.find(empresa =>
      usuarioActivo?.run &&
      normalizarRut(empresa.propietarioRun) === normalizarRut(usuarioActivo.run)
    ) || null,
    [empresasRegistradas, usuarioActivo]
  );

  // Consultar PostgreSQL al iniciar sesión.
  useEffect(() => {
    if (!usuarioActivo?.id) {
      setEmpresasRegistradas([]);
      return;
    }

    let cancelado = false;

    fetch('http://localhost:3000/api/empresas/mia', {
      credentials: 'include'
    })
      .then(async respuesta => {
        const datos = await respuesta.json();

        if (!respuesta.ok) {
          throw new Error(
            datos.error || 'no se pudo consultar la empresa.'
          );
        }

        return datos;
      })
      .then(datos => {
        if (!cancelado) {
          setEmpresasRegistradas(
            datos.empresa ? [datos.empresa] : []
          );
        }
      })
      .catch(error => {
        if (!cancelado) {
          console.error('error al cargar empresa:', error);
          setEmpresasRegistradas([]);
        }
      });

    return () => {
      cancelado = true;
    };
  }, [usuarioActivo?.id]);

  const solicitarEmpresa = async (metodo, ruta, datos) => {
    const respuesta = await fetch(
      'http://localhost:3000' + ruta,
      {
        method: metodo,
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
      }
    );

    const resultado = await respuesta.json();

    if (!respuesta.ok) {
      throw new Error(
        resultado.error || 'no se pudo guardar la empresa.'
      );
    }

    return resultado.empresa;
  };

  const crearEmpresa = async datos => {
    if (!usuarioActivo) {
      return {
        ok: false,
        error: 'inicia sesión.'
      };
    }

    try {
      const empresa = await solicitarEmpresa(
        'POST',
        '/api/empresas',
        datos
      );

      setEmpresasRegistradas([empresa]);

      const agregarRol = usuario => ({
        ...usuario,
        tipoPerfil: [
          ...new Set([
            ...(usuario.tipoPerfil || []),
            'Emprendedor'
          ])
        ]
      });

      setUsuarioActivo(actual =>
        actual ? agregarRol(actual) : actual
      );

      setUsuariosRegistrados(actual =>
        actual.map(u =>
          normalizarRut(u.run) === normalizarRut(usuarioActivo.run)
            ? agregarRol(u)
            : u
        )
      );

      setHistorialVistas(actual =>
        [...actual, vistaActual].slice(-30)
      );

      setVistaActual('mi-empresa');

      return { ok: true };

    } catch (error) {
      return {
        ok: false,
        error: error.message
      };
    }
  };

  const actualizarEmpresa = async cambios => {
    if (!empresaActiva) {
      return {
        ok: false,
        error: 'no tienes una empresa activa.'
      };
    }

    try {
      const empresa = await solicitarEmpresa(
        'PATCH',
        '/api/empresas/mia',
        cambios
      );

      setEmpresasRegistradas([empresa]);

      const nombre = empresa.nombreEmpresa;

      setPublicaciones(actual =>
        actual.map(item =>
          perteneceAEmpresa(item, empresaActiva)
            ? {
                ...item,
                empresaNombre: nombre,
                vendedor: nombre
              }
            : item
        )
      );

      setCarrito(actual =>
        actual.map(item =>
          perteneceAEmpresa(item, empresaActiva)
            ? {
                ...item,
                empresaNombre: nombre,
                vendedor: nombre
              }
            : item
        )
      );

      setListasDeseos(actual =>
        actual.map(lista => ({
          ...lista,
          productos: lista.productos.map(item =>
            perteneceAEmpresa(item, empresaActiva)
              ? {
                  ...item,
                  empresaNombre: nombre,
                  vendedor: nombre
                }
              : item
          )
        }))
      );

      return { ok: true };

    } catch (error) {
      return {
        ok: false,
        error: error.message
      };
    }
  };

  const [carrito, setCarrito] = useState([]);
  const [historialCompras, setHistorialCompras] = useState([]);
  const [productoSeleccionado, setProductoSeleccionado] = useState(null);
  const [compraReciente, setCompraReciente] = useState(null);
  const [prodsCotizacion, setProdsCotizacion] = useState([]);

  const [publicaciones, setPublicaciones] = useState([]);
  const [historialVentas, setHistorialVentas] = useState([]);

  const apiNegocio = useCallback(async (ruta, metodo = 'GET', contenido) => {
    const respuesta = await fetch('http://localhost:3000' + ruta, {
      method: metodo, credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      ...(contenido === undefined ? {} : { body: JSON.stringify(contenido) })
    });
    const datos = await respuesta.json();
    if (!respuesta.ok) throw new Error(datos.error || 'Error de PostgreSQL.');
    return datos;
  }, []);

  const cargarPublicaciones = useCallback(async () => {
    const datos = await apiNegocio('/api/publicaciones');
    setPublicaciones(datos.publicaciones);
  }, [apiNegocio]);

  useEffect(() => {
    cargarPublicaciones().catch(
      error => console.error('publicaciones:', error)
    );
  }, []);

  useEffect(() => {
    if (!usuarioActivo?.id) {
      setHistorialCompras([]);
      setHistorialVentas([]);
      return;
    }

    let cancelado = false;

    Promise.all([
      apiNegocio('/api/pedidos/mios'),
      apiNegocio('/api/pedidos/ventas')
    ]).then(([compras, ventas]) => {
      if (!cancelado) {
        setHistorialCompras(compras.pedidos);
        setHistorialVentas(ventas.pedidos);
      }
    }).catch(
      error => console.error('historial:', error)
    );

    return () => {
      cancelado = true;
    };
  }, [usuarioActivo?.id]);

  // Favoritos y listas pertenecen a la cuenta y se guardan en PostgreSQL.
  const [listasDeseos, guardarListasEstado] = useState([LISTA_PREDETERMINADA]);
  const listasRef = useRef([LISTA_PREDETERMINADA]);
  const colaListas = useRef(Promise.resolve());
  const versionListas = useRef(0);
  const [productoParaListas, setProductoParaListas] = useState(null);
  const [listasMarcadas, setListasMarcadas] = useState([]);

  const cargarListas = useCallback(async () => {
    const r = await apiNegocio('/api/listas');
    listasRef.current = r.listas;
    guardarListasEstado(r.listas);
    return r.listas;
  }, [apiNegocio]);

  useEffect(() => {
    if (!usuarioActivo?.id) {
      listasRef.current = [LISTA_PREDETERMINADA];
      guardarListasEstado([LISTA_PREDETERMINADA]);
      return;
    }
    cargarListas().catch(e => console.error('Listas:', e.message));
  }, [usuarioActivo?.id, cargarListas]);

  const setListasDeseos = (cambio) => {
    const siguientes = typeof cambio === 'function' ? cambio(listasRef.current) : cambio;
    listasRef.current = siguientes;
    guardarListasEstado(siguientes);
    const version = ++versionListas.current;
    colaListas.current = colaListas.current.catch(() => {}).then(async () => {
      const r = await apiNegocio('/api/listas', 'PUT', { listas: listasRef.current });
      if (version === versionListas.current) {
        listasRef.current = r.listas;
        guardarListasEstado(r.listas);
      }
    }).catch(async error => {
      console.error('Error al guardar listas:', error);
      alert('No se pudieron guardar las listas: ' + error.message);
      try { await cargarListas(); } catch { /* Mantener error visible */ }
    });
  };

  const deseos = useMemo(() => {
    const unicos = new Map();

    listasDeseos.forEach(lista => {
      (lista.productos || []).forEach(producto => {
        if (producto?.id != null) {
          unicos.set(String(producto.id), producto);
        }
      });
    });

    return [...unicos.values()];
  }, [listasDeseos]);

  const setDeseos = (actualizacion) => {
    setListasDeseos(actual => {
      const favoritos = actual.find(
        lista => String(lista.id) === 'favoritos'
      );

      const anteriores = favoritos?.productos || [];

      const nuevos = typeof actualizacion === 'function'
        ? actualizacion(anteriores)
        : actualizacion;

      return actual.map(lista =>
        String(lista.id) === 'favoritos'
          ? {
              ...lista,
              productos: Array.isArray(nuevos)
                ? nuevos
                : anteriores
            }
          : lista
      );
    });
  };

  const abrirSelectorListas = (producto) => {
    if (!producto) return;

    setProductoParaListas(producto);

    setListasMarcadas(
      listasDeseos
        .filter(lista => lista.productos.some(
          p => String(p.id) === String(producto.id)
        ))
        .map(lista => String(lista.id))
    );
  };

  const guardarEnListas = () => {
    if (!productoParaListas) return;

    const producto = productoParaListas;

    setListasDeseos(actual => actual.map(lista => {
      const resto = lista.productos.filter(
        p => String(p.id) !== String(producto.id)
      );

      return {
        ...lista,
        productos: listasMarcadas.includes(String(lista.id))
          ? [...resto, producto]
          : resto
      };
    }));

    setProductoParaListas(null);
    setListasMarcadas([]);
  };

  const [usuariosRegistrados, setUsuariosRegistrados] = useState([]);

  useEffect(() => {
    setUsuarioActivo(actual => {
      if (!actual) return null;

      const actualizado = usuariosRegistrados.find(
        usuario =>
          normalizarRut(usuario.run) === normalizarRut(actual.run)
      );

      return actualizado || null;
    });
  }, [usuariosRegistrados]);

  const actualizarUsuario = (actualizado) => {
    setUsuarioActivo(actualizado);

    setUsuariosRegistrados(actual => actual.map(usuario =>
      usuario.run === actualizado.run
        ? actualizado
        : usuario
    ));
  };

  const eliminarCuenta = () => {
    if (!usuarioActivo) return;

    const idEmpresa = empresaActiva?.id;

    if (idEmpresa) {
      setPublicaciones(actual => actual.filter(
        p => String(p.empresaId) !== String(idEmpresa)
      ));

      setEmpresasRegistradas(actual => actual.filter(
        e => String(e.id) !== String(idEmpresa)
      ));
    }

    setUsuariosRegistrados(actual => actual.filter(
      usuario => usuario.run !== usuarioActivo.run
    ));

    setUsuarioActivo(null);
    setVistaActual('login');
  };

  const [chats, setChats] = useState([]);
  const [chatActivo, setChatActivo] = useState(null);
  const [adminUsuarios, setAdminUsuarios] = useState([]);
  const [adminEmpresas, setAdminEmpresas] = useState([]);
  const [adminPublicaciones, setAdminPublicaciones] = useState([]);

  const cargarChats = useCallback(async () => {
    const r = await apiNegocio('/api/chats');
    setChats(r.chats);
    return r.chats;
  }, [apiNegocio]);

  const cargarAdmin = useCallback(async () => {
    const r = await apiNegocio('/api/admin/resumen');
    setAdminUsuarios(r.usuarios);
    setAdminEmpresas(r.empresas);
    setAdminPublicaciones(r.publicaciones);
    const catalogo = await apiNegocio('/api/publicaciones');
    setPublicaciones(catalogo.publicaciones);
    return r;
  }, [apiNegocio]);

  useEffect(() => {
    if (!usuarioActivo?.id) {
      setChats([]); setChatActivo(null);
      return;
    }
    cargarChats().catch(e => console.error('Chats:', e.message));
  }, [usuarioActivo?.id, cargarChats]);

  useEffect(() => {
    const refrescar = () => {
      cargarPublicaciones().catch(() => {});
      if (usuarioActivo?.id) {
        cargarChats().catch(() => {});
        cargarListas().catch(() => {});
        if (vistaActual === 'admin-panel') cargarAdmin().catch(() => {});
      }
    };
    window.addEventListener('focus', refrescar);
    return () => window.removeEventListener('focus', refrescar);
  }, [usuarioActivo?.id, vistaActual, cargarPublicaciones, cargarChats, cargarListas, cargarAdmin]);

  const handleAbrirChat = async nuevoChat => {
    if (!usuarioActivo) return alert('Inicia sesión para escribir al vendedor.');
    try {
      const r = await apiNegocio('/api/chats', 'POST', { publicacionId: nuevoChat.publicacionId });
      const actualizados = await cargarChats();
      setChatActivo(actualizados.find(c => String(c.id) === String(r.id)) || { id: r.id });
      navegar('chat');
    } catch (e) { alert(e.message); }
  };

  const abrirDetalleProducto = (producto) => {
    setProductoSeleccionado(producto);
    navegar('detalle-producto');
  };

  const agregarPublicacion = async item => {
    try {
      const datos = await apiNegocio(
        '/api/publicaciones',
        'POST',
        item
      );

      setPublicaciones(actual => [
        datos.publicacion,
        ...actual
      ]);

      return { ok: true };

    } catch (error) {
      return {
        ok: false,
        error: error.message
      };
    }
  };

  const guardarPublicacion = async (id, cambios) => {
    try {
      const datos = await apiNegocio(
        '/api/publicaciones/' + id,
        'PATCH',
        cambios
      );

      setPublicaciones(actual =>
        actual.map(item =>
          String(item.id) === String(id)
            ? datos.publicacion
            : item
        )
      );

      return { ok: true };

    } catch (error) {
      return {
        ok: false,
        error: error.message
      };
    }
  };

  const eliminarPublicacion = async id => {
    try {
      await apiNegocio(
        '/api/publicaciones/' + id,
        'DELETE'
      );

      setPublicaciones(actual =>
        actual.filter(
          item => String(item.id) !== String(id)
        )
      );

      return { ok: true };

    } catch (error) {
      return {
        ok: false,
        error: error.message
      };
    }
  };

  return (
    <div className="cv-app">
      {vistaActual !== 'login' && (
        <BarraSuperior
          vistaActual={vistaActual}
          onNavigate={navegar}
          onVolver={volver}
          onCerrarSesion={cerrarSesion}
          onVerDetalle={abrirDetalleProducto}
          onSeleccionarCategoria={abrirCategoria}
          publicaciones={publicaciones}
          carrito={carrito}
          deseos={deseos}
          usuarioActivo={usuarioActivo}
          empresaActiva={empresaActiva}
          usuarios={usuariosRegistrados}
        />
      )}

      <div className="cv-pantalla">
        {vistaActual === 'login' && (
          <Login
            onOpenRegistro={() => setMostrarRegistro(true)}
            onLoginSuccess={usuario => {
              setUsuariosRegistrados(actual => [
                ...actual.filter(
                  u =>
                    normalizarRut(u.run) !== normalizarRut(usuario.run)
                ),
                usuario
              ]);

              setUsuarioActivo(usuario);
              setHistorialVistas([]);
              setVistaActual('principal');
            }}
          />
        )}

        {(vistaActual === 'principal' || vistaActual === 'deseos') && (
          <Principal
            onNavigate={navegar}
            carrito={carrito}
            setCarrito={setCarrito}
            deseos={deseos}
            setDeseos={setDeseos}
            listasDeseos={listasDeseos}
            setListasDeseos={setListasDeseos}
            modoDeseos={vistaActual === 'deseos'}
            onElegirListas={abrirSelectorListas}
            onVerDetalle={abrirDetalleProducto}
            empresaActiva={empresaActiva}
            usuarioActivo={usuarioActivo}
            usuarios={usuariosRegistrados}
            publicaciones={publicaciones}
            categoriaDesdeMenu={categoriaDesdeMenu}
            reinicioPrincipal={reinicioPrincipal}
            onEstadoFiltro={setFiltroPrincipalActivo}
            onLimpiarCategoria={() => setCategoriaDesdeMenu(null)}
          />
        )}

        {vistaActual === 'servicios' && (
          <Servicios
            publicaciones={publicaciones}
            onVerDetalle={abrirDetalleProducto}
          />
        )}

        {vistaActual === 'detalle-producto' && (
          <DetalleProducto
            producto={productoSeleccionado}
            onNavigate={navegar}
            carrito={carrito}
            setCarrito={setCarrito}
            deseos={deseos}
            setDeseos={setDeseos}
            onElegirListas={abrirSelectorListas}
            historialCompras={historialCompras}
            onAbrirChat={handleAbrirChat}
          />
        )}

        {vistaActual === 'carrito' && (
          <Carrito
            onNavigate={navegar}
            carrito={carrito}
            setCarrito={setCarrito}
            publicaciones={publicaciones}
            deseos={deseos}
            usuarioActivo={usuarioActivo}
            empresaActiva={empresaActiva}
            onVerDetalle={abrirDetalleProducto}
            onAbrirChat={handleAbrirChat}
            onCompraExitosa={async compra => {
              try {
                const resultado = await apiNegocio(
                  '/api/pedidos',
                  'POST',
                  {
                    productos: compra.productos.map(p => ({
                      id: p.id,
                      cantidad: p.cantidad || 1
                    })),
                    region: compra.region
                  }
                );

                const guardada = {
                  ...compra,
                  ...resultado,
                  id: resultado.pedidoId,
                  ubicacionDespacho: resultado.region,
                  medioPago: 'Simulado',
                  exito: true,
                  numeroSeguimiento: 'PED-' + resultado.pedidoId,
                  fecha: new Date(
                    resultado.fecha
                  ).toLocaleString('es-CL')
                };

                setHistorialCompras(actual => [
                  guardada,
                  ...actual
                ]);

                setCompraReciente(guardada);

                cargarPublicaciones().catch(
                  error => console.error(
                    'recargar catálogo:',
                    error
                  )
                );

                return true;

              } catch (error) {
                alert(error.message);
                return false;
              }
            }}


              onIrCotizacion={productos => {
              setProdsCotizacion(productos);
              navegar('cotizacion');
            }}
          />
        )}

        {vistaActual === 'perfil' && (
          <Perfil
            onNavigate={navegar}
            usuarioActivo={usuarioActivo}
            onActualizarUsuario={actualizarUsuario}
            onEliminarCuenta={eliminarCuenta}
          />
        )}

        {vistaActual === 'mis-compras' && (
          <MisCompras
            onNavigate={navegar}
            historial={historialCompras}
          />
        )}

        {vistaActual === 'comprobante-pago' && (
          <ComprobantePago
            onNavigate={navegar}
            datosUltimaCompra={compraReciente}
          />
        )}

        {vistaActual === 'cotizacion' && (
          <Cotizacion
            onNavigate={navegar}
            productosCotizar={prodsCotizacion}
            onSolicitar={async productos => {
              try {
                const resultado = await apiNegocio(
                  '/api/cotizaciones',
                  'POST',
                  {
                    productos: productos.map(p => ({
                      id: p.id,
                      cantidad: p.cantidad || 1
                    }))
                  }
                );

                return {
                  ok: true,
                  id: resultado.cotizacionId
                };

              } catch (error) {
                return {
                  ok: false,
                  error: error.message
                };
              }
            }}
          />
        )}

        {vistaActual === 'chat' && (
          <Chat onNavigate={navegar} chats={chats} chatActivoInicial={chatActivo}
            onCargarChats={cargarChats} onChatApi={apiNegocio} />
        )}

        {vistaActual === 'gestion-ventas' && (
          <GestionComercial onNavigate={navegar} api={apiNegocio} vendedor />
        )}
        {vistaActual === 'gestion-compras' && (
          <GestionComercial onNavigate={navegar} api={apiNegocio} />
        )}

        {vistaActual === 'registro-empresa' && (
          <RegistroEmpresa
            onNavigate={navegar}
            usuarioActivo={usuarioActivo}
            empresasRegistradas={empresasRegistradas}
            onEmpresaCreada={crearEmpresa}
          />
        )}

        {vistaActual === 'mi-empresa' && (
          <MiEmpresa
            empresaActiva={empresaActiva}
            publicaciones={publicaciones}
            historialCompras={historialVentas}
            onNavigate={navegar}
            empresasRegistradas={empresasRegistradas}
            onActualizarEmpresa={actualizarEmpresa}
          />
        )}

        {vistaActual === 'publicar-producto' && (
          <PublicarItem
            key="publicar-producto"
            tipoPublicacion="Producto"
            onNavigate={navegar}
            onAgregarPublicacion={agregarPublicacion}
            empresaActiva={empresaActiva}
          />
        )}

        {vistaActual === 'publicar-servicio' && (
          <PublicarItem
            key="publicar-servicio"
            tipoPublicacion="Servicio"
            onNavigate={navegar}
            onAgregarPublicacion={agregarPublicacion}
            empresaActiva={empresaActiva}
          />
        )}

        {vistaActual === 'mis-ventas' && (
          <MisVentas
            onNavigate={navegar}
            publicaciones={publicaciones}
            empresaActiva={empresaActiva}
            onGuardarPublicacion={guardarPublicacion}
            onEliminarPublicacion={eliminarPublicacion}
            historialCompras={historialVentas}
          />
        )}

        {vistaActual === 'admin-panel' && (
          <AdminPanel
            onNavigate={navegar}
            usuarios={adminUsuarios}
            publicaciones={adminPublicaciones}
            empresasRegistradas={adminEmpresas}
            usuarioActivo={usuarioActivo}
            seccion={seccionAdmin}
            onCambiarSeccion={setSeccionAdmin}
            onAdminCargar={cargarAdmin}
            onAdminAccion={apiNegocio}
          />
        )}

        {mostrarRegistro && vistaActual === 'login' && (
          <Registro
            onClose={() => setMostrarRegistro(false)}
            onRegistroExitoso={async nuevoUsuario => {
              try {
                const respuesta = await fetch(
                  'http://localhost:3000/api/registro',
                  {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(nuevoUsuario)
                  }
                );

                const datos = await respuesta.json();

                if (!respuesta.ok) {
                  return {
                    ok: false,
                    error: datos.error || 'no se pudo crear la cuenta.'
                  };
                }

                setUsuariosRegistrados(actual => [
                  ...actual,
                  datos.usuario
                ]);

                setMostrarRegistro(false);
                return { ok: true };

              } catch {
                return {
                  ok: false,
                  error: 'no se pudo conectar con el backend.'
                };
              }
            }}
          />
        )}

        {productoParaListas && (
          <div
            className="listas-modal-fondo"
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 9999,
              background: 'rgba(0,0,0,.55)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 16
            }}
            onMouseDown={() => setProductoParaListas(null)}
          >
            <section
              className="listas-modal selector-listas-modal"
              role="dialog"
              aria-modal="true"
              aria-label="Elegir listas de deseos"
              onMouseDown={evento => evento.stopPropagation()}
              style={{
                background: 'white',
                borderRadius: 18,
                padding: 24,
                width: 'min(100%, 460px)',
                maxHeight: '85vh',
                overflowY: 'auto',
                color: '#222',
                position: 'relative'
              }}
            >
              <button
                type="button"
                aria-label="Cerrar"
                onClick={() => setProductoParaListas(null)}
                style={{
                  position: 'absolute',
                  top: 12,
                  right: 16,
                  border: 0,
                  background: 'transparent',
                  fontSize: 28,
                  cursor: 'pointer'
                }}
              >
                ×
              </button>

              <h2 style={{ margin: '0 35px 12px 0' }}>
                ♡+ Agregar a mis listas
              </h2>

              <p>
                Selecciona las listas para{' '}
                <strong>{productoParaListas.titulo}</strong>:
              </p>

              <div style={{
                display: 'grid',
                gap: 12,
                margin: '18px 0'
              }}>
                {listasDeseos.map(lista => (
                  <label
                    key={lista.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: 12,
                      border: '1px solid #ddd',
                      borderRadius: 10,
                      cursor: 'pointer'
                    }}
                  >
                    <span>{lista.nombre}</span>

                    <input
                      type="checkbox"
                      checked={listasMarcadas.includes(String(lista.id))}
                      onChange={e =>
                        setListasMarcadas(actual =>
                          e.target.checked
                            ? [...new Set([
                                ...actual,
                                String(lista.id)
                              ])]
                            : actual.filter(
                                id => id !== String(lista.id)
                              )
                        )
                      }
                    />
                  </label>
                ))}
              </div>

              <button
                type="button"
                onClick={guardarEnListas}
                style={{
                  background: '#ff6600',
                  border: 0,
                  color: '#fff',
                  padding: '12px 20px',
                  borderRadius: 10,
                  fontWeight: 700,
                  width: '100%',
                  cursor: 'pointer'
                }}
              >
                Guardar cambios
              </button>

              <p style={{ fontSize: 12, color: '#666' }}>
                Puedes elegir varias listas. Si desmarcas todas,
                se quitará de favoritos.
              </p>
            </section>
          </div>
        )}
      </div>
    </div>
  );
}
