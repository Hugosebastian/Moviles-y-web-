
const crypto = require('node:crypto');

const IMG = '/productos/sin-imagen.svg';

const ENVIO = {
  'Arica y Parinacota': 12990,
  Tarapacá: 11990,
  Antofagasta: 9990,
  Atacama: 8990,
  Coquimbo: 6990,
  Valparaíso: 4990,
  'Región Metropolitana': 3990,
  "Libertador General Bernardo O'Higgins": 4990,
  Maule: 5490,
  Ñuble: 5990,
  Biobío: 5990,
  'La Araucanía': 6990,
  'Los Ríos': 8990,
  'Los Lagos': 12000,
  'Aysén del General Carlos Ibáñez del Campo': 16990,
  'Magallanes y de la Antártica Chilena': 18990
};

const EXTRA = [
  'oferta', 'img', 'imagenes', 'seccion',
  'condicion', 'marca', 'color', 'tamano',
  'peso', 'materialPrincipal', 'tiempo',
  'metodoEntrega', 'restriccionEdad'
];

const CAMPOS = `
  p.*, e.nombre_empresa, u.run AS propietario_run
  FROM publicaciones p
  JOIN empresas e ON e.id = p.empresa_id
  JOIN usuarios u ON u.id = e.propietario_id
`;

function salida(p) {
  const datos = p.datos || {};

  return {
    ...datos,
    id: String(p.id),
    tipo: p.tipo,
    titulo: p.titulo,
    descripcion: p.descripcion,
    categoria: p.categoria,
    precioNum: Number(p.precio),
    precioStr: '$' + Number(p.precio).toLocaleString('es-CL'),
    stock: Number(p.stock),
    img: datos.img || IMG,
    imagenes: datos.imagenes?.length
      ? datos.imagenes
      : [datos.img || IMG],
    empresaId: String(p.empresa_id),
    vendedorId: String(p.empresa_id),
    empresaNombre: p.nombre_empresa,
    vendedor: p.nombre_empresa,
    propietarioRun: p.propietario_run
  };
}

function validarPublicacion(b, tipo) {
  const titulo = String(b.titulo || '').trim();
  const descripcion = String(b.descripcion || '').trim();
  const categoria = String(b.categoria || '').trim();
  const precio = Number(b.precioNum);
  const stock = Number(b.stock);

  if (
    titulo.length < 3 ||
    titulo.length > 150 ||
    descripcion.length < 10 ||
    descripcion.length > 5000 ||
    categoria.length > 100
  ) {
    throw new Error(
      'revisa el título, descripción y categoría.'
    );
  }

  if (
    !Number.isSafeInteger(precio) ||
    precio <= 0 ||
    precio > 1000000000
  ) {
    throw new Error(
      'el precio debe ser un entero positivo válido.'
    );
  }

  if (
    !Number.isSafeInteger(stock) ||
    stock < 0 ||
    stock > 1000000
  ) {
    throw new Error(
      'el stock debe ser un entero entre 0 y 1000000.'
    );
  }

  const datos = {};

  for (const k of EXTRA) {
    if (b[k] === undefined) continue;

    if (k === 'imagenes') {
      if (
        !Array.isArray(b[k]) ||
        b[k].length > 5 ||
        b[k].some(
          v => typeof v !== 'string' ||
            v.length > 2000000
        )
      ) {
        throw new Error('las imágenes no son válidas.');
      }

      datos[k] = b[k];

    } else {
      if (
        typeof b[k] !== 'string' ||
        b[k].length > (k === 'img' ? 2000000 : 250)
      ) {
        throw new Error(
          'los datos adicionales no son válidos.'
        );
      }

      datos[k] = b[k];
    }
  }

  const descuento = Number(
    String(datos.oferta || '0').replace('%', '')
  );

  if (
    !Number.isFinite(descuento) ||
    descuento < 0 ||
    descuento > 100
  ) {
    throw new Error('la oferta no es válida.');
  }

  return {
    tipo,
    titulo,
    descripcion,
    categoria,
    precio,
    stock,
    datos
  };
}

function fallo(res, err) {
  console.error('negocio-api:', err);

  res.status(500).json({
    error: 'error del servidor. revisa la terminal de Node.js.'
  });
}

function registrarRutasNegocio(app, pool) {

  async function autenticar(req, res, next) {
    const token = (req.headers.cookie || '')
      .split(';')
      .map(x => x.trim())
      .find(x => x.startsWith('cv_sesion='))
      ?.slice('cv_sesion='.length);

    if (!token || !/^[a-f0-9]{64}$/.test(token)) {
      return res.status(401).json({
        error: 'inicia sesión.'
      });
    }

    try {
      const hash = crypto
        .createHash('sha256')
        .update(token)
        .digest('hex');

      const r = await pool.query(
        `SELECT s.usuario_id
         FROM sesiones s
         JOIN usuarios u ON u.id = s.usuario_id
         WHERE s.token_hash = $1
           AND s.expira_en > NOW()
           AND u.estado_cuenta = 'Activa'`,
        [hash]
      );

      if (!r.rows.length) {
        return res.status(401).json({
          error: 'sesión vencida.'
        });
      }

      req.usuarioId = r.rows[0].usuario_id;
      next();

    } catch (e) {
      fallo(res, e);
    }
  }

  // Proteger operaciones que modifican datos.
  app.use(
    ['/api/publicaciones', '/api/pedidos', '/api/cotizaciones'],
    (req, res, next) => {
      if (
        ['GET', 'HEAD', 'OPTIONS'].includes(req.method)
      ) {
        return next();
      }

      const origen =
        process.env.FRONTEND_ORIGIN ||
        'http://localhost:5173';

      if (req.headers.origin !== origen) {
        return res.status(403).json({
          error: 'origen no permitido.'
        });
      }

      next();
    }
  );

  // Mostrar catálogo.
  app.get('/api/publicaciones', async (_req, res) => {
    try {
      const r = await pool.query(
        `SELECT ${CAMPOS}
         WHERE p.activa = TRUE AND e.activa = TRUE
         ORDER BY p.id DESC
         LIMIT 500`
      );

      res.json({
        publicaciones: r.rows.map(salida)
      });

    } catch (e) {
      fallo(res, e);
    }
  });

  // Publicar producto o servicio.
  app.post(
    '/api/publicaciones',
    autenticar,
    async (req, res) => {
      try {
        const empresa = await pool.query(
          `SELECT id
           FROM empresas
           WHERE propietario_id = $1 AND activa = TRUE`,
          [req.usuarioId]
        );

        if (!empresa.rows.length) {
          return res.status(403).json({
            error: 'primero registra una empresa.'
          });
        }

        const tipo = req.body?.tipo;

        if (!['Producto', 'Servicio'].includes(tipo)) {
          return res.status(400).json({
            error: 'tipo de publicación inválido.'
          });
        }

        const d = validarPublicacion(
          req.body || {},
          tipo
        );

        const r = await pool.query(
          `INSERT INTO publicaciones (
            empresa_id, tipo, titulo, descripcion,
            categoria, precio, stock, datos
          )
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
          RETURNING id`,
          [
            empresa.rows[0].id,
            d.tipo,
            d.titulo,
            d.descripcion,
            d.categoria,
            d.precio,
            d.stock,
            JSON.stringify(d.datos)
          ]
        );

        const p = await pool.query(
          `SELECT ${CAMPOS} WHERE p.id = $1`,
          [r.rows[0].id]
        );

        res.status(201).json({
          publicacion: salida(p.rows[0])
        });

      } catch (e) {
        if (
          e.message.startsWith('revisa') ||
          e.message.startsWith('el ') ||
          e.message.startsWith('las ')
        ) {
          return res.status(400).json({
            error: e.message
          });
        }

        fallo(res, e);
      }
    }
  );

  // Editar publicación propia.
  app.patch(
    '/api/publicaciones/:id',
    autenticar,
    async (req, res) => {
      try {
        const anterior = await pool.query(
          `SELECT p.*
           FROM publicaciones p
           JOIN empresas e ON e.id = p.empresa_id
           WHERE p.id = $1
             AND e.propietario_id = $2
             AND p.activa = TRUE`,
          [req.params.id, req.usuarioId]
        );

        if (!anterior.rows.length) {
          return res.status(404).json({
            error: 'publicación no encontrada o sin permisos.'
          });
        }

        const p = anterior.rows[0];

        const d = validarPublicacion(
          {
            ...p.datos,
            titulo: p.titulo,
            descripcion: p.descripcion,
            categoria: p.categoria,
            precioNum: p.precio,
            stock: p.stock,
            ...req.body
          },
          p.tipo
        );

        await pool.query(
          `UPDATE publicaciones
           SET titulo = $1,
               descripcion = $2,
               categoria = $3,
               precio = $4,
               stock = $5,
               datos = $6
           WHERE id = $7 AND activa = TRUE`,
          [
            d.titulo,
            d.descripcion,
            d.categoria,
            d.precio,
            d.stock,
            JSON.stringify(d.datos),
            p.id
          ]
        );

        const r = await pool.query(
          `SELECT ${CAMPOS} WHERE p.id = $1`,
          [p.id]
        );

        res.json({
          publicacion: salida(r.rows[0])
        });

      } catch (e) {
        if (
          e.message.startsWith('revisa') ||
          e.message.startsWith('el ') ||
          e.message.startsWith('las ')
        ) {
          return res.status(400).json({
            error: e.message
          });
        }

        fallo(res, e);
      }
    }
  );

  // Ocultar publicación propia.
  app.delete(
    '/api/publicaciones/:id',
    autenticar,
    async (req, res) => {
      try {
        const r = await pool.query(
          `UPDATE publicaciones p
           SET activa = FALSE
           FROM empresas e
           WHERE p.id = $1
             AND e.id = p.empresa_id
             AND e.propietario_id = $2
             AND p.activa = TRUE
           RETURNING p.id`,
          [req.params.id, req.usuarioId]
        );

        if (!r.rowCount) {
          return res.status(404).json({
            error: 'publicación no encontrada o sin permisos.'
          });
        }

        res.json({ ok: true });

      } catch (e) {
        fallo(res, e);
      }
    }
  );

  // Validar productos usando precios de PostgreSQL.
  async function prepararItems(
    cliente,
    productos,
    compradorId,
    bloquear
  ) {
    if (
      !Array.isArray(productos) ||
      !productos.length ||
      productos.length > 30
    ) {
      throw new Error(
        'selecciona entre 1 y 30 productos.'
      );
    }

    const ids = productos.map(x => String(x.id));

    if (
      new Set(ids).size !== ids.length ||
      ids.some(id => !/^\d+$/.test(id))
    ) {
      throw new Error(
        'productos inválidos o repetidos.'
      );
    }

    const items = [];
    let empresaId = null;

    for (
      const item of [...productos].sort(
        (a, b) => Number(a.id) - Number(b.id)
      )
    ) {
      const cantidad = Number(item.cantidad ?? 1);

      if (
        !Number.isSafeInteger(cantidad) ||
        cantidad < 1 ||
        cantidad > 1000
      ) {
        throw new Error('cantidad inválida.');
      }

      const r = await cliente.query(
        `SELECT
           p.id, p.empresa_id, p.tipo, p.titulo,
           p.precio, p.stock, e.propietario_id
         FROM publicaciones p
         JOIN empresas e ON e.id = p.empresa_id
         WHERE p.id = $1 AND p.activa = TRUE AND e.activa = TRUE
         ${bloquear ? 'FOR UPDATE OF p' : ''}`,
        [item.id]
      );

      const p = r.rows[0];

      if (!p || p.tipo !== 'Producto') {
        throw new Error(
          'uno de los productos ya no está disponible.'
        );
      }

      if (
        String(p.propietario_id) ===
        String(compradorId)
      ) {
        throw new Error(
          'no puedes comprar tus propios productos.'
        );
      }

      if (
        empresaId &&
        String(empresaId) !== String(p.empresa_id)
      ) {
        throw new Error(
          'selecciona productos de una sola empresa.'
        );
      }

      empresaId = p.empresa_id;

      if (
        bloquear &&
        Number(p.stock) < cantidad
      ) {
        throw new Error(
          `stock insuficiente para ${p.titulo}.`
        );
      }

      items.push({
        ...p,
        cantidad
      });
    }

    return {
      items,
      empresaId,
      subtotal: items.reduce(
        (n, p) =>
          n + Number(p.precio) * p.cantidad,
        0
      )
    };
  }

  async function registrarOperacion(req, res, tipo) {
    const cliente = await pool.connect()
      .catch(() => null);

    if (!cliente) {
      return res.status(500).json({
        error: 'base de datos no disponible.'
      });
    }

    try {
      await cliente.query('BEGIN');

      const d = await prepararItems(
        cliente,
        req.body?.productos,
        req.usuarioId,
        tipo === 'pedido'
      );

      let registro;

      if (tipo === 'pedido') {
        const region = String(req.body?.region || '');

        if (!Object.hasOwn(ENVIO, region)) {
          throw new Error(
            'región de despacho inválida.'
          );
        }

        const iva = Math.round(
          d.subtotal * 0.19
        );

        const envio = ENVIO[region];
        const total = d.subtotal + iva + envio;

        registro = await cliente.query(
          `INSERT INTO pedidos (
            comprador_id, empresa_id, region,
            medio_pago, subtotal, iva,
            costo_envio, total, estado
          )
          VALUES (
            $1, $2, $3, 'Simulado',
            $4, $5, $6, $7, 'Registrado'
          )
          RETURNING id, creada_en`,
          [
            req.usuarioId,
            d.empresaId,
            region,
            d.subtotal,
            iva,
            envio,
            total
          ]
        );

        for (const p of d.items) {
          await cliente.query(
            `INSERT INTO pedido_detalles (
              pedido_id, publicacion_id,
              titulo, precio_unitario, cantidad
            )
            VALUES ($1,$2,$3,$4,$5)`,
            [
              registro.rows[0].id,
              p.id,
              p.titulo,
              p.precio,
              p.cantidad
            ]
          );

          await cliente.query(
            `UPDATE publicaciones
             SET stock = stock - $1
             WHERE id = $2`,
            [p.cantidad, p.id]
          );
        }

        await cliente.query('COMMIT');

        return res.status(201).json({
          pedidoId: String(registro.rows[0].id),
          totalPagado: total,
          subtotal: d.subtotal,
          iva,
          costoEnvio: envio,
          region,
          fecha: registro.rows[0].creada_en,
          estado: 'Registrado',
          medioPago: 'Simulado'
        });
      }

      registro = await cliente.query(
        `INSERT INTO cotizaciones (
          solicitante_id, empresa_id,
          total, estado
        )
        VALUES ($1,$2,$3,'Solicitada')
        RETURNING id`,
        [
          req.usuarioId,
          d.empresaId,
          d.subtotal
        ]
      );

      for (const p of d.items) {
        await cliente.query(
          `INSERT INTO cotizacion_detalles (
            cotizacion_id, publicacion_id,
            titulo, precio_unitario, cantidad
          )
          VALUES ($1,$2,$3,$4,$5)`,
          [
            registro.rows[0].id,
            p.id,
            p.titulo,
            p.precio,
            p.cantidad
          ]
        );
      }

      await cliente.query('COMMIT');

      res.status(201).json({
        cotizacionId: String(
          registro.rows[0].id
        ),
        estado: 'Solicitada',
        total: d.subtotal
      });

    } catch (e) {
      await cliente.query('ROLLBACK')
        .catch(() => {});

      if (e.message && !e.code) {
        return res.status(400).json({
          error: e.message
        });
      }

      fallo(res, e);

    } finally {
      cliente.release();
    }
  }

  app.post(
    '/api/pedidos',
    autenticar,
    (req, res) =>
      registrarOperacion(req, res, 'pedido')
  );

  app.post(
    '/api/cotizaciones',
    autenticar,
    (req, res) =>
      registrarOperacion(req, res, 'cotizacion')
  );

  // Historial del comprador.
  app.get(
    '/api/pedidos/mios',
    autenticar,
    async (req, res) => {
      try {
        const r = await pool.query(
          `SELECT
             p.id, p.region, p.total, p.estado,
             p.transportista, p.numero_seguimiento,
             p.creada_en, d.titulo,
             d.precio_unitario, d.cantidad,
             d.publicacion_id, pub.datos,
             pub.empresa_id
           FROM pedidos p
           JOIN pedido_detalles d
             ON d.pedido_id = p.id
           JOIN publicaciones pub
             ON pub.id = d.publicacion_id
           WHERE p.comprador_id = $1
           ORDER BY p.id DESC, d.id ASC`,
          [req.usuarioId]
        );

        const map = new Map();

        for (const f of r.rows) {
          const id = String(f.id);

          if (!map.has(id)) {
            map.set(id, {
              id,
              fecha: new Date(
                f.creada_en
              ).toLocaleString('es-CL'),
              ubicacionDespacho: f.region,
              estado: f.estado,
              transportista: f.transportista || '',
              numeroSeguimiento: f.numero_seguimiento || '',
              totalPagado: Number(f.total),
              productos: []
            });
          }

          map.get(id).productos.push({
            id: String(f.publicacion_id),
            titulo: f.titulo,
            precioNum: Number(
              f.precio_unitario
            ),
            cantidad: f.cantidad,
            empresaId: String(f.empresa_id),
            img: f.datos?.img || IMG
          });
        }

        res.json({
          pedidos: [...map.values()]
        });

      } catch (e) {
        fallo(res, e);
      }
    }
  );

  // Historial de ventas de la empresa.
  app.get(
    '/api/pedidos/ventas',
    autenticar,
    async (req, res) => {
      try {
        const r = await pool.query(
          `SELECT
             p.id, p.region, p.total, p.estado,
             p.transportista, p.numero_seguimiento,
             p.creada_en, d.titulo,
             d.precio_unitario, d.cantidad,
             d.publicacion_id, pub.datos,
             pub.empresa_id, pub.tipo
           FROM pedidos p
           JOIN empresas e
             ON e.id = p.empresa_id
           JOIN pedido_detalles d
             ON d.pedido_id = p.id
           JOIN publicaciones pub
             ON pub.id = d.publicacion_id
           WHERE e.propietario_id = $1
           ORDER BY p.id DESC, d.id ASC`,
          [req.usuarioId]
        );

        const map = new Map();

        for (const f of r.rows) {
          const id = String(f.id);

          if (!map.has(id)) {
            map.set(id, {
              id,
              fecha: new Date(
                f.creada_en
              ).toLocaleString('es-CL'),
              ubicacionDespacho: f.region,
              estado: f.estado,
              transportista: f.transportista || '',
              numeroSeguimiento: f.numero_seguimiento || '',
              totalPagado: Number(f.total),
              productos: []
            });
          }

          map.get(id).productos.push({
            id: String(f.publicacion_id),
            titulo: f.titulo,
            precioNum: Number(
              f.precio_unitario
            ),
            cantidad: f.cantidad,
            empresaId: String(f.empresa_id),
            tipo: f.tipo,
            img: f.datos?.img || IMG
          });
        }

        res.json({
          pedidos: [...map.values()]
        });

      } catch (e) {
        fallo(res, e);
      }
    }
  );

  // Cotizaciones del usuario.
  app.get(
    '/api/cotizaciones/mias',
    autenticar,
    async (req, res) => {
      try {
        const r = await pool.query(
          `SELECT id, total, estado, creada_en
           FROM cotizaciones
           WHERE solicitante_id = $1
           ORDER BY id DESC
           LIMIT 100`,
          [req.usuarioId]
        );

        res.json({
          cotizaciones: r.rows
        });

      } catch (e) {
        fallo(res, e);
      }
    }
  );
}

module.exports = {
  registrarRutasNegocio
};
