const crypto = require('node:crypto');
const cookieName = 'cv_sesion';

function instalarMejoras(app, pool) {
  const ejecutar = (sql, args = []) => pool.query(sql, args);
  const responderError = (res, err) => {
    console.error('mejoras-api:', err.message);
    return res.status(500).json({ error: 'Error interno. Revisa la terminal del backend.' });
  };
  const validarId = id => /^\d+$/.test(String(id));
  const permiso = async (req, res, next) => {
    try {
      const token = (req.headers.cookie || '').split(';').map(x => x.trim())
        .find(x => x.startsWith(cookieName + '='))?.slice(cookieName.length + 1);
      if (!token || !/^[a-f0-9]{64}$/.test(token)) return res.status(401).json({ error: 'Inicia sesión.' });
      const hash = crypto.createHash('sha256').update(token).digest('hex');
      const r = await ejecutar(`SELECT s.usuario_id FROM sesiones s
        JOIN usuarios u ON u.id=s.usuario_id
        WHERE s.token_hash=$1 AND s.expira_en > NOW() AND u.estado_cuenta='Activa'`, [hash]);
      if (!r.rowCount) return res.status(401).json({ error: 'Sesión vencida.' });
      req.usuarioId = r.rows[0].usuario_id;
      next();
    } catch (err) { responderError(res, err); }
  };
  const admin = async (req, res, next) => {
    try {
      const r = await ejecutar(`SELECT 1 FROM usuario_roles ur JOIN roles r ON r.id=ur.rol_id
        WHERE ur.usuario_id=$1 AND r.nombre='Administrador'`, [req.usuarioId]);
      if (!r.rowCount) return res.status(403).json({ error: 'Solo administradores aprobados.' });
      next();
    } catch (err) { responderError(res, err); }
  };
  const origen = (req, res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    const permitido = process.env.FRONTEND_ORIGIN || 'http://localhost:5173';
    if (req.headers.origin && req.headers.origin !== permitido) {
      return res.status(403).json({ error: 'Origen no permitido.' });
    }
    next();
  };
  app.use(['/api/admin', '/api/chats', '/api/listas', '/api/gestion'], origen);

  const obtenerAdmin = async () => {
    const [usuarios, empresas, publicaciones] = await Promise.all([
      ejecutar(`SELECT u.id,u.run,u.nombre_completo,u.correo,u.estado_cuenta,
        COALESCE((SELECT array_agg(r.nombre ORDER BY r.id) FROM usuario_roles ur JOIN roles r ON r.id=ur.rol_id WHERE ur.usuario_id=u.id),ARRAY[]::varchar[]) AS roles,
        (SELECT estado FROM solicitudes_administrador WHERE usuario_id=u.id ORDER BY fecha_solicitud DESC,id DESC LIMIT 1) AS solicitud
        FROM usuarios u ORDER BY u.id DESC`),
      ejecutar(`SELECT e.*,u.run AS propietario_run FROM empresas e JOIN usuarios u ON u.id=e.propietario_id ORDER BY e.id DESC`),
      ejecutar(`SELECT p.*,e.nombre_empresa,u.run AS propietario_run FROM publicaciones p
        JOIN empresas e ON e.id=p.empresa_id JOIN usuarios u ON u.id=e.propietario_id ORDER BY p.id DESC`)
    ]);
    return {
      usuarios: usuarios.rows.map(u => ({ id: String(u.id), run:u.run, nombreCompleto:u.nombre_completo, correo:u.correo,
        estadoCuenta:u.estado_cuenta, tipoPerfil:u.roles, estadoAdmin:u.roles.includes('Administrador') ? 'Aprobado' : u.solicitud })),
      empresas: empresas.rows.map(e => ({ id:String(e.id), propietarioRun:e.propietario_run, nombreEmpresa:e.nombre_empresa,
        runEmpresa:e.rut_empresa, correo:e.correo, activa:e.activa })),
      publicaciones: publicaciones.rows.filter(p => p.activa && p.activa_empresa !== false).map(p => ({
        id:String(p.id), tipo:p.tipo, titulo:p.titulo, descripcion:p.descripcion, categoria:p.categoria,
        precioNum:Number(p.precio), precioStr:'$'+Number(p.precio).toLocaleString('es-CL'), stock:p.stock,
        empresaId:String(p.empresa_id), empresaNombre:p.nombre_empresa, ...p.datos
      }))
    };
  };
  app.get('/api/admin/resumen', permiso, admin, async (_req, res) => {
    try { res.json(await obtenerAdmin()); } catch (e) { responderError(res, e); }
  });
  app.patch('/api/admin/usuarios/:id/solicitud', permiso, admin, async (req, res) => {
    if (!validarId(req.params.id) || !['Aprobada','Rechazada'].includes(req.body?.estado)) return res.status(400).json({error:'Datos inválidos.'});
    const c = await pool.connect();
    try {
      await c.query('BEGIN');
      const solicitud = await c.query(`SELECT id FROM solicitudes_administrador WHERE usuario_id=$1 AND estado='Pendiente' ORDER BY id DESC LIMIT 1 FOR UPDATE`, [req.params.id]);
      if (!solicitud.rowCount) { await c.query('ROLLBACK'); return res.status(404).json({error:'No hay solicitud pendiente.'}); }
      await c.query(`UPDATE solicitudes_administrador SET estado=$1 WHERE id=$2`, [req.body.estado, solicitud.rows[0].id]);
      if (req.body.estado === 'Aprobada') {
        await c.query(`INSERT INTO usuario_roles(usuario_id,rol_id) SELECT $1,id FROM roles WHERE nombre='Administrador' ON CONFLICT DO NOTHING`, [req.params.id]);
      }
      await c.query('COMMIT'); res.json({ok:true});
    } catch(e) { await c.query('ROLLBACK').catch(()=>{}); responderError(res,e); } finally {c.release();}
  });
  app.patch('/api/admin/usuarios/:id/estado', permiso, admin, async (req,res) => {
    if (!validarId(req.params.id) || !['Activa','Bloqueada'].includes(req.body?.estado)) return res.status(400).json({error:'Estado inválido.'});
    if (String(req.usuarioId)===req.params.id) return res.status(403).json({error:'No puedes bloquear tu propia cuenta.'});
    try {
      const r=await ejecutar('UPDATE usuarios SET estado_cuenta=$1 WHERE id=$2 RETURNING id',[req.body.estado,req.params.id]);
      if (!r.rowCount) return res.status(404).json({error:'Usuario no encontrado.'});
      if (req.body.estado==='Bloqueada') await ejecutar('DELETE FROM sesiones WHERE usuario_id=$1',[req.params.id]);
      res.json({ok:true});
    } catch(e){responderError(res,e);}
  });
  // Desactivación reversible: no destruye historial de compras ni claves foráneas.
  app.patch('/api/admin/empresas/:id/estado', permiso, admin, async (req,res) => {
    if (!validarId(req.params.id) || typeof req.body?.activa!=='boolean') return res.status(400).json({error:'Datos inválidos.'});
    const c=await pool.connect();
    try {
      await c.query('BEGIN');
      const r=await c.query('UPDATE empresas SET activa=$1 WHERE id=$2 RETURNING id',[req.body.activa,req.params.id]);
      if (!r.rowCount){await c.query('ROLLBACK');return res.status(404).json({error:'Empresa no encontrada.'});}
      await c.query('COMMIT'); res.json({ok:true});
    } catch(e){await c.query('ROLLBACK').catch(()=>{});responderError(res,e);} finally{c.release();}
  });
  app.patch('/api/admin/publicaciones/:id', permiso, admin, async(req,res)=>{
    if (!validarId(req.params.id)) return res.status(400).json({error:'ID inválido.'});
    const b=req.body||{};
    const titulo=String(b.titulo||'').trim(), categoria=String(b.categoria||'').trim();
    const precio=Number(b.precioNum),stock=Number(b.stock);
    if(titulo.length<3||titulo.length>150||categoria.length>100||!Number.isSafeInteger(precio)||precio<=0||!Number.isSafeInteger(stock)||stock<0) return res.status(400).json({error:'Revisa nombre, categoría, precio y stock.'});
    try {
      const r=await ejecutar(`UPDATE publicaciones SET titulo=$1,categoria=$2,precio=$3,stock=$4 WHERE id=$5 AND activa=TRUE RETURNING id`,[titulo,categoria,precio,stock,req.params.id]);
      if(!r.rowCount) return res.status(404).json({error:'Publicación no encontrada.'});
      res.json({ok:true});
    }catch(e){responderError(res,e);}
  });
  app.patch('/api/admin/publicaciones/:id/estado', permiso, admin, async(req,res)=>{
    if(!validarId(req.params.id)||typeof req.body?.activa!=='boolean')return res.status(400).json({error:'Datos inválidos.'});
    try {
      const r=await ejecutar('UPDATE publicaciones SET activa=$1 WHERE id=$2 RETURNING id',[req.body.activa,req.params.id]);
      if(!r.rowCount)return res.status(404).json({error:'Publicación no encontrada.'});
      res.json({ok:true});
    }catch(e){responderError(res,e);}
  });

  // Listas de deseos: cada usuario tiene listas propias, sin localStorage.
  const listar = async id => {
    await ejecutar(`INSERT INTO listas_deseos(usuario_id,nombre,predeterminada)
      VALUES($1,'Mis favoritos',TRUE) ON CONFLICT DO NOTHING`,[id]);
    const r=await ejecutar(`SELECT l.id,l.nombre,l.predeterminada,p.id AS publicacion_id,p.titulo,p.precio,p.datos
      FROM listas_deseos l LEFT JOIN lista_deseos_items i ON i.lista_id=l.id
      LEFT JOIN publicaciones p ON p.id=i.publicacion_id AND p.activa=TRUE AND EXISTS (SELECT 1 FROM empresas ex WHERE ex.id=p.empresa_id AND ex.activa=TRUE)
      LEFT JOIN empresas e ON e.id=p.empresa_id
      WHERE l.usuario_id=$1 ORDER BY l.predeterminada DESC,l.id,i.publicacion_id`,[id]);
    const listas=new Map();
    for(const f of r.rows){const idLista=f.predeterminada?'favoritos':String(f.id);
      if(!listas.has(idLista))listas.set(idLista,{id:idLista,nombre:f.nombre,predeterminada:f.predeterminada,productos:[]});
      if(f.publicacion_id && f.titulo)listas.get(idLista).productos.push({id:String(f.publicacion_id),titulo:f.titulo,precioNum:Number(f.precio),precioStr:'$'+Number(f.precio).toLocaleString('es-CL'),img:f.datos?.img||'/productos/sin-imagen.svg'});
    }
    return [...listas.values()];
  };
  app.get('/api/listas',permiso,async(req,res)=>{try{res.json({listas:await listar(req.usuarioId)});}catch(e){responderError(res,e);}});
  app.put('/api/listas',permiso,async(req,res)=>{
    const listas=req.body?.listas;
    if(!Array.isArray(listas)||listas.length<1||listas.length>20||!listas.some(l=>l.id==='favoritos'))return res.status(400).json({error:'Listas inválidas.'});
    const nombres=new Set();
    for(const l of listas){const nombre=String(l.nombre||'').trim();
      if(nombre.length<1||nombre.length>80||nombres.has(nombre.toLowerCase())||!Array.isArray(l.productos)||l.productos.length>100||l.productos.some(p=>!validarId(p.id))||new Set(l.productos.map(p=>String(p.id))).size!==l.productos.length)return res.status(400).json({error:'Revisa nombres y productos de tus listas.'});
      nombres.add(nombre.toLowerCase());
    }
    const c=await pool.connect();
    try{
      await c.query('BEGIN');
      await c.query('SELECT id FROM usuarios WHERE id=$1 FOR UPDATE',[req.usuarioId]);
      const actual=await c.query('SELECT id,predeterminada FROM listas_deseos WHERE usuario_id=$1',[req.usuarioId]);
      const idsActual=new Set(actual.rows.map(x=>String(x.id)));
      for(const l of listas){
        let id;
        if(l.id==='favoritos'){
          const r=await c.query(`INSERT INTO listas_deseos(usuario_id,nombre,predeterminada) VALUES($1,'Mis favoritos',TRUE) ON CONFLICT DO NOTHING RETURNING id`,[req.usuarioId]);
          id=r.rows[0]?.id || actual.rows.find(x=>x.predeterminada)?.id;
          if(!id){const rr=await c.query('SELECT id FROM listas_deseos WHERE usuario_id=$1 AND predeterminada=TRUE',[req.usuarioId]);id=rr.rows[0].id;}
        }else if(validarId(l.id) && idsActual.has(String(l.id))){id=l.id;await c.query('UPDATE listas_deseos SET nombre=$1 WHERE id=$2',[l.nombre.trim(),id]);}
        else{const r=await c.query('INSERT INTO listas_deseos(usuario_id,nombre) VALUES($1,$2) RETURNING id',[req.usuarioId,l.nombre.trim()]);id=r.rows[0].id;}
        await c.query('DELETE FROM lista_deseos_items WHERE lista_id=$1',[id]);
        for(const p of l.productos){const r=await c.query(`INSERT INTO lista_deseos_items(lista_id,publicacion_id)
          SELECT $1,p.id FROM publicaciones p JOIN empresas e ON e.id=p.empresa_id WHERE p.id=$2 AND p.activa=TRUE AND e.activa=TRUE ON CONFLICT DO NOTHING RETURNING lista_id`,[id,p.id]);
          if(!r.rowCount)throw Object.assign(new Error('Un producto ya no está disponible.'),{status:400});
        }
        idsActual.delete(String(id));
      }
      for(const id of idsActual){const row=actual.rows.find(x=>String(x.id)===id);if(!row.predeterminada)await c.query('DELETE FROM listas_deseos WHERE id=$1',[id]);}
      await c.query('COMMIT');res.json({listas:await listar(req.usuarioId)});
    }catch(e){await c.query('ROLLBACK').catch(()=>{});if(e.status)return res.status(e.status).json({error:e.message});if(e.code==='23505')return res.status(409).json({error:'Ya existe una lista con ese nombre.'});responderError(res,e);}finally{c.release();}
  });

  // Chat privado: solo comprador y dueño del producto.
  const listarChats=async usuarioId=>{
    const r=await ejecutar(`SELECT c.id,c.publicacion_id,p.titulo,p.datos,e.nombre_empresa,
      comprador.nombre_completo AS comprador,vendedor.nombre_completo AS vendedor,
      c.comprador_id,c.vendedor_id FROM conversaciones c
      JOIN publicaciones p ON p.id=c.publicacion_id JOIN empresas e ON e.id=p.empresa_id
      JOIN usuarios comprador ON comprador.id=c.comprador_id JOIN usuarios vendedor ON vendedor.id=c.vendedor_id
      WHERE c.comprador_id=$1 OR c.vendedor_id=$1 ORDER BY c.id DESC`,[usuarioId]);
    return r.rows.map(x=>({id:String(x.id),publicacionId:String(x.publicacion_id),vendedorNombre:String(x.vendedor_id)===String(usuarioId)?x.comprador:x.vendedor,
      productoTitulo:x.titulo,productoImg:x.datos?.img||'/productos/sin-imagen.svg',mensajes:[]}));
  };
  app.get('/api/chats',permiso,async(req,res)=>{try{res.json({chats:await listarChats(req.usuarioId)});}catch(e){responderError(res,e);}});
  app.post('/api/chats',permiso,async(req,res)=>{
    const id=req.body?.publicacionId;
    if(!validarId(id))return res.status(400).json({error:'Selecciona una publicación válida.'});
    try{
      const r=await ejecutar(`SELECT p.id,e.propietario_id FROM publicaciones p JOIN empresas e ON e.id=p.empresa_id
        WHERE p.id=$1 AND p.activa=TRUE AND e.activa=TRUE`,[id]);
      if(!r.rowCount)return res.status(404).json({error:'Publicación no disponible.'});
      if(String(r.rows[0].propietario_id)===String(req.usuarioId))return res.status(403).json({error:'No puedes abrir un chat contigo mismo.'});
      const c=await ejecutar(`INSERT INTO conversaciones(publicacion_id,comprador_id,vendedor_id) VALUES($1,$2,$3)
        ON CONFLICT(publicacion_id,comprador_id) DO UPDATE SET vendedor_id=EXCLUDED.vendedor_id RETURNING id`,[id,req.usuarioId,r.rows[0].propietario_id]);
      res.status(201).json({id:String(c.rows[0].id)});
    }catch(e){responderError(res,e);}
  });
  const chatPropio=async(id,user)=>ejecutar('SELECT id FROM conversaciones WHERE id=$1 AND (comprador_id=$2 OR vendedor_id=$2)',[id,user]);
  app.get('/api/chats/:id/mensajes',permiso,async(req,res)=>{
    if(!validarId(req.params.id))return res.status(400).json({error:'ID inválido.'});
    try{
      if(!(await chatPropio(req.params.id,req.usuarioId)).rowCount)return res.status(404).json({error:'Chat no encontrado.'});
      const r=await ejecutar('SELECT id,remitente_id,texto,enviado_en FROM mensajes_chat WHERE conversacion_id=$1 ORDER BY id ASC LIMIT 500',[req.params.id]);
      res.json({mensajes:r.rows.map(m=>({id:String(m.id),sender:String(m.remitente_id)===String(req.usuarioId)?'mine':'other',text:m.texto,time:new Date(m.enviado_en).toLocaleTimeString('es-CL',{hour:'2-digit',minute:'2-digit'})}))});
    }catch(e){responderError(res,e);}
  });
  app.post('/api/chats/:id/mensajes',permiso,async(req,res)=>{
    const texto=String(req.body?.texto||'').trim();
    if(!validarId(req.params.id)||texto.length<1||texto.length>2000)return res.status(400).json({error:'El mensaje debe tener entre 1 y 2000 caracteres.'});
    try{
      if(!(await chatPropio(req.params.id,req.usuarioId)).rowCount)return res.status(404).json({error:'Chat no encontrado.'});
      const r=await ejecutar('INSERT INTO mensajes_chat(conversacion_id,remitente_id,texto) VALUES($1,$2,$3) RETURNING id',[req.params.id,req.usuarioId,texto]);
      res.status(201).json({id:String(r.rows[0].id)});
    }catch(e){responderError(res,e);}
  });

  // Cotizaciones: respuesta del vendedor y aceptación del solicitante.
  const cotizaciones=async(user,recibidas)=>{
    const r=await ejecutar(`SELECT c.id,c.total,c.estado,c.creada_en,c.vence_en,c.respuesta,c.respondida_en,
      e.nombre_empresa,u.nombre_completo AS solicitante,
      COALESCE(json_agg(json_build_object('titulo',d.titulo,'cantidad',d.cantidad,'precio',d.precio_unitario) ORDER BY d.id)
      FILTER(WHERE d.id IS NOT NULL),'[]'::json) AS detalles
      FROM cotizaciones c JOIN empresas e ON e.id=c.empresa_id JOIN usuarios u ON u.id=c.solicitante_id
      LEFT JOIN cotizacion_detalles d ON d.cotizacion_id=c.id
      WHERE ${recibidas?'e.propietario_id':'c.solicitante_id'}=$1
      GROUP BY c.id,e.nombre_empresa,u.nombre_completo ORDER BY c.id DESC LIMIT 100`,[user]);
    return r.rows.map(x=>({...x,id:String(x.id),total:Number(x.total),estado:(x.vence_en && new Date(x.vence_en)<new Date() && x.estado!=='Aceptada')?'Expirada':x.estado}));
  };
  app.get('/api/gestion/cotizaciones/mias',permiso,async(req,res)=>{try{res.json({cotizaciones:await cotizaciones(req.usuarioId,false)});}catch(e){responderError(res,e);}});
  app.get('/api/gestion/cotizaciones/recibidas',permiso,async(req,res)=>{try{res.json({cotizaciones:await cotizaciones(req.usuarioId,true)});}catch(e){responderError(res,e);}});
  app.patch('/api/gestion/cotizaciones/:id/responder',permiso,async(req,res)=>{
    const respuesta=String(req.body?.respuesta||'').trim();
    if(!validarId(req.params.id)||respuesta.length<3||respuesta.length>2000)return res.status(400).json({error:'Escribe una respuesta de 3 a 2000 caracteres.'});
    try{
      const r=await ejecutar(`UPDATE cotizaciones c SET respuesta=$1,respondida_en=NOW(),estado='Respondida'
        FROM empresas e WHERE c.empresa_id=e.id AND c.id=$2 AND e.propietario_id=$3
        AND c.estado IN ('Pendiente','Solicitada','Respondida') AND (c.vence_en IS NULL OR c.vence_en>NOW()) RETURNING c.id`,[respuesta,req.params.id,req.usuarioId]);
      if(!r.rowCount)return res.status(409).json({error:'Cotización no disponible o sin permisos.'});
      res.json({ok:true});
    }catch(e){responderError(res,e);}
  });
  app.patch('/api/gestion/cotizaciones/:id/aceptar',permiso,async(req,res)=>{
    if(!validarId(req.params.id))return res.status(400).json({error:'ID inválido.'});
    try{
      const r=await ejecutar(`UPDATE cotizaciones SET estado='Aceptada' WHERE id=$1 AND solicitante_id=$2
        AND estado='Respondida' AND (vence_en IS NULL OR vence_en>NOW()) RETURNING id`,[req.params.id,req.usuarioId]);
      if(!r.rowCount)return res.status(409).json({error:'La cotización no está respondida o ya venció.'});
      res.json({ok:true});
    }catch(e){responderError(res,e);}
  });
  // Estados de pedidos: solamente el propietario de la empresa.
  app.patch('/api/gestion/pedidos/:id/estado',permiso,async(req,res)=>{
    const estados=['Registrado','En preparación','Enviado','Entregado'];
    const estado=req.body?.estado;
    const transportista=String(req.body?.transportista||'').trim();
    const seguimiento=String(req.body?.numeroSeguimiento||'').trim();
    if(!validarId(req.params.id)||!estados.includes(estado)||transportista.length>120||seguimiento.length>120)return res.status(400).json({error:'Datos de pedido inválidos.'});
    if(estado==='Enviado' && (!transportista||!seguimiento))return res.status(400).json({error:'Indica transportista y número de seguimiento.'});
    try{
      const r=await ejecutar(`UPDATE pedidos p SET estado=$1,transportista=$2,numero_seguimiento=$3,actualizado_en=NOW()
        FROM empresas e WHERE p.empresa_id=e.id AND e.propietario_id=$4 AND p.id=$5
        AND ((p.estado='Registrado' AND $1='En preparación') OR
             (p.estado='En preparación' AND $1='Enviado') OR
             (p.estado='Enviado' AND $1='Entregado')) RETURNING p.id`,[estado,transportista||null,seguimiento||null,req.usuarioId,req.params.id]);
      if(!r.rowCount)return res.status(409).json({error:'No se puede realizar ese cambio de estado o no tienes permisos.'});
      res.json({ok:true});
    }catch(e){responderError(res,e);}
  });
}
module.exports={instalarMejoras};
