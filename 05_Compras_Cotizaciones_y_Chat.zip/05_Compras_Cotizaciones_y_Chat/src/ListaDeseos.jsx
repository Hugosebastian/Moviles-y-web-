
import { useState } from 'react';
import './ListaDeseos.css';

function CompartirIcono() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24"
      fill="none" stroke="currentColor" strokeWidth="2"
      aria-hidden="true">
      <path d="M8 11 16 6M8 13l8 5" />
      <circle cx="6" cy="12" r="3" />
      <circle cx="18" cy="5" r="3" />
      <circle cx="18" cy="19" r="3" />
    </svg>
  );
}

export default function ListaDeseos({
  listasDeseos,
  setListasDeseos,
  onVerDetalle,
  onElegirListas
}) {
  const [ventana, setVentana] = useState(null);
  const [nombre, setNombre] = useState('');
  const [error, setError] = useState('');
  const [menuAbierto, setMenuAbierto] = useState(null);

  const abrirVentana = (tipo, lista = null) => {
    setVentana({ tipo, id: lista?.id });
    setNombre(tipo === 'editar' ? lista.nombre : '');
    setError('');
    setMenuAbierto(null);
  };

  const guardarNombre = (e) => {
    e.preventDefault();
    const limpio = nombre.trim();

    if (!limpio) {
      return setError('Escribe un nombre para la lista.');
    }

    if (listasDeseos.some(
      l => l.nombre.toLowerCase() === limpio.toLowerCase()
        && l.id !== ventana.id
    )) {
      return setError('Ya existe una lista con ese nombre.');
    }

    if (ventana.tipo === 'crear') {
      setListasDeseos(actual => [
        ...actual,
        {
          id: `lista-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          nombre: limpio,
          predeterminada: false,
          productos: []
        }
      ]);
    } else {
      setListasDeseos(actual =>
        actual.map(l =>
          l.id === ventana.id
            ? { ...l, nombre: limpio }
            : l
        )
      );
    }

    setVentana(null);
  };

  const eliminarLista = (lista) => {
    setMenuAbierto(null);

    if (lista.predeterminada) return;

    if (window.confirm(`¿Eliminar la lista "${lista.nombre}"?`)) {
      setListasDeseos(actual =>
        actual.filter(l => l.id !== lista.id)
      );
    }
  };

  const quitarProducto = (idLista, idProducto) => {
    setListasDeseos(actual =>
      actual.map(l =>
        l.id === idLista
          ? {
              ...l,
              productos: l.productos.filter(
                p => String(p.id) !== String(idProducto)
              )
            }
          : l
      )
    );
  };

  return (
    <main className="listas-contenido">

      <header className="listas-titulo-pagina">
        <h1>Mis listas</h1>
        <p>Organiza tus productos favoritos como quieras.</p>
      </header>

      <div className="listas-cuadricula">
        {listasDeseos.map(lista => (
          <article className="listas-tarjeta" key={lista.id}>

            <div className="listas-tarjeta-arriba">
              <div>
                {lista.predeterminada && (
                  <span className="listas-etiqueta">
                    Predeterminada
                  </span>
                )}

                <h2>{lista.nombre}</h2>
                <p>
                  {lista.productos.length}{' '}
                  {lista.productos.length === 1
                    ? 'producto'
                    : 'productos'}
                </p>
              </div>

              <div className="listas-herramientas">
                <button
                  className="listas-icono-boton"
                  type="button"
                  disabled
                  aria-label="Compartir (próximamente)"
                  title="Compartir próximamente"
                >
                  <CompartirIcono />
                </button>

                {!lista.predeterminada && (
                  <div className="listas-menu-contenedor">
                    <button
                      type="button"
                      className="listas-icono-boton listas-tres-puntos"
                      aria-label={`Opciones de ${lista.nombre}`}
                      aria-expanded={menuAbierto === lista.id}
                      onClick={() =>
                        setMenuAbierto(actual =>
                          actual === lista.id ? null : lista.id
                        )
                      }
                    >
                      ⋮
                    </button>

                    {menuAbierto === lista.id && (
                      <div className="listas-menu-opciones">
                        <button
                          type="button"
                          onClick={() => abrirVentana('editar', lista)}
                        >
                          Editar nombre
                        </button>

                        <button
                          type="button"
                          className="listas-opcion-eliminar"
                          onClick={() => eliminarLista(lista)}
                        >
                          Eliminar lista
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {lista.productos.length === 0 ? (
              <div className="listas-sin-productos">
                <span aria-hidden="true">♡</span>
                <p>Esta lista todavía no tiene productos.</p>
              </div>
            ) : (
              <div className="listas-productos">
                {lista.productos.map(p => (
                  <div className="listas-producto" key={p.id}>

                    <img
                      src={
                        p.img ||
                        p.imagenes?.[0] ||
                        '/productos/sin-imagen.svg'
                      }
                      alt={p.titulo}
                      onError={e => {
                        e.currentTarget.onerror = null;
                        e.currentTarget.src =
                          '/productos/sin-imagen.svg';
                      }}
                    />

                    <div className="listas-producto-informacion">
                      <h3>{p.titulo}</h3>
                      <strong>
                        {p.precioStr ||
                          `$${Number(p.precioNum || 0)
                            .toLocaleString('es-CL')}`}
                      </strong>

                      <button
                        type="button"
                        className="listas-enlace-detalle"
                        onClick={() => onVerDetalle?.(p)}
                      >
                        Ver producto
                      </button>
                    </div>

                    <div className="listas-producto-acciones">
                      <button
                        type="button"
                        className="listas-producto-corazon"
                        aria-label="Elegir listas"
                        title="Elegir listas"
                        onClick={() => onElegirListas(p)}
                      >
                        ♥
                      </button>

                      <button
                        type="button"
                        className="listas-quitar-producto"
                        onClick={() =>
                          quitarProducto(lista.id, p.id)
                        }
                      >
                        Quitar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </article>
        ))}
      </div>

      <div className="listas-crear-fila">
        <button
          type="button"
          className="listas-boton-principal"
          onClick={() => abrirVentana('crear')}
        >
          + Crear lista
        </button>
      </div>

      {ventana && (
        <div
          className="listas-modal-fondo"
          onMouseDown={() => setVentana(null)}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-label="Crear o editar lista"
            className="listas-modal"
            onMouseDown={e => e.stopPropagation()}
          >
            <button
              type="button"
              className="listas-modal-cerrar"
              aria-label="Cerrar"
              onClick={() => setVentana(null)}
            >
              ×
            </button>

            <div className="listas-modal-titulo">
              <span className="listas-corazon-plus">
                ♡<small>+</small>
              </span>

              <h2>
                {ventana.tipo === 'crear'
                  ? 'Crear nueva lista'
                  : 'Editar nombre'}
              </h2>
            </div>

            <form onSubmit={guardarNombre}>
              <label htmlFor="nombre-nueva-lista">
                Ingresa un nombre a la lista
              </label>

              <input
                id="nombre-nueva-lista"
                autoFocus
                maxLength="50"
                value={nombre}
                placeholder="Ej. Mis zapatillas"
                onChange={e => {
                  setNombre(e.target.value);
                  setError('');
                }}
              />

              {error && (
                <p className="listas-error">{error}</p>
              )}

              <button
                type="submit"
                className="listas-boton-principal"
              >
                {ventana.tipo === 'crear'
                  ? 'Crear lista'
                  : 'Guardar nombre'}
              </button>
            </form>
          </section>
        </div>
      )}
    </main>
  );
}
