import Logo from './Logo';

import React, { useState } from 'react';
import './DetalleProducto.css';

export default function DetalleProducto({
  producto,
  onNavigate,
  carrito,
  setCarrito,
  deseos = [],
  onElegirListas,
  historialCompras,
  onAbrirChat
}) {

  // ========================================
  // INFORMACIÓN DEL PRODUCTO
  // ========================================

  const productoData = {
    ...producto,

    id: producto?.id || 1,

    titulo:
      producto?.titulo ||
      'Jeans Baggy Hombre Bearcliff',

    marca:
      producto?.marca ||
      'BEARCLIFF',

    vendedor:
      producto?.vendedor ||
      'Falabella',

    precioStr:
      producto?.precioStr ||
      '$19.990',

    precioNum:
      producto?.precioNum ||
      19990,

    imagenes:
      producto?.imagenes?.length
        ? producto.imagenes
        : [
            producto?.img ||
            'https://cdn-icons-png.flaticon.com/512/2611/2611075.png'
          ],

    colores:
      producto?.colores || [
        {
          id: 1,
          nombre: 'Negro',
          img: 'https://cdn-icons-png.flaticon.com/512/2611/2611075.png'
        },
        {
          id: 2,
          nombre: 'Azul',
          img: 'https://cdn-icons-png.flaticon.com/512/2806/2806024.png'
        }
      ],

    tallas:
      producto?.tallas ?? [
        '40', '42', '44', '46', '48', '50'
      ],

    especificaciones:
      producto?.especificaciones || [
        {
          clave: 'Fit prenda inferior',
          valor: 'Baggy'
        },
        {
          clave: 'Tiro',
          valor: 'Medio'
        },
        {
          clave: 'Composición',
          valor: '100% Algodón'
        },
        {
          clave: 'Código producto',
          valor: '883533612'
        }
      ]
  };

  // ========================================
  // ESTADOS
  // ========================================

  const [imgIndex, setImgIndex] = useState(0);

  const [colorSel, setColorSel] = useState(
    productoData.colores[0] || {
      id: 0,
      nombre: 'Único'
    }
  );

  const [tallaSel, setTallaSel] = useState(
    productoData.tallas?.[0] || 'Única'
  );

  const [cantidad, setCantidad] = useState(1);

  // ========================================
  // LISTA DE DESEOS
  // ========================================

  const esDeseo = deseos.some(
    item =>
      String(item.id) === String(productoData.id)
  );

  const handleToggleDeseo = () => {
    if (onElegirListas) {
      onElegirListas(productoData);
    }
  };

  // ========================================
  // CARRITO
  // ========================================

  const handleAgregarAlCarrito = () => {

    const itemCarrito = {
      ...productoData,
      tallaSeleccionada: tallaSel,
      colorSeleccionado: colorSel.nombre,
      cantidad
    };

    const existe = carrito.find(
      p => p.id === productoData.id
    );

    if (existe) {

      setCarrito(actual =>
        actual.map(p =>
          p.id === productoData.id
            ? {
                ...p,
                cantidad: p.cantidad + cantidad
              }
            : p
        )
      );

    } else {

      setCarrito(actual => [
        ...actual,
        itemCarrito
      ]);

    }

    alert(
      `¡${productoData.titulo} (${cantidad} ud.) agregado al carrito!`
    );
  };

  // ========================================
  // COMPRAS Y OPINIONES
  // ========================================

  const haComprado = historialCompras?.some(
    compra =>
      compra.productos?.some(
        p => p.id === productoData.id
      )
  );

  const [nuevaResena, setNuevaResena] = useState({
    rating: 5,
    comentario: ''
  });

  const [resenasList, setResenasList] = useState([
    {
      author: 'Jorge Vásquez',
      rating: 5,
      date: 'hace 2 días',
      text: 'Muy buena calidad, corresponde a la talla elegida.'
    },
    {
      author: 'Isaac',
      rating: 5,
      date: 'hace 1 semana',
      text: 'Llegó el tamaño correspondiente y es idéntico a la foto.'
    }
  ]);

  const handlePublicarResena = (e) => {
    e.preventDefault();

    if (!nuevaResena.comentario.trim()) {
      return;
    }

    setResenasList(actual => [
      {
        author: 'Tú (Comprador verificado)',
        rating: nuevaResena.rating,
        date: 'Hoy',
        text: nuevaResena.comentario
      },
      ...actual
    ]);

    setNuevaResena({
      rating: 5,
      comentario: ''
    });

    alert('¡Gracias por tu reseña!');
  };

  // ========================================
  // CHAT CON VENDEDOR
  // ========================================

  const handleIniciarChat = () => {

    if (!onAbrirChat) return;

    const nuevoChat = {
      publicacionId: productoData.id,

      vendedorNombre: productoData.vendedor,

      productoTitulo: productoData.titulo,

      productoImg: productoData.imagenes[0],

      mensajes: [
        {
          id: 1,
          sender: 'other',
          text: `¡Hola! Gracias por consultar por ${productoData.titulo}.`,
          time: '12:00'
        }
      ]
    };

    onAbrirChat(nuevoChat);
  };

  // ========================================
  // NAVEGACIÓN DE IMÁGENES
  // ========================================

  const cambiarImagen = (direccion) => {

    const total = productoData.imagenes.length;

    setImgIndex(actual =>
      (actual + direccion + total) % total
    );
  };

  // ========================================
  // INTERFAZ
  // ========================================

  return (
    <div className="pdp-container">

      {/* BARRA SUPERIOR */}

      <nav
        className="navbar-orange"
        style={{
          padding: '10px 20px',
          display: 'flex',
          alignItems: 'center'
        }}
      >

        <button
          className="btn-back-home"
          onClick={() => onNavigate('principal')}
          style={{ marginRight: '15px' }}
        >
          &#8592; Volver a la tienda
        </button>

        <div className="logo-home-circle">

          <Logo
            alt="Logo"
            style={{ width: '25px' }}
          />

        </div>
      </nav>

      <div className="pdp-content">

        {/* =====================================
            GALERÍA E INFORMACIÓN
        ===================================== */}

        <div className="pdp-main-grid">

          {/* GALERÍA */}

          <div className="gallery-container">

            <div className="thumbs-column">

              {productoData.imagenes.map((img, idx) => (

                <button
                  key={idx}
                  className={`thumb-btn ${
                    idx === imgIndex ? 'active' : ''
                  }`}
                  onClick={() => setImgIndex(idx)}
                >
                  <img
                    src={img}
                    alt={`Imagen ${idx + 1}`}
                  />
                </button>

              ))}

            </div>

            <div className="main-image-wrapper">

              <button
                className="arrow-btn left"
                onClick={() => cambiarImagen(-1)}
              >
                &lt;
              </button>

              <img
                src={productoData.imagenes[imgIndex]}
                alt={productoData.titulo}
              />

              <button
                className="arrow-btn right"
                onClick={() => cambiarImagen(1)}
              >
                &gt;
              </button>

            </div>
          </div>

          {/* INFORMACIÓN */}

          <div className="info-column">

            <span className="brand-tag">
              {productoData.marca}
            </span>

            <h1 className="pdp-title">
              {productoData.titulo}
            </h1>

            <p className="seller-info">
              Vendido por{' '}
              <strong>
                {productoData.vendedor}
              </strong>
            </p>

            <div className="pdp-price">
              {productoData.precioStr}
            </div>

            {/* COLORES */}

            {productoData.colores.length > 0 && (
              <div>

                <div className="section-title">
                  Color: {colorSel.nombre}
                </div>

                <div className="color-swatches">

                  {productoData.colores.map(color => (

                    <button
                      key={color.id}
                      className={`swatch-btn ${
                        colorSel.id === color.id
                          ? 'active'
                          : ''
                      }`}
                      onClick={() => setColorSel(color)}
                    >
                      <img
                        src={color.img}
                        alt={color.nombre}
                      />
                    </button>

                  ))}

                </div>
              </div>
            )}

            {/* TALLAS */}

            {productoData.tallas?.length > 0 ? (

              <div>

                <div className="section-title">
                  Elige tu talla:
                </div>

                <div className="sizes-grid">

                  {productoData.tallas.map(
                    (talla, idx) => (

                      <button
                        key={idx}
                        className={`size-btn ${
                          tallaSel === talla
                            ? 'active'
                            : ''
                        }`}
                        onClick={() => setTallaSel(talla)}
                      >
                        {talla}
                      </button>

                    )
                  )}

                </div>
              </div>

            ) : (

              <div className="section-title">
                Talla: <strong>Única</strong>
              </div>

            )}

            {/* =====================================
                COMPRAR, CHAT Y FAVORITOS
            ===================================== */}

            <div className="buy-actions-row">

              {/* CANTIDAD */}

              <div className="qty-picker">

                <button
                  onClick={() =>
                    setCantidad(actual =>
                      Math.max(1, actual - 1)
                    )
                  }
                >
                  -
                </button>

                <span>{cantidad}</span>

                <button
                  onClick={() =>
                    setCantidad(actual => actual + 1)
                  }
                >
                  +
                </button>

              </div>

              {/* CARRITO */}

              <button
                className="btn-add-cart-main"
                onClick={handleAgregarAlCarrito}
              >
                Agregar al carrito
              </button>

              {/* CHAT */}

              <button
                className="btn-add-cart-main"
                style={{ background: '#20c997' }}
                onClick={handleIniciarChat}
              >
                💬 Chatear con vendedor
              </button>

              {/* CORAZÓN DE LISTA DE DESEOS */}

              <button
                type="button"
                className="btn-pdp-heart"
                onClick={handleToggleDeseo}
                title={
                  esDeseo
                    ? 'Editar mis listas de deseos'
                    : 'Agregar a mis listas de deseos'
                }
                aria-label="Elegir listas de deseos"
                style={{
                  color: esDeseo
                    ? '#e92741'
                    : '#777777',
                  fontSize: '28px'
                }}
              >
                {esDeseo ? '♥' : '♡'}
              </button>

            </div>
          </div>
        </div>

        {/* =====================================
            ESPECIFICACIONES
        ===================================== */}

        <div className="pdp-section-box">

          <h3>Especificaciones del Producto</h3>

          <div
            className="specs-list"
            style={{ marginTop: '15px' }}
          >

            {productoData.especificaciones.map(
              (spec, idx) => (

                <div
                  key={idx}
                  className="spec-item"
                >
                  <strong>{spec.clave}</strong>
                  <span>{spec.valor}</span>
                </div>

              )
            )}

          </div>
        </div>

        {/* =====================================
            OPINIONES
        ===================================== */}

        <div className="pdp-section-box">

          <h3>Opiniones del Producto</h3>

          {/* RESUMEN DE CALIFICACIONES */}

          <div
            className="reviews-dashboard"
            style={{ marginTop: '20px' }}
          >

            <div>

              <div className="rating-score-box">
                <span className="big-score">
                  4.6
                </span>
                <span>/5 ★★★★★</span>
              </div>

              <div className="star-bars">

                <div className="star-row">
                  <span>5★</span>
                  <div className="bar-bg">
                    <div
                      className="bar-fill"
                      style={{ width: '80%' }}
                    />
                  </div>
                </div>

                <div className="star-row">
                  <span>4★</span>
                  <div className="bar-bg">
                    <div
                      className="bar-fill"
                      style={{ width: '15%' }}
                    />
                  </div>
                </div>

                <div className="star-row">
                  <span>3★</span>
                  <div className="bar-bg">
                    <div
                      className="bar-fill"
                      style={{ width: '5%' }}
                    />
                  </div>
                </div>

              </div>
            </div>

            {/* MEDIDORES */}

            <div className="meters-box">

              <div className="meter-item">

                <span>Comodidad</span>

                <div className="meter-track">
                  <div
                    className="meter-pointer"
                    style={{ left: '85%' }}
                  />
                </div>

                <strong>Muy Cómodo</strong>

              </div>

              <div className="meter-item">

                <span>Tallaje</span>

                <div className="meter-track">
                  <div
                    className="meter-pointer"
                    style={{ left: '50%' }}
                  />
                </div>

                <strong>Normal</strong>

              </div>
            </div>

            {/* RECOMENDACIÓN */}

            <div className="recommend-badge">

              <div className="circle-pct">
                85%
              </div>

              <span style={{ fontSize: '12px' }}>
                Lo recomiendan
              </span>

            </div>
          </div>

          {/* LISTA DE OPINIONES */}

          <div className="reviews-grid">

            {resenasList.map((rev, idx) => (

              <div
                key={idx}
                className="review-card"
              >

                <div className="review-header">

                  <span className="review-author">
                    {rev.author}
                  </span>

                  <span className="review-date">
                    {rev.date}
                  </span>

                </div>

                <div>
                  {'★'.repeat(rev.rating)}
                </div>

                <p className="review-comment">
                  {rev.text}
                </p>

              </div>

            ))}

          </div>

          {/* =====================================
              PUBLICAR OPINIÓN
          ===================================== */}

          {haComprado ? (

            <form
              onSubmit={handlePublicarResena}
              className="add-review-box"
            >

              <h4>
                Escribe tu opinión
                (Comprador Verificado)
              </h4>

              <div style={{ margin: '10px 0' }}>

                <label htmlFor="calificacion">
                  Calificación:{' '}
                </label>

                <select
                  id="calificacion"
                  value={nuevaResena.rating}
                  onChange={e =>
                    setNuevaResena(actual => ({
                      ...actual,
                      rating: Number(e.target.value)
                    }))
                  }
                >
                  <option value={5}>5 Estrellas</option>
                  <option value={4}>4 Estrellas</option>
                  <option value={3}>3 Estrellas</option>
                  <option value={2}>2 Estrellas</option>
                  <option value={1}>1 Estrella</option>
                </select>

              </div>

              <textarea
                rows={3}
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: '6px',
                  border: '1px solid #ccc'
                }}
                placeholder="¿Qué te pareció el producto?"
                value={nuevaResena.comentario}
                onChange={e =>
                  setNuevaResena(actual => ({
                    ...actual,
                    comentario: e.target.value
                  }))
                }
                required
              />

              <button
                type="submit"
                className="btn-add-cart-main"
                style={{
                  marginTop: '10px',
                  width: 'auto'
                }}
              >
                Publicar Opinión
              </button>

            </form>

          ) : (

            <div className="review-restricted-msg">
              🔒 Solo los usuarios que han comprado
              este producto pueden dejar una opinión.
            </div>

          )}

        </div>

      </div>
    </div>
  );
}
