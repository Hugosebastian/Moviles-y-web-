import Logo from './Logo';
import React from 'react';
import './MisCompras.css';

export default function MisCompras({ onNavigate, historial }) {
  return (
    <div className="compras-page">
      {/* NAVBAR BÁSICO */}
      <nav className="navbar-orange" style={{ padding: '10px 20px', display: 'flex', alignItems: 'center' }}>
        <button className="btn-back-home" onClick={() => onNavigate('principal')} style={{ marginRight: '15px' }}>
          &#8592;
        </button>
        <div className="logo-home-circle">
          <Logo alt="Logo" style={{ width: '25px' }}/>
        </div>
      </nav>

      <div className="compras-content">
        <h2 className="compras-title">Historial de Mis Compras</h2>
        <button type="button" onClick={() => onNavigate("gestion-compras")}>Ver estados de pedidos y cotizaciones ↗</button>

        {historial.length === 0 ? (
          <p>Aún no tienes compras registradas. ¡Ve a la tienda y agrega algunos productos!</p>
        ) : (
          historial.map((compra, index) => (
            <div key={index} className="compra-card">
              
              <div className="compra-header">
                <div>
                  <p><span>Fecha de compra:</span> <strong>{compra.fecha}</strong></p>
                  <p><span>Envío a:</span> <strong>{compra.ubicacionDespacho}</strong></p>
                  <p><span>Estado:</span> <strong>{compra.estado || "Registrado"}</strong></p>
                  {compra.transportista && <p>Transporte: {compra.transportista} · Seguimiento: {compra.numeroSeguimiento}</p>}
                </div>
                <div style={{ textAlign: 'right' }}>
                  <p>Total Pagado:</p>
                  <p className="compra-total">${compra.totalPagado.toLocaleString('es-CL')}</p>
                </div>
              </div>

              <div className="compra-body">
                {compra.productos.map((prod, idx) => (
                  <div key={idx} className="compra-item">
                    <img src={prod.img} alt={prod.titulo} />
                    <div className="item-info">
                      <p className="item-title">{prod.titulo}</p>
                      <p className="item-qty">Cantidad: {prod.cantidad} x ${prod.precioNum.toLocaleString('es-CL')}</p>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          ))
        )}
      </div>
    </div>
  );
}