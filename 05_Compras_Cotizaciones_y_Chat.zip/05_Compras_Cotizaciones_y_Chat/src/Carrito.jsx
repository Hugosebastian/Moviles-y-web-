import Logo from './Logo';
import { useEffect, useMemo, useRef, useState } from 'react';
import './Carrito.css';

// Son valores de demostración, no tarifas oficiales de despacho.
// Se conservan los cuatro costos que ya tenía tu carrito.
const REGIONES = [
  { nombre: 'Arica y Parinacota', costo: 12990 },
  { nombre: 'Tarapacá', costo: 11990 },
  { nombre: 'Antofagasta', costo: 9990 },
  { nombre: 'Atacama', costo: 8990 },
  { nombre: 'Coquimbo', costo: 6990 },
  { nombre: 'Valparaíso', costo: 4990 },
  { nombre: 'Región Metropolitana', costo: 3990 },
  { nombre: "Libertador General Bernardo O'Higgins", costo: 4990 },
  { nombre: 'Maule', costo: 5490 },
  { nombre: 'Ñuble', costo: 5990 },
  { nombre: 'Biobío', costo: 5990 },
  { nombre: 'La Araucanía', costo: 6990 },
  { nombre: 'Los Ríos', costo: 8990 },
  { nombre: 'Los Lagos', costo: 12000 },
  { nombre: 'Aysén del General Carlos Ibáñez del Campo', costo: 16990 },
  { nombre: 'Magallanes y de la Antártica Chilena', costo: 18990 }
];

const formatoCLP = (numero) => `$${Math.round(Number(numero) || 0).toLocaleString('es-CL')}`;
const normalizar = (texto) => String(texto ?? '').normalize('NFD')
  .replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

// La empresa vendedora NO es lo mismo que la marca del producto.
function empresaDe(item) {
  const id = item.empresaId ?? item.vendedorId ?? item.empresa?.id ?? item.vendedor?.id;
  const nombre = item.empresaNombre
    || (typeof item.empresa === 'string' ? item.empresa : item.empresa?.nombre)
    || (typeof item.vendedor === 'string' ? item.vendedor : item.vendedor?.nombre)
    || item.vendedorNombre;

  if (id !== undefined && id !== null && String(id).trim()) {
    return { clave: `id:${id}`, nombre: nombre || `Empresa ${id}` };
  }
  if (nombre && String(nombre).trim()) {
    return { clave: `nombre:${normalizar(nombre)}`, nombre: String(nombre) };
  }
  // Si la publicación no informa empresa, no se mezcla con otra por accidente.
  return {
    clave: `sin-empresa:${item.id ?? item.titulo ?? 'desconocido'}`,
    nombre: 'Empresa no identificada'
  };
}

function precioDe(item) {
  if (Number.isFinite(Number(item.precioNum))) return Number(item.precioNum);
  return Number(String(item.precioStr ?? '0').replace(/[^\d]/g, '')) || 0;
}

function seleccionInicial(carrito) {
  if (!carrito.length) return [];
  const primeraEmpresa = empresaDe(carrito[0]).clave;
  return carrito.flatMap((item, index) =>
    empresaDe(item).clave === primeraEmpresa ? [index] : []
  );
}

export default function Carrito({
  onNavigate,
  carrito = [],
  setCarrito,
  onCompraExitosa,
  onIrCotizacion,
  onAbrirChat,
  onVerDetalle,
  publicaciones = [],
  deseos = [],
  usuarioActivo,
  empresaActiva
}) {
  const [seleccionados, setSeleccionados] = useState(() => seleccionInicial(carrito));
  const [regionSeleccionada, setRegionSeleccionada] = useState('Región Metropolitana');
  const [medioPago, setMedioPago] = useState('Debito');
  const [comprando, setComprando] = useState(false);
  const [busqueda, setBusqueda] = useState('');
  const [mostrarResultados, setMostrarResultados] = useState(false);
  const [mostrarMenu, setMostrarMenu] = useState(false);
  const [mostrarPerfil, setMostrarPerfil] = useState(false);
  const buscadorRef = useRef(null);

  // Si el carrito se vacía o se acorta desde otra pantalla, quitar índices inválidos.
  useEffect(() => {
    setSeleccionados(actual => actual.filter(i => i >= 0 && i < carrito.length));
  }, [carrito.length]);

  useEffect(() => {
    const cerrarConEscape = (e) => {
      if (e.key === 'Escape') {
        setMostrarMenu(false);
        setMostrarPerfil(false);
        setMostrarResultados(false);
      }
    };
    document.addEventListener('keydown', cerrarConEscape);
    return () => document.removeEventListener('keydown', cerrarConEscape);
  }, []);

  useEffect(() => {
    const cerrarAlClicFuera = (e) => {
      if (buscadorRef.current && !buscadorRef.current.contains(e.target)) {
        setMostrarResultados(false);
      }
    };
    document.addEventListener('mousedown', cerrarAlClicFuera);
    return () => document.removeEventListener('mousedown', cerrarAlClicFuera);
  }, []);

  const itemsAComprar = carrito.filter((_, i) => seleccionados.includes(i));
  const empresaSeleccionada = itemsAComprar.length ? empresaDe(itemsAComprar[0]) : null;

  const cambiarSeleccion = (indice) => {
    const empresaNueva = empresaDe(carrito[indice]);
    setSeleccionados(actual => {
      if (actual.includes(indice)) return actual.filter(i => i !== indice);
      const primeraSeleccionada = actual.length ? empresaDe(carrito[actual[0]]) : null;
      // Seleccionar otra empresa reemplaza la selección, sin borrar productos.
      if (primeraSeleccionada && primeraSeleccionada.clave !== empresaNueva.clave) {
        return [indice];
      }
      return [...actual, indice];
    });
  };

  const cambiarCantidad = (indice, delta) => {
    setCarrito(actual => actual.map((item, i) => i === indice
      ? { ...item, cantidad: Math.max(1, (Number(item.cantidad) || 1) + delta) }
      : item
    ));
  };

  const productosBusqueda = useMemo(() => {
    const unicos = new Map();
    [...publicaciones, ...carrito].forEach((producto) => {
      if (!producto || producto.tipo === 'Servicio') return;
      const clave = `${producto.id ?? producto.titulo}|${empresaDe(producto).clave}`;
      unicos.set(clave, producto);
    });
    return [...unicos.values()];
  }, [publicaciones, carrito]);

  const resultados = useMemo(() => {
    const palabras = normalizar(busqueda).split(/\s+/).filter(Boolean);
    if (!palabras.length) return [];
    return productosBusqueda.filter(p => {
      const texto = normalizar([
        p.titulo, p.marca, p.categoria, empresaDe(p).nombre, p.descripcion
      ].join(' '));
      return palabras.every(palabra => texto.includes(palabra));
    });
  }, [busqueda, productosBusqueda]);

  const irADetalle = (producto) => {
    setMostrarResultados(false);
    setBusqueda('');
    if (onVerDetalle) onVerDetalle(producto);
    else onNavigate('principal');
  };

  const irA = (vista) => {
    setMostrarMenu(false);
    setMostrarPerfil(false);
    setMostrarResultados(false);
    onNavigate(vista);
  };

  const abrirChat = (producto) => {
    if (!onAbrirChat) {
      alert('El chat aún no está conectado desde App.jsx.');
      return;
    }
    onAbrirChat({
      publicacionId: producto.id,
      vendedorNombre: empresaDe(producto).nombre,
      productoTitulo: producto.titulo,
      productoImg: producto.img || producto.imagenes?.[0],
      mensajes: [{
        id: 1,
        sender: 'other',
        text: '¡Hola! ¿Tienes alguna consulta sobre el producto?',
        time: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })
      }]
    });
  };

  const subtotal = itemsAComprar.reduce((suma, p) =>
    suma + precioDe(p) * (Number(p.cantidad) || 1), 0
  );
  // Se conserva el cálculo de IVA de tu carrito anterior (subtotal + 19%).
  const iva = Math.round(subtotal * 0.19);
  const region = REGIONES.find(r => r.nombre === regionSeleccionada) || REGIONES[6];
  const costoEnvio = itemsAComprar.length ? region.costo : 0;
  const total = subtotal + iva + costoEnvio;
  const cantidadSeleccionada = itemsAComprar.reduce((suma, p) => suma + (Number(p.cantidad) || 1), 0);
  const seleccionValida = itemsAComprar.length > 0 && itemsAComprar.every(
    p => empresaDe(p).clave === empresaSeleccionada?.clave
  );

  const comprar = async () => {
    if (comprando) return;

    if (!seleccionValida) {
      alert('Selecciona productos de una sola empresa para comprar.');
      return;
    }
    const datosCompra = {
      productoNombre: itemsAComprar[0].titulo + (itemsAComprar.length > 1
        ? ` y ${itemsAComprar.length - 1} más` : ''),
      img: itemsAComprar[0].img || itemsAComprar[0].imagenes?.[0],
      productos: itemsAComprar,
      empresa: empresaSeleccionada.nombre,
      region: regionSeleccionada,
      medioPago,
      subtotal,
      iva,
      costoEnvio,
      totalPagado: total,
      exito: true, // Simulación: no se procesa ningún pago real.
      numeroSeguimiento: `TRK${Math.floor(100000000 + Math.random() * 900000000)}`,
      fecha: new Date().toLocaleString('es-CL')
    };
    setComprando(true);

    try {
      const guardado = await onCompraExitosa?.(
        datosCompra
      );

      if (!guardado) return;

      setCarrito(actual =>
        actual.filter(
          (_, i) => !seleccionados.includes(i)
        )
      );

      setSeleccionados([]);
      onNavigate('comprobante-pago');

    } finally {
      setComprando(false);
    }
  };

  return (
    <div className="carrito-page">
      {/* Barra superior completa, sin salir del carrito al buscar. */}
      <nav className="cart-navbar" aria-label="Navegación principal">
        <div className="cart-nav-izquierda">
          <button className="cart-nav-volver" type="button" onClick={() => irA('principal')} title="Volver a Principal">←</button>
          <button className="cart-nav-logo" type="button" onClick={() => irA('principal')} title="Inicio">
            <Logo alt="Compra y Venta" />
          </button>
          <button className="cart-nav-menu" type="button" onClick={() => { setMostrarMenu(true); setMostrarPerfil(false); }}>
            <span>☰</span> Menú
          </button>
        </div>

        <div className="cart-nav-centro" ref={buscadorRef}>
          <form className="cart-buscador" onSubmit={e => { e.preventDefault(); setMostrarResultados(true); }}>
            <input
              type="search"
              placeholder="Buscar productos, marcas y más..."
              value={busqueda}
              onChange={e => { setBusqueda(e.target.value); setMostrarResultados(true); }}
              onFocus={() => { if (busqueda.trim()) setMostrarResultados(true); }}
              aria-label="Buscar publicaciones"
            />
            <button type="submit" title="Buscar" aria-label="Buscar">🔍</button>
          </form>
          {mostrarResultados && busqueda.trim() && (
            <div className="cart-resultados" role="region" aria-label="Resultados de búsqueda">
              <div className="cart-resultados-titulo">Resultados ({resultados.length})</div>
              {resultados.length ? resultados.map((p, i) => (
                <button key={`${p.id ?? p.titulo}-${i}`} type="button" className="cart-resultado" onClick={() => irADetalle(p)}>
                  <img src={p.img || p.imagenes?.[0] || '/productos/sin-imagen.svg'} alt="" />
                  <span><strong>{p.titulo}</strong><small>{empresaDe(p).nombre} · {formatoCLP(precioDe(p))}</small></span>
                  <span aria-hidden="true">›</span>
                </button>
              )) : <p className="cart-sin-resultados">No encontramos productos con ese nombre.</p>}
            </div>
          )}
        </div>

        <div className="cart-nav-derecha">
          <button type="button" className="cart-nav-icono" title="Lista de deseos" aria-label="Lista de deseos" onClick={() => irA('deseos')}>
            ♡{deseos.length > 0 && <small className="cart-nav-contador">{deseos.length}</small>}
          </button>
          <button type="button" className="cart-nav-icono" title="Carrito" aria-label="Carrito" onClick={() => { setMostrarPerfil(false); setMostrarResultados(false); }}>
            🛒{carrito.length > 0 && <small className="cart-nav-contador">{carrito.length}</small>}
          </button>
          <div className="cart-perfil-contenedor">
            <button type="button" className="cart-nav-usuario" title="Opciones de usuario" aria-label="Opciones de usuario" aria-expanded={mostrarPerfil} onClick={() => setMostrarPerfil(v => !v)}>
              <span>👤</span>⌄
            </button>
            {mostrarPerfil && (
              <div className="cart-perfil-menu">
                <button type="button" onClick={() => irA('perfil')}>Mi perfil</button>
                <button type="button" onClick={() => irA('mis-compras')}>Mis compras</button>
                <button type="button" onClick={() => irA('chat')}>Mis mensajes</button>
                {usuarioActivo?.tipoPerfil?.includes('Administrador') && usuarioActivo?.estadoAdmin === 'Aprobado' &&
                  <button type="button" onClick={() => irA('admin-panel')}>Panel administrador</button>}
                {empresaActiva ? (
                  <>
                    <button type="button" onClick={() => irA('vender')}>Publicar producto</button>
                    <button type="button" onClick={() => irA('mis-ventas')}>Mis ventas</button>
                  </>
                ) : <button type="button" onClick={() => irA('registro-empresa')}>Crear empresa</button>}
                <button type="button" onClick={() => { if (window.confirm('¿Quieres cerrar sesión?')) irA('login'); }}>Cerrar sesión</button>
              </div>
            )}
          </div>
        </div>
      </nav>

      {mostrarMenu && (
        <div className="cart-menu-fondo" onMouseDown={() => setMostrarMenu(false)}>
          <aside className="cart-menu-panel" onMouseDown={e => e.stopPropagation()} aria-label="Menú lateral">
            <div className="cart-menu-cabecera"><h2>Menú</h2><button type="button" onClick={() => setMostrarMenu(false)} aria-label="Cerrar menú">×</button></div>
            <p>Bienvenido a Compra y Venta</p>
            <button type="button" onClick={() => irA('principal')}>⌂ &nbsp; Inicio y categorías</button>
            <button type="button" onClick={() => irA('deseos')}>♡ &nbsp; Lista de deseos</button>
            <button type="button" onClick={() => irA('carrito')}>🛒 &nbsp; Mi carrito</button>
            <button type="button" onClick={() => irA('perfil')}>👤 &nbsp; Mi perfil</button>
            <button type="button" onClick={() => irA('mis-compras')}>▣ &nbsp; Mis compras</button>
            <button type="button" onClick={() => irA('chat')}>💬 &nbsp; Mensajes</button>
            {empresaActiva && <button type="button" onClick={() => irA('mis-ventas')}>▤ &nbsp; Mis ventas</button>}
          </aside>
        </div>
      )}

      <main className="carrito-content">
        <h1 className="cart-titulo-pagina">Mi carrito</h1>
        {carrito.length === 0 ? (
          <div className="cart-vacio"><h2>Tu carrito está vacío.</h2><button type="button" onClick={() => irA('principal')}>Explorar productos</button></div>
        ) : (
          <div className="carrito-grid">
            <section className="cart-left-panel">
              <div className="cart-header-gray">✔️ Todos los productos ({carrito.length})</div>
              <div className="cart-items-container">
                <div className="cart-items-title">Productos</div>
                <p className="cart-aviso-empresa">Puedes guardar productos de varias empresas, pero cada compra corresponde a una sola empresa.</p>
                {carrito.map((item, indice) => {
                  const empresa = empresaDe(item);
                  const seleccionado = seleccionados.includes(indice);
                  const otraEmpresa = empresaSeleccionada && empresaSeleccionada.clave !== empresa.clave;
                  const cantidad = Number(item.cantidad) || 1;
                  return (
                    <article key={`${item.id ?? item.titulo}-${indice}`} className={`cart-item-card ${seleccionado ? 'cart-item-elegido' : ''}`}>
                      <input
                        className="cart-seleccionar"
                        type="checkbox"
                        checked={seleccionado}
                        onChange={() => cambiarSeleccion(indice)}
                        aria-label={`Seleccionar ${item.titulo}`}
                      />
                      <img src={item.img || item.imagenes?.[0] || '/productos/sin-imagen.svg'} alt={item.titulo} className="cart-item-img" />
                      <div className="cart-item-details">
                        <h4>{item.titulo}</h4>
                        <span className="cart-seller-name">Empresa: {empresa.nombre}</span>
                        {otraEmpresa && <small className="cart-cambiar-empresa">Al marcarlo, cambiarás la empresa seleccionada.</small>}
                        <div className="cart-qty-row">
                          <div className="qty-controls">
                            <button type="button" onClick={() => cambiarCantidad(indice, -1)} aria-label="Disminuir cantidad">−</button>
                            <span>{cantidad}</span>
                            <button type="button" onClick={() => cambiarCantidad(indice, 1)} aria-label="Aumentar cantidad">+</button>
                          </div>
                        </div>
                      </div>
                      <div className="cart-item-actions">
                        <span className="cart-item-price">{formatoCLP(precioDe(item) * cantidad)}</span>
                        <button type="button" className="cart-icon-btn" title="Chatear con la empresa" onClick={() => abrirChat(item)}>💬</button>
                        <button type="button" className="cart-icon-btn cart-quitar" title="Quitar del carrito" onClick={() => {
                          setCarrito(actual => actual.filter((_, i) => i !== indice));
                          setSeleccionados(actual => actual.filter(i => i !== indice).map(i => i > indice ? i - 1 : i));
                        }}>Quitar</button>
                      </div>
                    </article>
                  );
                })}
              </div>
            </section>

            <section className="cart-right-panel">
              <h3>Resumen de compra</h3>
              <p className="cart-empresa-resumen">Empresa: <strong>{empresaSeleccionada?.nombre || 'Selecciona un producto'}</strong></p>
              <div className="summary-row"><span>Productos ({cantidadSeleccionada})</span><span>{formatoCLP(subtotal)}</span></div>
              <div className="summary-row"><span>IVA (19%)</span><span>{formatoCLP(iva)}</span></div>
              <div className="summary-row"><span>Descuento de productos</span><span>0%</span></div>
              <label className="cart-resumen-etiqueta" htmlFor="cart-region">Región de despacho</label>
              <select id="cart-region" className="summary-select" value={regionSeleccionada} onChange={e => setRegionSeleccionada(e.target.value)}>
                {REGIONES.map(r => <option key={r.nombre} value={r.nombre}>{r.nombre}</option>)}
              </select>
              <div className="summary-row"><span>Costo envío</span><span>{formatoCLP(costoEnvio)}</span></div>
              <small className="cart-nota-envio">Costos de envío de ejemplo; deben confirmarse antes de cobrar pedidos reales.</small>
              <div className="summary-total-row"><span>Total</span><span>{formatoCLP(total)}</span></div>
              <label className="cart-resumen-etiqueta" htmlFor="cart-medio-pago">Medio de pago</label>
              <select id="cart-medio-pago" className="summary-select" value={medioPago} onChange={e => setMedioPago(e.target.value)}>
                <option value="Debito">Tarjeta de Débito</option>
                <option value="Credito">Tarjeta de Crédito</option>
                <option value="Transferencia">Transferencia Bancaria</option>
              </select>
              <button type="button" className="btn-comprar-blue" disabled={!seleccionValida || comprando} onClick={comprar}>{comprando ? 'GUARDANDO...' : 'REGISTRAR PEDIDO'}</button>
              <button type="button" className="btn-cotizar-outline" disabled={!seleccionValida} onClick={() => onIrCotizacion?.(itemsAComprar)}>Solicitar Cotización</button>
              <small className="cart-nota-simulacion">Versión de prueba: el botón Comprar genera un comprobante simulado, sin cobro real.</small>
            </section>
          </div>
        )}
      </main>
    </div>
  );
}
