import { useEffect, useState } from 'react';

export default function GestionComercial({ onNavigate, api, vendedor = false }) {
  const [cotizaciones, setCotizaciones] = useState([]);
  const [pedidos, setPedidos] = useState([]);
  const [respuestas, setRespuestas] = useState({});
  const [envios, setEnvios] = useState({});
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(false);
  const cargar = async () => {
    setCargando(true);
    try {
      const ruta = vendedor ? '/api/gestion/cotizaciones/recibidas' : '/api/gestion/cotizaciones/mias';
      const datos = await api(ruta);
      setCotizaciones(datos.cotizaciones);
      const p = await api(vendedor ? '/api/pedidos/ventas' : '/api/pedidos/mios');
      setPedidos(p.pedidos);
      setError('');
    } catch(e) { setError(e.message); } finally { setCargando(false); }
  };
  useEffect(() => { cargar(); }, [vendedor]);
  const ejecutar = async (ruta, datos) => {
    try { await api(ruta,'PATCH',datos); await cargar(); }
    catch(e) { setError(e.message); }
  };
  const tarjeta = { background:'#fff',borderRadius:14,padding:18,margin:'12px 0',boxShadow:'0 1px 6px #0002' };
  const boton = {background:'#f97316',color:'white',border:0,padding:'9px 14px',borderRadius:8,cursor:'pointer',margin:4};
  return <main style={{maxWidth:950,margin:'auto',padding:22}}>
    <button style={boton} onClick={() => onNavigate(vendedor?'mis-ventas':'mis-compras')}>← Volver</button>
    <h1>{vendedor?'Gestión de pedidos y cotizaciones':'Mis pedidos y cotizaciones'}</h1>
    <button style={boton} onClick={cargar}>↻ Actualizar desde PostgreSQL</button>
    {cargando && <p>Cargando...</p>}{error && <p role="alert" style={{color:'crimson'}}>{error}</p>}
    <h2>Cotizaciones</h2>
    {!cotizaciones.length && <p>No hay cotizaciones registradas.</p>}
    {cotizaciones.map(c => <section key={c.id} style={tarjeta}>
      <h3>Cotización N° {c.id} · {c.estado}</h3>
      <p>{vendedor?`Solicitante: ${c.solicitante}`:`Empresa: ${c.nombre_empresa}`}</p>
      <p>Total referencial: ${Number(c.total).toLocaleString('es-CL')}</p>
      <p>Vigencia: {c.vence_en?new Date(c.vence_en).toLocaleDateString('es-CL'):'No indicada'}</p>
      <ul>{c.detalles.map((d,i)=><li key={i}>{d.titulo} × {d.cantidad} — ${Number(d.precio).toLocaleString('es-CL')}</li>)}</ul>
      {c.respuesta && <p><strong>Respuesta:</strong> {c.respuesta}</p>}
      {vendedor && ['Solicitada','Pendiente','Respondida'].includes(c.estado) && <div>
        <textarea rows={2} maxLength={2000} style={{width:'100%'}} placeholder="Respuesta del vendedor" value={respuestas[c.id] ?? c.respuesta ?? ''}
          onChange={e=>setRespuestas(a=>({...a,[c.id]:e.target.value}))}/>
        <button style={boton} onClick={()=>ejecutar(`/api/gestion/cotizaciones/${c.id}/responder`,{respuesta:respuestas[c.id]??c.respuesta??''})}>Responder cotización</button>
      </div>}
      {!vendedor && c.estado==='Respondida' && <button style={boton} onClick={()=>ejecutar(`/api/gestion/cotizaciones/${c.id}/aceptar`,{})}>Aceptar cotización</button>}
    </section>)}
    <h2>Pedidos</h2>
    {!pedidos.length && <p>No hay pedidos registrados.</p>}
    {pedidos.map(p => <section key={p.id} style={tarjeta}>
      <h3>Pedido N° {p.id} · {p.estado || 'Registrado'}</h3>
      <p>Total: ${Number(p.totalPagado).toLocaleString('es-CL')} · Región: {p.ubicacionDespacho}</p>
      <ul>{p.productos.map((d,i)=><li key={i}>{d.titulo} × {d.cantidad}</li>)}</ul>
      {p.transportista && <p>Transportista: {p.transportista} · Seguimiento: {p.numeroSeguimiento}</p>}
      {vendedor && !['Entregado','Cancelado'].includes(p.estado) && <div>
        {p.estado==='En preparación' && <>
          <input aria-label="Transportista" placeholder="Transportista" value={envios[p.id]?.transportista??''}
            onChange={e=>setEnvios(a=>({...a,[p.id]:{...a[p.id],transportista:e.target.value}}))}/>
          <input aria-label="Número de seguimiento" placeholder="Número de seguimiento" value={envios[p.id]?.numeroSeguimiento??''}
            onChange={e=>setEnvios(a=>({...a,[p.id]:{...a[p.id],numeroSeguimiento:e.target.value}}))}/>
        </>}
        <button style={boton} onClick={()=>ejecutar(`/api/gestion/pedidos/${p.id}/estado`,{
          estado:p.estado==='Registrado'?'En preparación':p.estado==='En preparación'?'Enviado':'Entregado',
          transportista:envios[p.id]?.transportista||p.transportista||'',
          numeroSeguimiento:envios[p.id]?.numeroSeguimiento||p.numeroSeguimiento||''
        })}>Marcar {p.estado==='Registrado'?'En preparación':p.estado==='En preparación'?'Enviado':'Entregado'}</button>
      </div>}
    </section>)}
  </main>;
}
